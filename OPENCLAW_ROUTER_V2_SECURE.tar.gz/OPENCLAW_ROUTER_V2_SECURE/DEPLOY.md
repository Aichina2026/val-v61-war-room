# OpenClaw Router V2.0 - 部署指南

## 系统要求

### 最低配置
- **CPU**: 2核
- **内存**: 2GB RAM
- **磁盘**: 10GB 可用空间
- **网络**: 公网IP或内网穿透

### 推荐配置
- **CPU**: 4核+
- **内存**: 4GB+ RAM
- **磁盘**: 20GB+ SSD
- **Docker**: 20.10+ / Docker Compose 2.0+

### 依赖软件
- Docker 20.10+
- Docker Compose 2.0+
- curl / wget
- (可选) Git

---

## 快速开始

### 1. 克隆项目

```bash
git clone https://github.com/openclaw/smart-router-v2.git
cd smart-router-v2
```

### 2. 配置环境变量

```bash
# 从模板创建环境文件
cp .env.example .env

# 编辑环境文件，设置必要的配置
nano .env
```

**必须配置项:**
- `FOURSAPI_KEYS` - 4SAPI API密钥 (支持多个，用逗号分隔)
- `JWT_SECRET` - JWT签名密钥 (生产环境必须修改)
- `API_KEY` - 内部API认证密钥

### 3. 启动服务

```bash
# 标准模式启动
./scripts/start.sh

# 后台模式启动
./scripts/start.sh -d

# 带监控启动 (Prometheus + Grafana)
./scripts/start.sh -m monitoring

# 强制重建镜像后启动
./scripts/start.sh -b
```

### 4. 验证部署

```bash
# 运行健康检查
./scripts/health-check.sh

# 详细健康检查
./scripts/health-check.sh -v
```

---

## 环境变量配置

### 核心配置

| 变量名 | 必需 | 默认值 | 说明 |
|--------|:----:|--------|------|
| `FOURSAPI_KEYS` | ✅ | - | 4SAPI API密钥，多个用逗号分隔 |
| `FOURSAPI_BASE_URL` | - | `https://api.4sapi.com/v1` | 4SAPI基础URL |
| `JWT_SECRET` | ✅ | - | JWT签名密钥 |
| `API_KEY` | ✅ | - | 内部API认证密钥 |

### 服务器配置

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| `HTTP_PORT` | 8080 | HTTP API端口 |
| `WS_PORT` | 8081 | WebSocket端口 |
| `METRICS_PORT` | 9090 | Prometheus指标端口 |
| `NODE_ENV` | production | 运行环境 |

### Redis配置

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| `REDIS_URL` | `redis://localhost:6379/0` | Redis连接URL |
| `REDIS_HOST` | localhost | Redis主机 |
| `REDIS_PORT` | 6379 | Redis端口 |

### 路由配置

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| `ROUTER_DEFAULT_STRATEGY` | adaptive | 默认路由策略 |
| `ROUTER_MAX_CONCURRENT` | 100 | 最大并发数 |
| `ROUTER_REQUEST_TIMEOUT` | 60000 | 请求超时(毫秒) |
| `ROUTER_ML_PREDICT_ENABLED` | true | 启用ML预测 |

### 熔断器配置

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| `CIRCUIT_BREAKER_HEALTH_THRESHOLD` | 0.92 | 健康阈值 |
| `CIRCUIT_BREAKER_FAILURE_THRESHOLD` | 0.5 | 失败率阈值 |
| `CIRCUIT_BREAKER_WAIT_DURATION` | 30000 | 熔断等待时间(毫秒) |

---

## 部署模式

### 开发模式

适用于本地开发和调试:

```bash
./scripts/start.sh -m dev
```

特性:
- 热重载
- 调试端口开放 (9229)
- 详细日志输出

### 标准生产模式

适用于生产环境:

```bash
./scripts/start.sh -m standard -d
```

特性:
- 多阶段构建优化
- 非root用户运行
- 健康检查
- 资源限制

### 监控模式

适用于需要监控的场景:

```bash
./scripts/start.sh -m monitoring -d
```

包含:
- Prometheus (http://localhost:9091)
- Grafana (http://localhost:3000)
- Redis监控

---

## 服务端口

| 端口 | 服务 | 说明 |
|:----:|------|------|
| 8080 | HTTP API | 主服务接口 |
| 8081 | WebSocket | 实时通信 |
| 9090 | Metrics | Prometheus指标 |
| 6379 | Redis | 缓存服务 |
| 9091 | Prometheus | 监控UI (监控模式) |
| 3000 | Grafana | 仪表板 (监控模式) |

---

## 运维命令

### 查看日志

```bash
# 查看所有服务日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f app
docker-compose logs -f redis

# 查看最近100行
docker-compose logs --tail=100 app
```

### 重启服务

```bash
# 重启所有服务
docker-compose restart

# 重启特定服务
docker-compose restart app

# 停止并重新启动
./scripts/stop.sh
./scripts/start.sh -d
```

### 更新部署

```bash
# 拉取最新代码
git pull

# 重建并启动
./scripts/start.sh -b -d
```

### 停止服务

```bash
# 正常停止
./scripts/stop.sh

# 停止并删除数据卷 (⚠️ 数据丢失)
./scripts/stop.sh -v

# 完全清理 (包含镜像)
./scripts/stop.sh -a
```

---

## 监控配置

### Prometheus

访问: http://localhost:9091

默认配置监控:
- OpenClaw Router V2 指标
- Redis 状态
- 容器资源使用

### Grafana

访问: http://localhost:3000
- 默认账号: admin/admin

预配置仪表板:
- 系统概览
- 请求速率 & 延迟
- 熔断器状态
- Key池健康度

### 健康检查端点

```bash
# 基础健康检查
curl http://localhost:8080/health

# 就绪检查
curl http://localhost:8080/ready

# Prometheus指标
curl http://localhost:9090/metrics
```

---

## 安全建议

### 1. 修改默认密钥

```bash
# 生成强密钥
openssl rand -base64 32

# 更新 .env 文件
JWT_SECRET=your-generated-secret
API_KEY=your-generated-api-key
```

### 2. 配置防火墙

```bash
# 仅开放必要端口
sudo ufw allow 8080/tcp
sudo ufw allow 8081/tcp
# sudo ufw allow 22/tcp  # SSH
```

### 3. 启用HTTPS

建议使用反向代理 (Nginx/Traefik):

```nginx
server {
    listen 443 ssl http2;
    server_name your-domain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location /ws {
        proxy_pass http://localhost:8081;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

### 4. Redis安全

生产环境建议:
```bash
# 启用Redis认证
redis-cli CONFIG SET requirepass "your-strong-password"

# 更新 .env
REDIS_URL=redis://:your-strong-password@redis:6379/0
```

---

## 故障排查

### 服务无法启动

```bash
# 检查日志
docker-compose logs app

# 检查端口占用
sudo lsof -i :8080

# 检查环境变量
cat .env | grep -E "^(FOURSAPI_KEYS|JWT_SECRET)"
```

### 健康检查失败

```bash
# 详细检查
./scripts/health-check.sh -v

# 检查容器状态
docker-compose ps

# 进入容器调试
docker-compose exec app sh
```

### 性能问题

```bash
# 查看资源使用
docker stats

# 查看Redis内存
redis-cli INFO memory

# 重启优化
./scripts/stop.sh
./scripts/start.sh -d
```

---

## CI/CD 配置

### GitHub Actions

已配置工作流:
- `.github/workflows/ci.yml` - 持续集成
- `.github/workflows/deploy.yml` - 持续部署

### 所需 Secrets

| Secret | 说明 |
|--------|------|
| `GITHUB_TOKEN` | 自动提供 |
| `STAGING_SSH_KEY` | 预发布环境SSH密钥 |
| `STAGING_HOST` | 预发布服务器地址 |
| `PRODUCTION_SSH_KEY` | 生产环境SSH密钥 |
| `PRODUCTION_HOST` | 生产服务器地址 |
| `SLACK_WEBHOOK_URL` | Slack通知(可选) |

---

## 备份与恢复

### 备份数据

```bash
# 备份Redis数据
docker-compose exec redis redis-cli BGSAVE
docker cp openclaw-redis-v2:/data/dump.rdb ./backup/redis-$(date +%Y%m%d).rdb

# 备份日志
tar -czf ./backup/logs-$(date +%Y%m%d).tar.gz ./logs
```

### 恢复数据

```bash
# 停止服务
./scripts/stop.sh

# 恢复Redis数据
docker cp ./backup/redis-YYYYMMDD.rdb openclaw-redis-v2:/data/dump.rdb

# 启动服务
./scripts/start.sh -d
```

---

## 升级指南

### 小版本升级

```bash
git pull origin main
./scripts/stop.sh
./scripts/start.sh -b -d
```

### 大版本升级

1. 阅读 CHANGELOG
2. 备份数据
3. 测试环境验证
4. 生产环境滚动更新

---

## 支持

- **文档**: https://docs.openclaw.io
- **Issue**: https://github.com/openclaw/smart-router-v2/issues
- **讨论**: https://github.com/openclaw/smart-router-v2/discussions

---

## 许可证

MIT License - 详见 LICENSE 文件
