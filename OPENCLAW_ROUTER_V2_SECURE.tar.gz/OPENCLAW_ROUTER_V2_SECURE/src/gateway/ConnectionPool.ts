/**
 * ConnectionPool - WebSocket连接池管理器
 *
 * 提供预建立连接、连接复用、自动扩缩容和连接健康检查
 * 实现生产级连接生命周期管理
 *
 * @version 2.0.0
 * @author OPENCLAW Router System
 */

import { EventEmitter } from 'events';
import WebSocket from 'ws';
import { JWTCache, JWTTokenData } from './JWTCache';
import { DistributedRateLimiter } from './DistributedRateLimiter';
import { MessageSerializer } from './MessageSerializer';

/**
 * 连接池配置
 */
export interface ConnectionPoolConfig {
  /** 最小连接数 */
  minConnections: number;
  /** 最大连接数 */
  maxConnections: number;
  /** 启动时是否预热 */
  warmupOnStart: boolean;
  /** 连接超时 (毫秒) */
  connectionTimeout: number;
  /** 心跳间隔 (毫秒) */
  heartbeatInterval: number;
  /** 空闲超时 (毫秒) */
  idleTimeout: number;
  /** 健康检查间隔 (毫秒) */
  healthCheckInterval: number;
  /** 扩容阈值 (0-1) */
  scaleUpThreshold: number;
  /** 缩容阈值 (0-1) */
  scaleDownThreshold: number;
}

/**
 * 连接状态
 */
export enum ConnectionState {
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  AUTHENTICATING = 'authenticating',
  READY = 'ready',
  BUSY = 'busy',
  CLOSING = 'closing',
  CLOSED = 'closed',
  ERROR = 'error',
}

/**
 * 池连接包装器
 */
export interface PooledConnection {
  /** 连接ID */
  id: string;
  /** WebSocket实例 */
  ws: WebSocket;
  /** 当前状态 */
  state: ConnectionState;
  /** 创建时间 */
  createdAt: number;
  /** 最后活动时间 */
  lastActivity: number;
  /** 认证信息 */
  auth?: JWTTokenData;
  /** 连接元数据 */
  metadata: Map<string, unknown>;
  /** 当前负载 (0-100) */
  load: number;
  /** 消息计数 */
  messageCount: number;
  /** 错误计数 */
  errorCount: number;
}

/**
 * 连接统计
 */
export interface ConnectionPoolStats {
  /** 总连接数 */
  total: number;
  /** 按状态分布 */
  byState: Record<ConnectionState, number>;
  /** 活跃连接数 */
  active: number;
  /** 可用连接数 */
  available: number;
  /** 等待获取连接的请求数 */
  waiting: number;
  /** 总创建数 */
  totalCreated: number;
  /** 总关闭数 */
  totalClosed: number;
  /** 总复用次数 */
  totalReused: number;
  /** 平均连接时长 */
  averageConnectionDuration: number;
  /** 连接错误率 */
  errorRate: number;
}

/**
 * 默认配置
 */
const DEFAULT_CONFIG: ConnectionPoolConfig = {
  minConnections: 5,
  maxConnections: 100,
  warmupOnStart: true,
  connectionTimeout: 30000,
  heartbeatInterval: 30000,
  idleTimeout: 300000,
  healthCheckInterval: 60000,
  scaleUpThreshold: 0.8,
  scaleDownThreshold: 0.3,
};

/**
 * 连接池管理器
 */
export class ConnectionPool extends EventEmitter {
  private config: ConnectionPoolConfig;
  private connections: Map<string, PooledConnection>;
  private connectionQueue: Array<{
    resolve: (conn: PooledConnection) => void;
    reject: (error: Error) => void;
    timeout: NodeJS.Timeout;
    priority: number;
  }>;
  private stats: {
    totalCreated: number;
    totalClosed: number;
    totalReused: number;
    totalErrors: number;
    connectionDurations: number[];
  };
  private healthCheckTimer: NodeJS.Timeout | null = null;
  private scaleCheckTimer: NodeJS.Timeout | null = null;
  private isClosing = false;

  // 依赖组件
  private jwtCache?: JWTCache;
  private rateLimiter?: DistributedRateLimiter;
  private serializer?: MessageSerializer;

  constructor(
    config: Partial<ConnectionPoolConfig> = {},
    deps?: {
      jwtCache?: JWTCache;
      rateLimiter?: DistributedRateLimiter;
      serializer?: MessageSerializer;
    }
  ) {
    super();
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.connections = new Map();
    this.connectionQueue = [];
    this.stats = {
      totalCreated: 0,
      totalClosed: 0,
      totalReused: 0,
      totalErrors: 0,
      connectionDurations: [],
    };

    if (deps) {
      this.jwtCache = deps.jwtCache;
      this.rateLimiter = deps.rateLimiter;
      this.serializer = deps.serializer;
    }

    this.startHealthCheck();
    this.startScaleCheck();

    if (this.config.warmupOnStart) {
      setImmediate(() => this.warmup());
    }
  }

  /**
   * 预热连接池
   */
  async warmup(): Promise<void> {
    const currentCount = this.connections.size;
    const needed = this.config.minConnections - currentCount;

    if (needed <= 0) return;

    this.emit('warmup:start', { needed });

    const promises: Promise<void>[] = [];
    for (let i = 0; i < needed; i++) {
      promises.push(this.createConnection().then(() => {}));
    }

    try {
      await Promise.all(promises);
      this.emit('warmup:complete', { created: needed });
    } catch (error) {
      this.emit('warmup:error', error);
    }
  }

  /**
   * 获取连接
   * @param timeout - 获取超时
   * @param priority - 优先级 (越高越优先)
   */
  async acquire(
    timeout?: number,
    priority: number = 0
  ): Promise<PooledConnection> {
    if (this.isClosing) {
      throw new Error('Connection pool is closing');
    }

    // 尝试获取可用连接
    const available = this.findAvailableConnection();
    if (available) {
      this.stats.totalReused++;
      this.updateConnectionActivity(available);
      this.emit('connection:acquired', { id: available.id, reused: true });
      return available;
    }

    // 如果未达到最大连接数，创建新连接
    if (this.connections.size < this.config.maxConnections) {
      try {
        const conn = await this.createConnection();
        this.updateConnectionActivity(conn);
        this.emit('connection:acquired', { id: conn.id, reused: false });
        return conn;
      } catch (error) {
        this.emit('connection:create:error', error);
      }
    }

    // 等待可用连接
    return new Promise((resolve, reject) => {
      const waitTimeout = setTimeout(() => {
        this.connectionQueue = this.connectionQueue.filter(
          (item) => item.timeout !== waitTimeout
        );
        reject(new Error('Connection acquisition timeout'));
      }, timeout || this.config.connectionTimeout);

      this.connectionQueue.push({ resolve, reject, timeout: waitTimeout, priority });

      // 按优先级排序
      this.connectionQueue.sort((a, b) => b.priority - a.priority);
    });
  }

  /**
   * 释放连接
   * @param connection - 要释放的连接
   */
  release(connection: PooledConnection): void {
    if (!this.connections.has(connection.id)) {
      return;
    }

    this.updateConnectionActivity(connection);
    connection.state = ConnectionState.READY;

    // 处理等待队列
    this.processWaitQueue();

    this.emit('connection:released', { id: connection.id });
  }

  /**
   * 关闭连接
   * @param connection - 要关闭的连接
   * @param reason - 关闭原因
   */
  async closeConnection(
    connection: PooledConnection,
    reason: string = 'normal'
  ): Promise<void> {
    if (connection.state === ConnectionState.CLOSED) {
      return;
    }

    connection.state = ConnectionState.CLOSING;

    // 关闭WebSocket
    if (connection.ws.readyState === WebSocket.OPEN) {
      connection.ws.close(1000, reason);
    }

    // 记录连接时长
    const duration = Date.now() - connection.createdAt;
    this.stats.connectionDurations.push(duration);

    // 保持最近1000条记录
    if (this.stats.connectionDurations.length > 1000) {
      this.stats.connectionDurations.shift();
    }

    this.connections.delete(connection.id);
    this.stats.totalClosed++;

    this.emit('connection:closed', { id: connection.id, reason, duration });
  }

  /**
   * 创建新连接
   */
  private async createConnection(): Promise<PooledConnection> {
    const id = this.generateConnectionId();

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Connection creation timeout'));
      }, this.config.connectionTimeout);

      try {
        // 注意：这里创建的是服务端WebSocket (用于与客户端通信)
        // 实际项目中可能需要不同的创建逻辑
        const ws = new WebSocket('wss://placeholder');

        const connection: PooledConnection = {
          id,
          ws,
          state: ConnectionState.CONNECTING,
          createdAt: Date.now(),
          lastActivity: Date.now(),
          metadata: new Map(),
          load: 0,
          messageCount: 0,
          errorCount: 0,
        };

        ws.on('open', () => {
          clearTimeout(timeout);
          connection.state = ConnectionState.CONNECTED;
          this.connections.set(id, connection);
          this.stats.totalCreated++;
          this.emit('connection:created', { id });
          resolve(connection);
        });

        ws.on('error', (error) => {
          clearTimeout(timeout);
          connection.state = ConnectionState.ERROR;
          this.stats.totalErrors++;
          this.emit('connection:error', { id, error });
          reject(error);
        });

        ws.on('close', () => {
          if (this.connections.has(id)) {
            this.closeConnection(connection, 'remote closed');
          }
        });

        ws.on('message', (data) => {
          this.handleMessage(connection, data);
        });

        ws.on('ping', () => {
          connection.lastActivity = Date.now();
        });

        ws.on('pong', () => {
          connection.lastActivity = Date.now();
        });

      } catch (error) {
        clearTimeout(timeout);
        reject(error);
      }
    });
  }

  /**
   * 处理消息
   */
  private handleMessage(connection: PooledConnection, data: WebSocket.Data): void {
    connection.lastActivity = Date.now();
    connection.messageCount++;
    connection.load = Math.min(100, connection.load + 1);

    this.emit('message', { connectionId: connection.id, data });
  }

  /**
   * 查找可用连接
   */
  private findAvailableConnection(): PooledConnection | null {
    let best: PooledConnection | null = null;
    let bestLoad = Infinity;

    for (const conn of this.connections.values()) {
      if (conn.state === ConnectionState.READY && conn.load < bestLoad) {
        best = conn;
        bestLoad = conn.load;
      }
    }

    return best;
  }

  /**
   * 更新连接活动
   */
  private updateConnectionActivity(connection: PooledConnection): void {
    connection.lastActivity = Date.now();
    connection.state = ConnectionState.BUSY;
  }

  /**
   * 处理等待队列
   */
  private processWaitQueue(): void {
    while (this.connectionQueue.length > 0) {
      const available = this.findAvailableConnection();
      if (!available) break;

      const waiter = this.connectionQueue.shift();
      if (waiter) {
        clearTimeout(waiter.timeout);
        this.updateConnectionActivity(available);
        waiter.resolve(available);
      }
    }
  }

  /**
   * 启动健康检查
   */
  private startHealthCheck(): void {
    this.healthCheckTimer = setInterval(() => {
      this.performHealthCheck();
    }, this.config.healthCheckInterval);
  }

  /**
   * 执行健康检查
   */
  private performHealthCheck(): void {
    const now = Date.now();
    const toClose: PooledConnection[] = [];

    for (const conn of this.connections.values()) {
      // 检查空闲超时
      if (now - conn.lastActivity > this.config.idleTimeout) {
        if (conn.state === ConnectionState.READY) {
          toClose.push(conn);
          continue;
        }
      }

      // 检查连接状态
      if (conn.ws.readyState === WebSocket.CLOSED || conn.ws.readyState === WebSocket.CLOSING) {
        toClose.push(conn);
        continue;
      }

      // 发送心跳
      if (conn.state === ConnectionState.READY && conn.ws.readyState === WebSocket.OPEN) {
        conn.ws.ping();
      }

      // 检查错误率
      if (conn.messageCount > 0 && conn.errorCount / conn.messageCount > 0.1) {
        toClose.push(conn);
      }
    }

    // 关闭不健康连接
    for (const conn of toClose) {
      this.closeConnection(conn, 'health check failed');
    }

    // 保持最小连接数
    const needed = this.config.minConnections - this.connections.size;
    if (needed > 0 && !this.isClosing) {
      for (let i = 0; i < needed; i++) {
        this.createConnection().catch(() => {});
      }
    }

    this.emit('health:check', { closed: toClose.length, created: needed });
  }

  /**
   * 启动扩缩容检查
   */
  private startScaleCheck(): void {
    this.scaleCheckTimer = setInterval(() => {
      this.checkScaling();
    }, 10000);
  }

  /**
   * 检查扩缩容
   */
  private checkScaling(): void {
    const total = this.connections.size;
    if (total === 0) return;

    const busy = Array.from(this.connections.values()).filter(
      (c) => c.state === ConnectionState.BUSY
    ).length;

    const utilization = busy / total;

    // 扩容
    if (utilization > this.config.scaleUpThreshold && total < this.config.maxConnections) {
      const toAdd = Math.min(5, this.config.maxConnections - total);
      for (let i = 0; i < toAdd; i++) {
        this.createConnection().catch(() => {});
      }
      this.emit('scale:up', { added: toAdd, utilization });
    }

    // 缩容
    if (utilization < this.config.scaleDownThreshold && total > this.config.minConnections) {
      const toRemove = Math.min(3, total - this.config.minConnections);
      let removed = 0;

      for (const conn of this.connections.values()) {
        if (conn.state === ConnectionState.READY && removed < toRemove) {
          this.closeConnection(conn, 'scale down');
          removed++;
        }
      }

      if (removed > 0) {
        this.emit('scale:down', { removed, utilization });
      }
    }
  }

  /**
   * 生成连接ID
   */
  private generateConnectionId(): string {
    return `conn-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 获取连接统计
   */
  getStats(): ConnectionPoolStats {
    const byState: Record<ConnectionState, number> = {
      [ConnectionState.CONNECTING]: 0,
      [ConnectionState.CONNECTED]: 0,
      [ConnectionState.AUTHENTICATING]: 0,
      [ConnectionState.READY]: 0,
      [ConnectionState.BUSY]: 0,
      [ConnectionState.CLOSING]: 0,
      [ConnectionState.CLOSED]: 0,
      [ConnectionState.ERROR]: 0,
    };

    for (const conn of this.connections.values()) {
      byState[conn.state]++;
    }

    const avgDuration =
      this.stats.connectionDurations.length > 0
        ? this.stats.connectionDurations.reduce((a, b) => a + b, 0) /
          this.stats.connectionDurations.length
        : 0;

    const totalMessages = Array.from(this.connections.values()).reduce(
      (sum, c) => sum + c.messageCount,
      0
    );

    return {
      total: this.connections.size,
      byState,
      active: byState[ConnectionState.BUSY],
      available: byState[ConnectionState.READY],
      waiting: this.connectionQueue.length,
      totalCreated: this.stats.totalCreated,
      totalClosed: this.stats.totalClosed,
      totalReused: this.stats.totalReused,
      averageConnectionDuration: avgDuration,
      errorRate: totalMessages > 0 ? this.stats.totalErrors / totalMessages : 0,
    };
  }

  /**
   * 获取连接
   */
  getConnection(id: string): PooledConnection | undefined {
    return this.connections.get(id);
  }

  /**
   * 获取所有连接
   */
  getAllConnections(): PooledConnection[] {
    return Array.from(this.connections.values());
  }

  /**
   * 关闭连接池
   */
  async close(force: boolean = false): Promise<void> {
    this.isClosing = true;

    // 停止定时器
    if (this.healthCheckTimer) {
      clearInterval(this.healthCheckTimer);
      this.healthCheckTimer = null;
    }

    if (this.scaleCheckTimer) {
      clearInterval(this.scaleCheckTimer);
      this.scaleCheckTimer = null;
    }

    // 拒绝等待队列
    for (const waiter of this.connectionQueue) {
      clearTimeout(waiter.timeout);
      waiter.reject(new Error('Connection pool is closing'));
    }
    this.connectionQueue = [];

    // 关闭所有连接
    const closePromises: Promise<void>[] = [];
    for (const conn of this.connections.values()) {
      closePromises.push(this.closeConnection(conn, 'pool closing'));
    }

    if (!force) {
      await Promise.all(closePromises);
    }

    this.connections.clear();
    this.emit('closed');
  }
}

export default ConnectionPool;
