/**
 * JWTCache - JWT多级缓存系统
 * 
 * 提供L1内存缓存(10s TTL)和L2 Redis缓存(60s TTL)两级缓存架构
 * 实现快速验证路径、缓存穿透保护和异步刷新机制
 * 
 * @version 2.0.0
 * @author OPENCLAW Router System
 */

import Redis, { RedisOptions } from 'ioredis';
import { EventEmitter } from 'events';
import * as crypto from 'crypto';

/**
 * JWT令牌数据
 */
export interface JWTTokenData {
  /** 用户ID */
  userId: string;
  /** 用户角色 */
  roles: string[];
  /** 权限列表 */
  permissions: string[];
  /** 颁发时间 */
  issuedAt: number;
  /** 过期时间 */
  expiresAt: number;
  /** 令牌元数据 */
  metadata?: Record<string, unknown>;
}

/**
 * 缓存条目
 */
interface CacheEntry<T> {
  /** 缓存数据 */
  data: T;
  /** 过期时间戳 */
  expiresAt: number;
  /** 最后访问时间 */
  lastAccessed: number;
  /** 访问计数 */
  accessCount: number;
}

/**
 * JWT缓存配置
 */
export interface JWTCacheConfig {
  /** L1内存缓存TTL (毫秒，默认10s) */
  l1TTL: number;
  /** L2 Redis缓存TTL (毫秒，默认60s) */
  l2TTL: number;
  /** L1最大条目数 */
  l1MaxSize: number;
  /** Redis连接配置 */
  redis?: RedisOptions | Redis;
  /** 是否启用缓存预热 */
  enableWarmup: boolean;
  /** 缓存穿透保护窗口 (毫秒) */
  penetrationProtectionWindow: number;
  /** 异步刷新阈值 (剩余TTL小于此值时触发刷新，毫秒) */
  asyncRefreshThreshold: number;
}

/**
 * 缓存统计
 */
export interface CacheStats {
  l1: {
    hits: number;
    misses: number;
    size: number;
    evictions: number;
  };
  l2: {
    hits: number;
    misses: number;
    errors: number;
  };
  penetrationProtection: {
    blockedRequests: number;
    uniqueKeys: number;
  };
  asyncRefreshes: number;
}

/**
 * 验证结果
 */
export interface ValidationResult {
  /** 是否有效 */
  valid: boolean;
  /** 令牌数据 */
  data?: JWTTokenData;
  /** 错误信息 */
  error?: string;
  /** 缓存来源 */
  source?: 'l1' | 'l2' | 'origin';
  /** 验证耗时 */
  durationMs: number;
}

/**
 * 默认配置
 */
const DEFAULT_CONFIG: JWTCacheConfig = {
  l1TTL: 10000, // 10秒
  l2TTL: 60000, // 60秒
  l1MaxSize: 10000,
  enableWarmup: false,
  penetrationProtectionWindow: 5000,
  asyncRefreshThreshold: 5000,
};

/**
 * JWT缓存类
 */
export class JWTCache extends EventEmitter {
  private config: JWTCacheConfig;
  private l1Cache: Map<string, CacheEntry<JWTTokenData>>;
  private redis: Redis | null = null;
  private redisConnected = false;
  private stats: CacheStats;
  private penetrationProtection: Map<string, number> = new Map();
  private refreshInProgress: Set<string> = new Set();
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor(config: Partial<JWTCacheConfig> = {}) {
    super();
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.l1Cache = new Map();
    this.stats = {
      l1: { hits: 0, misses: 0, size: 0, evictions: 0 },
      l2: { hits: 0, misses: 0, errors: 0 },
      penetrationProtection: { blockedRequests: 0, uniqueKeys: 0 },
      asyncRefreshes: 0,
    };

    this.initRedis();
    this.startCleanupInterval();
  }

  /**
   * 初始化Redis连接
   */
  private initRedis(): void {
    if (this.config.redis) {
      if (this.config.redis instanceof Redis) {
        this.redis = this.config.redis;
      } else {
        this.redis = new Redis(this.config.redis);
      }

      this.redis.on('connect', () => {
        this.redisConnected = true;
        this.emit('redis:connect');
      });

      this.redis.on('error', (err) => {
        this.redisConnected = false;
        this.emit('redis:error', err);
      });

      this.redis.on('close', () => {
        this.redisConnected = false;
        this.emit('redis:close');
      });
    }
  }

  /**
   * 启动定期清理任务
   */
  private startCleanupInterval(): void {
    // 每30秒清理一次过期条目
    this.cleanupInterval = setInterval(() => {
      this.cleanupL1Cache();
    }, 30000);
  }

  /**
   * 验证JWT令牌 (主入口)
   * @param token - JWT令牌
   * @returns 验证结果
   */
  async validateToken(token: string): Promise<ValidationResult> {
    const startTime = Date.now();
    const cacheKey = this.generateCacheKey(token);

    try {
      // 1. 检查L1缓存
      const l1Result = this.getFromL1(cacheKey);
      if (l1Result) {
        this.checkAndTriggerAsyncRefresh(cacheKey, token, l1Result);
        return {
          valid: true,
          data: l1Result,
          source: 'l1',
          durationMs: Date.now() - startTime,
        };
      }

      // 2. 检查缓存穿透保护
      if (this.isPenetrationProtected(cacheKey)) {
        this.stats.penetrationProtection.blockedRequests++;
        return {
          valid: false,
          error: 'Token validation rate limited (penetration protection)',
          durationMs: Date.now() - startTime,
        };
      }

      // 3. 检查L2缓存
      if (this.redisConnected) {
        const l2Result = await this.getFromL2(cacheKey);
        if (l2Result) {
          // 回填L1缓存
          this.setL1(cacheKey, l2Result);
          return {
            valid: true,
            data: l2Result,
            source: 'l2',
            durationMs: Date.now() - startTime,
          };
        }
      }

      // 4. L1和L2都未命中，需要验证原始令牌
      this.stats.l1.misses++;
      this.stats.l2.misses++;

      // 记录穿透保护
      this.recordPenetrationAttempt(cacheKey);

      return {
        valid: false,
        source: 'origin',
        durationMs: Date.now() - startTime,
      };
    } catch (error) {
      this.emit('error', error);
      return {
        valid: false,
        error: `Validation error: ${error}`,
        durationMs: Date.now() - startTime,
      };
    }
  }

  /**
   * 设置令牌缓存 (在原始验证成功后调用)
   * @param token - 原始令牌
   * @param data - 令牌数据
   */
  async setToken(token: string, data: JWTTokenData): Promise<void> {
    const cacheKey = this.generateCacheKey(token);
    const now = Date.now();

    // 检查令牌是否过期
    if (data.expiresAt <= now) {
      return;
    }

    // 计算实际TTL
    const l1TTL = Math.min(this.config.l1TTL, data.expiresAt - now);
    const l2TTL = Math.min(this.config.l2TTL, data.expiresAt - now);

    // 设置L1缓存
    this.setL1(cacheKey, data, l1TTL);

    // 设置L2缓存
    if (this.redisConnected && l2TTL > 0) {
      try {
        await this.redis!.setex(
          `jwt:${cacheKey}`,
          Math.ceil(l2TTL / 1000),
          JSON.stringify(data)
        );
      } catch (error) {
        this.stats.l2.errors++;
        this.emit('redis:error', error);
      }
    }
  }

  /**
   * 使令牌失效
   * @param token - 要失效的令牌
   */
  async invalidateToken(token: string): Promise<void> {
    const cacheKey = this.generateCacheKey(token);

    // 删除L1缓存
    this.l1Cache.delete(cacheKey);

    // 删除L2缓存
    if (this.redisConnected) {
      try {
        await this.redis!.del(`jwt:${cacheKey}`);
      } catch (error) {
        this.emit('redis:error', error);
      }
    }

    this.emit('token:invalidated', cacheKey);
  }

  /**
   * 批量使令牌失效 (如用户登出所有会话)
   * @param userId - 用户ID
   */
  async invalidateUserTokens(userId: string): Promise<void> {
    // 清理L1中属于该用户的令牌
    for (const [key, entry] of this.l1Cache.entries()) {
      if (entry.data.userId === userId) {
        this.l1Cache.delete(key);
      }
    }

    // 使用Redis pattern删除
    if (this.redisConnected) {
      try {
        const keys = await this.redis!.keys(`jwt:*`);
        for (const key of keys) {
          const data = await this.redis!.get(key);
          if (data) {
            const parsed = JSON.parse(data) as JWTTokenData;
            if (parsed.userId === userId) {
              await this.redis!.del(key);
            }
          }
        }
      } catch (error) {
        this.emit('redis:error', error);
      }
    }

    this.emit('user:tokens:invalidated', userId);
  }

  /**
   * 从L1缓存获取
   */
  private getFromL1(cacheKey: string): JWTTokenData | null {
    const entry = this.l1Cache.get(cacheKey);
    
    if (!entry) {
      return null;
    }

    // 检查是否过期
    if (entry.expiresAt <= Date.now()) {
      this.l1Cache.delete(cacheKey);
      return null;
    }

    // 更新访问统计
    entry.lastAccessed = Date.now();
    entry.accessCount++;
    this.stats.l1.hits++;

    return entry.data;
  }

  /**
   * 设置L1缓存
   */
  private setL1(cacheKey: string, data: JWTTokenData, ttl?: number): void {
    // 检查容量并清理
    if (this.l1Cache.size >= this.config.l1MaxSize) {
      this.evictL1Entries();
    }

    const effectiveTTL = ttl || this.config.l1TTL;
    
    this.l1Cache.set(cacheKey, {
      data,
      expiresAt: Date.now() + effectiveTTL,
      lastAccessed: Date.now(),
      accessCount: 0,
    });

    this.stats.l1.size = this.l1Cache.size;
  }

  /**
   * 从L2缓存获取
   */
  private async getFromL2(cacheKey: string): Promise<JWTTokenData | null> {
    if (!this.redisConnected) {
      return null;
    }

    try {
      const data = await this.redis!.get(`jwt:${cacheKey}`);
      
      if (data) {
        this.stats.l2.hits++;
        return JSON.parse(data) as JWTTokenData;
      }
      
      return null;
    } catch (error) {
      this.stats.l2.errors++;
      this.emit('redis:error', error);
      return null;
    }
  }

  /**
   * 生成缓存键
   */
  private generateCacheKey(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * 检查是否需要触发异步刷新
   */
  private checkAndTriggerAsyncRefresh(
    cacheKey: string,
    token: string,
    data: JWTTokenData
  ): void {
    const entry = this.l1Cache.get(cacheKey);
    if (!entry) return;

    const remainingTTL = entry.expiresAt - Date.now();
    
    if (remainingTTL < this.config.asyncRefreshThreshold) {
      this.triggerAsyncRefresh(cacheKey, token, data);
    }
  }

  /**
   * 触发异步刷新
   */
  private triggerAsyncRefresh(
    cacheKey: string,
    token: string,
    data: JWTTokenData
  ): void {
    // 防止重复刷新
    if (this.refreshInProgress.has(cacheKey)) {
      return;
    }

    this.refreshInProgress.add(cacheKey);
    this.stats.asyncRefreshes++;

    // 异步刷新逻辑
    setImmediate(async () => {
      try {
        // 这里可以调用外部验证服务刷新令牌
        // 暂时延长TTL作为简单策略
        this.setL1(cacheKey, data);
        
        if (this.redisConnected) {
          await this.redis!.expire(`jwt:${cacheKey}`, Math.ceil(this.config.l2TTL / 1000));
        }

        this.emit('token:refreshed', cacheKey);
      } catch (error) {
        this.emit('refresh:error', error);
      } finally {
        this.refreshInProgress.delete(cacheKey);
      }
    });
  }

  /**
   * 缓存穿透保护检查
   */
  private isPenetrationProtected(cacheKey: string): boolean {
    const lastAttempt = this.penetrationProtection.get(cacheKey);
    if (!lastAttempt) return false;

    return Date.now() - lastAttempt < this.config.penetrationProtectionWindow;
  }

  /**
   * 记录穿透尝试
   */
  private recordPenetrationAttempt(cacheKey: string): void {
    this.penetrationProtection.set(cacheKey, Date.now());
    this.stats.penetrationProtection.uniqueKeys = this.penetrationProtection.size;

    // 清理旧的穿透保护记录
    if (this.penetrationProtection.size > 1000) {
      const now = Date.now();
      for (const [key, timestamp] of this.penetrationProtection.entries()) {
        if (now - timestamp > this.config.penetrationProtectionWindow) {
          this.penetrationProtection.delete(key);
        }
      }
    }
  }

  /**
   * 清理L1过期条目
   */
  private cleanupL1Cache(): void {
    const now = Date.now();
    let cleaned = 0;

    for (const [key, entry] of this.l1Cache.entries()) {
      if (entry.expiresAt <= now) {
        this.l1Cache.delete(key);
        cleaned++;
      }
    }

    if (cleaned > 0) {
      this.stats.l1.size = this.l1Cache.size;
      this.emit('cleanup', { cleaned, remaining: this.l1Cache.size });
    }
  }

  /**
   * 驱逐L1条目 (LRU策略)
   */
  private evictL1Entries(): void {
    const entriesToEvict = Math.ceil(this.config.l1MaxSize * 0.1); // 驱逐10%
    const sortedEntries = Array.from(this.l1Cache.entries())
      .sort((a, b) => a[1].lastAccessed - b[1].lastAccessed);

    for (let i = 0; i < Math.min(entriesToEvict, sortedEntries.length); i++) {
      this.l1Cache.delete(sortedEntries[i][0]);
      this.stats.l1.evictions++;
    }
  }

  /**
   * 获取统计信息
   */
  getStats(): CacheStats {
    return {
      l1: { ...this.stats.l1, size: this.l1Cache.size },
      l2: { ...this.stats.l2 },
      penetrationProtection: { ...this.stats.penetrationProtection },
      asyncRefreshes: this.stats.asyncRefreshes,
    };
  }

  /**
   * 获取缓存命中率
   */
  getHitRate(): { l1: number; l2: number; overall: number } {
    const l1Total = this.stats.l1.hits + this.stats.l1.misses;
    const l2Total = this.stats.l2.hits + this.stats.l2.misses;

    return {
      l1: l1Total > 0 ? this.stats.l1.hits / l1Total : 0,
      l2: l2Total > 0 ? this.stats.l2.hits / l2Total : 0,
      overall: l1Total > 0 ? this.stats.l1.hits / l1Total : 0,
    };
  }

  /**
   * 清空所有缓存
   */
  async clear(): Promise<void> {
    this.l1Cache.clear();
    this.stats.l1.size = 0;

    if (this.redisConnected) {
      try {
        const keys = await this.redis!.keys('jwt:*');
        if (keys.length > 0) {
          await this.redis!.del(...keys);
        }
      } catch (error) {
        this.emit('redis:error', error);
      }
    }

    this.emit('cache:cleared');
  }

  /**
   * 关闭缓存系统
   */
  async close(): Promise<void> {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }

    if (this.redis) {
      await this.redis.quit();
      this.redis = null;
      this.redisConnected = false;
    }

    this.l1Cache.clear();
    this.emit('closed');
  }
}

export default JWTCache;
