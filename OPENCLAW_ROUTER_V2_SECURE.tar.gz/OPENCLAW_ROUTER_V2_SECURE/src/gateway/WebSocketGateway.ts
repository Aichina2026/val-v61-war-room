/**
 * WebSocketGateway - WebSocket网关主类
 *
 * 集成连接池、JWT缓存、分布式限流、MessagePack序列化
 * 提供生产级WebSocket连接管理、认证、消息处理和健康监控
 *
 * @version 2.0.0
 * @author OPENCLAW Router System
 */

import { EventEmitter } from 'events';
import { createServer, Server as HTTPServer } from 'http';
import { Server as HTTPSServer } from 'https';
import WebSocket, { Server as WebSocketServer } from 'ws';
import { URL } from 'url';

import { ConnectionPool, PooledConnection, ConnectionState } from './ConnectionPool';
import { JWTCache, JWTTokenData, ValidationResult } from './JWTCache';
import { DistributedRateLimiter, RateLimitResult } from './DistributedRateLimiter';
import { MessageSerializer, Message, MessageType, MessageHeader } from './MessageSerializer';

/**
 * 网关配置
 */
export interface GatewayConfig {
  /** 监听端口 */
  port: number;
  /** 监听主机 */
  host: string;
  /** 连接池配置 */
  connectionPool: {
    minConnections: number;
    maxConnections: number;
    warmupOnStart: boolean;
  };
  /** JWT配置 */
  jwt: {
    l1TTL: number;
    l2TTL: number;
  };
  /** 限流配置 */
  rateLimit: {
    requestsPerSecond: number;
    burstSize: number;
  };
  /** 是否启用SSL */
  ssl?: boolean;
  /** SSL证书配置 */
  sslOptions?: {
    key: string;
    cert: string;
    ca?: string;
  };
  /** 心跳配置 */
  heartbeat?: {
    enabled: boolean;
    interval: number;
    timeout: number;
  };
  /** CORS配置 */
  cors?: {
    origins: string[];
    credentials: boolean;
  };
}

/**
 * 网关统计
 */
export interface GatewayStats {
  /** 运行时间 (毫秒) */
  uptime: number;
  /** 总连接数 */
  totalConnections: number;
  /** 当前活跃连接数 */
  activeConnections: number;
  /** 已认证连接数 */
  authenticatedConnections: number;
  /** 总消息数 */
  totalMessages: number;
  /** 每秒消息数 */
  messagesPerSecond: number;
  /** 错误数 */
  errorCount: number;
  /** 连接池统计 */
  connectionPool: ReturnType<ConnectionPool['getStats']>;
  /** JWT缓存统计 */
  jwtCache: ReturnType<JWTCache['getStats']>;
  /** 限流统计 */
  rateLimiter: ReturnType<DistributedRateLimiter['getStats']>;
  /** 序列化效率 */
  serializer: ReturnType<MessageSerializer['getEfficiencyMetrics']>;
}

/**
 * 客户端会话
 */
interface ClientSession {
  /** 会话ID */
  sessionId: string;
  /** 连接引用 */
  connection: PooledConnection;
  /** 认证状态 */
  isAuthenticated: boolean;
  /** 用户信息 */
  userInfo?: JWTTokenData;
  /** 连接时间 */
  connectedAt: number;
  /** 最后心跳时间 */
  lastHeartbeat: number;
  /** 订阅的频道 */
  subscriptions: Set<string>;
  /** 请求计数 */
  requestCount: number;
  /** 消息计数 */
  messageCount: number;
}

/**
 * 默认配置
 */
const DEFAULT_CONFIG: GatewayConfig = {
  port: 8080,
  host: '0.0.0.0',
  connectionPool: {
    minConnections: 10,
    maxConnections: 1000,
    warmupOnStart: true,
  },
  jwt: {
    l1TTL: 10000,
    l2TTL: 60000,
  },
  rateLimit: {
    requestsPerSecond: 100,
    burstSize: 150,
  },
  heartbeat: {
    enabled: true,
    interval: 30000,
    timeout: 60000,
  },
  cors: {
    origins: ['*'],
    credentials: true,
  },
};

/**
 * WebSocket网关
 */
export class WebSocketGateway extends EventEmitter {
  private config: GatewayConfig;
  private httpServer?: HTTPServer | HTTPSServer;
  private wss?: WebSocketServer;
  private connectionPool: ConnectionPool;
  private jwtCache: JWTCache;
  private rateLimiter: DistributedRateLimiter;
  private serializer: MessageSerializer;
  private sessions: Map<string, ClientSession>;
  private startTime: number;
  private stats: {
    totalConnections: number;
    totalMessages: number;
    errorCount: number;
    messageHistory: number[];
  };
  private heartbeatInterval?: NodeJS.Timeout;
  private isShuttingDown = false;

  constructor(config: Partial<GatewayConfig> = {}) {
    super();
    this.config = this.mergeConfig(config);
    
    // 初始化组件
    this.serializer = new MessageSerializer({
      enableCompression: true,
      compressionThreshold: 512,
      fallbackToJSON: true,
    });

    this.jwtCache = new JWTCache({
      l1TTL: this.config.jwt.l1TTL,
      l2TTL: this.config.jwt.l2TTL,
    });

    this.rateLimiter = new DistributedRateLimiter({
      requestsPerSecond: this.config.rateLimit.requestsPerSecond,
      burstSize: this.config.rateLimit.burstSize,
      distributed: false,
    });

    this.connectionPool = new ConnectionPool(
      {
        minConnections: this.config.connectionPool.minConnections,
        maxConnections: this.config.connectionPool.maxConnections,
        warmupOnStart: this.config.connectionPool.warmupOnStart,
      },
      {
        jwtCache: this.jwtCache,
        rateLimiter: this.rateLimiter,
        serializer: this.serializer,
      }
    );

    this.sessions = new Map();
    this.startTime = Date.now();
    this.stats = {
      totalConnections: 0,
      totalMessages: 0,
      errorCount: 0,
      messageHistory: [],
    };

    this.setupEventHandlers();
  }

  /**
   * 合并配置
   */
  private mergeConfig(config: Partial<GatewayConfig>): GatewayConfig {
    return {
      ...DEFAULT_CONFIG,
      ...config,
      connectionPool: { ...DEFAULT_CONFIG.connectionPool, ...config.connectionPool },
      jwt: { ...DEFAULT_CONFIG.jwt, ...config.jwt },
      rateLimit: { ...DEFAULT_CONFIG.rateLimit, ...config.rateLimit },
      heartbeat: { ...DEFAULT_CONFIG.heartbeat, ...config.heartbeat },
      cors: { ...DEFAULT_CONFIG.cors, ...config.cors },
    };
  }

  /**
   * 设置事件处理器
   */
  private setupEventHandlers(): void {
    // 连接池事件
    this.connectionPool.on('connection:created', ({ id }) => {
      this.emit('debug', { event: 'connection:created', connectionId: id });
    });

    this.connectionPool.on('connection:error', ({ id, error }) => {
      this.stats.errorCount++;
      this.emit('error', { event: 'connection:error', connectionId: id, error });
    });

    // JWT缓存事件
    this.jwtCache.on('error', (error) => {
      this.emit('error', { event: 'jwt:error', error });
    });

    // 限流器事件
    this.rateLimiter.on('sync:error', (error) => {
      this.emit('warn', { event: 'ratelimit:sync:error', error });
    });
  }

  /**
   * 启动网关
   */
  async start(): Promise<void> {
    if (this.httpServer) {
      throw new Error('Gateway is already running');
    }

    // 创建HTTP服务器
    this.httpServer = createServer();

    // 创建WebSocket服务器
    this.wss = new WebSocketServer({
      server: this.httpServer,
      perMessageDeflate: {
        zlibDeflateOptions: { chunkSize: 1024, memLevel: 7, level: 3 },
        zlibInflateOptions: { chunkSize: 10 * 1024 },
        clientNoContextTakeover: true,
        serverNoContextTakeover: true,
        serverMaxWindowBits: 10,
        concurrencyLimit: 10,
      },
      maxPayload: 100 * 1024 * 1024, // 100MB
      verifyClient: this.verifyClient.bind(this),
    });

    // 处理连接
    this.wss.on('connection', this.handleConnection.bind(this));
    this.wss.on('error', (error) => this.emit('error', { event: 'wss:error', error }));

    // 启动HTTP服务器
    await new Promise<void>((resolve, reject) => {
      this.httpServer!.listen(this.config.port, this.config.host, () => {
        this.emit('started', { host: this.config.host, port: this.config.port });
        resolve();
      });

      this.httpServer!.on('error', reject);
    });

    // 启动心跳检查
    if (this.config.heartbeat?.enabled) {
      this.startHeartbeatCheck();
    }

    // 启动统计收集
    this.startStatsCollection();

    this.emit('ready');
  }

  /**
   * 验证客户端
   */
  private verifyClient(
    info: { origin: string; secure: boolean; req: any },
    callback: (res: boolean, code?: number, message?: string) => void
  ): void {
    // CORS检查
    const origin = info.origin;
    if (this.config.cors && !this.config.cors.origins.includes('*')) {
      if (!this.config.cors.origins.includes(origin)) {
        callback(false, 403, 'Origin not allowed');
        return;
      }
    }

    // 限流检查
    const clientIp = info.req.socket.remoteAddress;
    const rateLimitResult = this.rateLimiter.check(`ip:${clientIp}`, 1);
    
    if (!rateLimitResult.allowed) {
      callback(false, 429, 'Rate limit exceeded');
      return;
    }

    callback(true);
  }

  /**
   * 处理新连接
   */
  private async handleConnection(ws: WebSocket, req: any): Promise<void> {
    const sessionId = this.generateSessionId();
    const clientIp = req.socket.remoteAddress;

    try {
      // 创建池连接
      const connection = await this.connectionPool.acquire(5000);
      connection.ws = ws; // 更新为实际WebSocket

      // 创建会话
      const session: ClientSession = {
        sessionId,
        connection,
        isAuthenticated: false,
        connectedAt: Date.now(),
        lastHeartbeat: Date.now(),
        subscriptions: new Set(),
        requestCount: 0,
        messageCount: 0,
      };

      this.sessions.set(sessionId, session);
      this.stats.totalConnections++;

      connection.state = ConnectionState.AUTHENTICATING;

      // 设置消息处理器
      ws.on('message', async (data) => {
        try {
          await this.handleMessage(session, data as Buffer);
        } catch (error) {
          this.handleError(session, error as Error);
        }
      });

      ws.on('close', (code, reason) => {
        this.handleDisconnect(session, code, reason.toString());
      });

      ws.on('error', (error) => {
        this.handleError(session, error);
      });

      ws.on('pong', () => {
        session.lastHeartbeat = Date.now();
      });

      // 发送欢迎消息
      await this.sendMessage(session, MessageType.CONTROL, {
        event: 'connected',
        sessionId,
        timestamp: Date.now(),
      });

      this.emit('client:connected', { sessionId, clientIp });

    } catch (error) {
      ws.close(1011, 'Failed to establish session');
      this.emit('error', { event: 'connection:failed', clientIp, error });
    }
  }

  /**
   * 处理消息
   */
  private async handleMessage(session: ClientSession, data: Buffer): Promise<void> {
    session.messageCount++;
    this.stats.totalMessages++;

    // 限流检查
    const rateLimitKey = session.isAuthenticated 
      ? `user:${session.userInfo?.userId}` 
      : `session:${session.sessionId}`;
    
    const rateResult = this.rateLimiter.check(rateLimitKey, 1);
    if (!rateResult.allowed) {
      await this.sendError(session, 'Rate limit exceeded', 429);
      return;
    }

    try {
      // 反序列化消息
      const message = await this.serializer.deserialize(data);
      
      // 处理不同消息类型
      switch (message.header.type) {
        case MessageType.AUTH:
          await this.handleAuth(session, message);
          break;
        case MessageType.REQUEST:
          await this.handleRequest(session, message);
          break;
        case MessageType.HEARTBEAT:
          await this.handleHeartbeat(session);
          break;
        case MessageType.CONTROL:
          await this.handleControl(session, message);
          break;
        default:
          await this.sendError(session, `Unknown message type: ${message.header.type}`, 400);
      }
    } catch (error) {
      this.handleError(session, error as Error);
    }
  }

  /**
   * 处理认证
   */
  private async handleAuth(session: ClientSession, message: Message<any>): Promise<void> {
    const { token } = message.payload;

    if (!token) {
      await this.sendError(session, 'Token is required', 401);
      return;
    }

    // 验证JWT
    const validation = await this.jwtCache.validateToken(token);

    if (!validation.valid) {
      await this.sendError(session, validation.error || 'Invalid token', 401);
      return;
    }

    // 缓存令牌
    if (validation.data) {
      await this.jwtCache.setToken(token, validation.data);
      
      session.isAuthenticated = true;
      session.userInfo = validation.data;
      session.connection.state = ConnectionState.READY;
      session.connection.auth = validation.data;

      await this.sendMessage(session, MessageType.AUTH, {
        success: true,
        userId: validation.data.userId,
        roles: validation.data.roles,
      });

      this.emit('client:authenticated', { 
        sessionId: session.sessionId, 
        userId: validation.data.userId 
      });
    }
  }

  /**
   * 处理请求
   */
  private async handleRequest(session: ClientSession, message: Message<any>): Promise<void> {
    if (!session.isAuthenticated) {
      await this.sendError(session, 'Authentication required', 401);
      return;
    }

    session.requestCount++;

    // 这里处理业务请求
    // 可以路由到具体的处理程序
    const { action, payload } = message.payload;

    this.emit('request', {
      sessionId: session.sessionId,
      userId: session.userInfo?.userId,
      action,
      payload,
      messageId: message.header.messageId,
    });

    // 发送确认
    await this.sendMessage(session, MessageType.RESPONSE, {
      ref: message.header.messageId,
      status: 'received',
    });
  }

  /**
   * 处理心跳
   */
  private async handleHeartbeat(session: ClientSession): Promise<void> {
    session.lastHeartbeat = Date.now();
    
    await this.sendMessage(session, MessageType.HEARTBEAT, {
      timestamp: Date.now(),
    });
  }

  /**
   * 处理控制消息
   */
  private async handleControl(session: ClientSession, message: Message<any>): Promise<void> {
    const { action } = message.payload;

    switch (action) {
      case 'subscribe':
        const { channel } = message.payload;
        session.subscriptions.add(channel);
        await this.sendMessage(session, MessageType.CONTROL, {
          event: 'subscribed',
          channel,
        });
        break;

      case 'unsubscribe':
        const { channel: unsubChannel } = message.payload;
        session.subscriptions.delete(unsubChannel);
        await this.sendMessage(session, MessageType.CONTROL, {
          event: 'unsubscribed',
          channel: unsubChannel,
        });
        break;

      case 'ping':
        await this.sendMessage(session, MessageType.CONTROL, {
          event: 'pong',
          timestamp: Date.now(),
        });
        break;

      default:
        await this.sendError(session, `Unknown control action: ${action}`, 400);
    }
  }

  /**
   * 处理断开连接
   */
  private handleDisconnect(session: ClientSession, code: number, reason: string): void {
    this.sessions.delete(session.sessionId);
    this.connectionPool.release(session.connection);

    this.emit('client:disconnected', {
      sessionId: session.sessionId,
      userId: session.userInfo?.userId,
      code,
      reason,
      duration: Date.now() - session.connectedAt,
    });
  }

  /**
   * 处理错误
   */
  private handleError(session: ClientSession, error: Error): void {
    this.stats.errorCount++;
    
    this.emit('error', {
      event: 'session:error',
      sessionId: session.sessionId,
      error: error.message,
    });

    // 发送错误消息
    this.sendError(session, error.message, 500).catch(() => {});
  }

  /**
   * 发送消息
   */
  async sendMessage<T>(session: ClientSession, type: MessageType, payload: T): Promise<void> {
    const message = this.serializer.createMessage(type, payload, {
      sessionId: session.sessionId,
    });

    const serialized = await this.serializer.serialize(message);
    
    if (session.connection.ws.readyState === WebSocket.OPEN) {
      session.connection.ws.send(serialized.data);
    }
  }

  /**
   * 发送错误消息
   */
  private async sendError(session: ClientSession, message: string, code: number): Promise<void> {
    await this.sendMessage(session, MessageType.ERROR, {
      code,
      message,
      timestamp: Date.now(),
    });
  }

  /**
   * 广播消息
   */
  async broadcast<T>(payload: T, channel?: string): Promise<number> {
    let count = 0;
    const promises: Promise<void>[] = [];

    for (const session of this.sessions.values()) {
      if (!session.isAuthenticated) continue;
      if (channel && !session.subscriptions.has(channel)) continue;

      promises.push(
        this.sendMessage(session, MessageType.EVENT, payload).then(() => {
          count++;
        }).catch(() => {})
      );
    }

    await Promise.all(promises);
    return count;
  }

  /**
   * 启动心跳检查
   */
  private startHeartbeatCheck(): void {
    const interval = this.config.heartbeat?.interval || 30000;
    const timeout = this.config.heartbeat?.timeout || 60000;

    this.heartbeatInterval = setInterval(() => {
      const now = Date.now();

      for (const session of this.sessions.values()) {
        if (now - session.lastHeartbeat > timeout) {
          session.connection.ws.terminate();
        } else {
          session.connection.ws.ping();
        }
      }
    }, interval);
  }

  /**
   * 启动统计收集
   */
  private startStatsCollection(): void {
    // 每秒记录消息数
    setInterval(() => {
      this.stats.messageHistory.push(this.stats.totalMessages);
      if (this.stats.messageHistory.length > 60) {
        this.stats.messageHistory.shift();
      }
    }, 1000);
  }

  /**
   * 生成会话ID
   */
  private generateSessionId(): string {
    return `sess-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 获取统计信息
   */
  getStats(): GatewayStats {
    const now = Date.now();
    const messagesInLastSecond = this.stats.messageHistory.length > 1
      ? this.stats.totalMessages - this.stats.messageHistory[this.stats.messageHistory.length - 2]
      : 0;

    const authenticatedCount = Array.from(this.sessions.values()).filter(s => s.isAuthenticated).length;

    return {
      uptime: now - this.startTime,
      totalConnections: this.stats.totalConnections,
      activeConnections: this.sessions.size,
      authenticatedConnections: authenticatedCount,
      totalMessages: this.stats.totalMessages,
      messagesPerSecond: messagesInLastSecond,
      errorCount: this.stats.errorCount,
      connectionPool: this.connectionPool.getStats(),
      jwtCache: this.jwtCache.getStats(),
      rateLimiter: this.rateLimiter.getStats(),
      serializer: this.serializer.getEfficiencyMetrics(),
    };
  }

  /**
   * 获取会话
   */
  getSession(sessionId: string): ClientSession | undefined {
    return this.sessions.get(sessionId);
  }

  /**
   * 获取所有会话
   */
  getAllSessions(): ClientSession[] {
    return Array.from(this.sessions.values());
  }

  /**
   * 优雅关闭
   */
  async shutdown(timeout: number = 30000): Promise<void> {
    this.isShuttingDown = true;

    this.emit('shutdown:start');

    // 停止接受新连接
    this.wss?.close();

    // 通知所有客户端
    const closePromises: Promise<void>[] = [];
    for (const session of this.sessions.values()) {
      closePromises.push(
        this.sendMessage(session, MessageType.CONTROL, {
          event: 'shutdown',
          message: 'Server is shutting down',
        }).catch(() => {})
      );
    }

    await Promise.all(closePromises);

    // 等待现有连接关闭
    await new Promise<void>((resolve) => {
      const timer = setTimeout(() => resolve(), timeout);
      
      const checkInterval = setInterval(() => {
        if (this.sessions.size === 0) {
          clearTimeout(timer);
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);
    });

    // 关闭组件
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }

    await this.connectionPool.close(true);
    await this.jwtCache.close();
    await this.rateLimiter.close();

    // 关闭HTTP服务器
    if (this.httpServer) {
      await new Promise<void>((resolve) => {
        this.httpServer!.close(() => resolve());
      });
    }

    this.emit('shutdown:complete');
  }
}

export default WebSocketGateway;
