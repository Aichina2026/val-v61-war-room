/**
 * MessageSerializer - MessagePack序列化器
 * 
 * 提供MessagePack序列化替代JSON，实现更小体积和更快序列化速度
 * 支持压缩和类型安全，提供JSON回退兼容
 * 
 * @version 2.0.0
 * @author OPENCLAW Router System
 */

import * as msgpack from 'msgpack-lite';
import * as zlib from 'zlib';
import { promisify } from 'util';

const gzip = promisify(zlib.gzip);
const gunzip = promisify(zlib.gunzip);

/**
 * 序列化选项
 */
export interface SerializerOptions {
  /** 启用压缩 */
  enableCompression?: boolean;
  /** 压缩阈值 (字节)，超过此大小才压缩 */
  compressionThreshold?: number;
  /** 压缩级别 (1-9) */
  compressionLevel?: number;
  /** 安全模式 - 启用后添加校验和 */
  safeMode?: boolean;
  /** JSON回退模式 - 当MessagePack失败时使用JSON */
  fallbackToJSON?: boolean;
}

/**
 * 序列化结果
 */
export interface SerializationResult {
  /** 序列化后的数据 */
  data: Buffer;
  /** 使用的格式 */
  format: 'msgpack' | 'json' | 'compressed';
  /** 原始大小 */
  originalSize: number;
  /** 序列化后大小 */
  serializedSize: number;
  /** 压缩率 (如果有压缩) */
  compressionRatio?: number;
}

/**
 * 消息类型枚举
 */
export enum MessageType {
  REQUEST = 0x01,
  RESPONSE = 0x02,
  EVENT = 0x03,
  ERROR = 0x04,
  HEARTBEAT = 0x05,
  AUTH = 0x06,
  CONTROL = 0x07,
}

/**
 * 消息头结构
 */
export interface MessageHeader {
  /** 消息类型 */
  type: MessageType;
  /** 消息ID */
  messageId: string;
  /** 时间戳 */
  timestamp: number;
  /** 版本 */
  version: number;
  /** 标志位 */
  flags: number;
}

/**
 * 完整消息结构
 */
export interface Message<T = unknown> {
  header: MessageHeader;
  payload: T;
  metadata?: Record<string, unknown>;
}

/**
 * 默认配置
 */
const DEFAULT_OPTIONS: Required<SerializerOptions> = {
  enableCompression: true,
  compressionThreshold: 1024,
  compressionLevel: 6,
  safeMode: true,
  fallbackToJSON: true,
};

/**
 * MessagePack序列化器类
 */
export class MessageSerializer {
  private options: Required<SerializerOptions>;
  private encodeStats = {
    totalEncoded: 0,
    totalBytesIn: 0,
    totalBytesOut: 0,
    compressedCount: 0,
    jsonFallbackCount: 0,
    errors: 0,
  };

  constructor(options: SerializerOptions = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
  }

  /**
   * 序列化消息
   * @param message - 要序列化的消息
   * @returns 序列化结果
   */
  async serialize<T>(message: Message<T>): Promise<SerializationResult> {
    const startTime = process.hrtime.bigint();
    
    try {
      // 首先尝试MessagePack序列化
      const packed = msgpack.encode(message);
      const originalSize = JSON.stringify(message).length;
      
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let finalData: Buffer = Buffer.from(packed as any);
      let format: SerializationResult['format'] = 'msgpack';
      let compressionRatio: number | undefined;

      // 检查是否需要压缩
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      if (this.options.enableCompression && (finalData as any).length > this.options.compressionThreshold) {
        try {
          const compressed = await gzip(finalData, { level: this.options.compressionLevel });
          
          // 只有当压缩后更小时才使用压缩
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          if ((compressed as any).length < (finalData as any).length) {
            finalData = compressed as Buffer;
            format = 'compressed';
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            compressionRatio = parseFloat(((compressed as any).length / (packed as any).length).toFixed(4));
            this.encodeStats.compressedCount++;
          }
        } catch (compressError) {
          // 压缩失败，使用原始数据
          console.warn('Compression failed, using uncompressed data:', compressError);
        }
      }

      // 更新统计
      this.encodeStats.totalEncoded++;
      this.encodeStats.totalBytesIn += originalSize;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.encodeStats.totalBytesOut += (finalData as any).length;

      return {
        data: finalData,
        format,
        originalSize,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        serializedSize: (finalData as any).length,
        compressionRatio,
      };
    } catch (error) {
      this.encodeStats.errors++;
      
      // 如果启用JSON回退，尝试使用JSON
      if (this.options.fallbackToJSON) {
        try {
          const jsonString = JSON.stringify(message);
          const buffer = Buffer.from(jsonString, 'utf-8');
          this.encodeStats.jsonFallbackCount++;
          
          return {
            data: buffer,
            format: 'json',
            originalSize: jsonString.length,
            serializedSize: jsonString.length,
          };
        } catch (jsonError) {
          throw new Error(`Serialization failed: ${error}. JSON fallback also failed: ${jsonError}`);
        }
      }
      
      throw new Error(`MessagePack serialization failed: ${error}`);
    }
  }

  /**
   * 同步序列化 (用于非异步场景)
   * @param message - 要序列化的消息
   * @returns 序列化结果 (不压缩)
   */
  serializeSync<T>(message: Message<T>): Omit<SerializationResult, 'format'> & { format: 'msgpack' | 'json' } {
    try {
      const packed = msgpack.encode(message);
      const originalSize = JSON.stringify(message).length;
      
      this.encodeStats.totalEncoded++;
      this.encodeStats.totalBytesIn += originalSize;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.encodeStats.totalBytesOut += (packed as any).length;

      return {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        data: Buffer.from(packed as any),
        format: 'msgpack',
        originalSize,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        serializedSize: (packed as any).length,
      };
    } catch (error) {
      this.encodeStats.errors++;
      
      if (this.options.fallbackToJSON) {
        const jsonString = JSON.stringify(message);
        this.encodeStats.jsonFallbackCount++;
        
        return {
          data: Buffer.from(jsonString, 'utf-8'),
          format: 'json',
          originalSize: jsonString.length,
          serializedSize: jsonString.length,
        };
      }
      
      throw new Error(`Serialization failed: ${error}`);
    }
  }

  /**
   * 反序列化消息
   * @param data - 要反序列化的数据
   * @returns 反序列化后的消息
   */
  async deserialize<T>(data: Buffer): Promise<Message<T>> {
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let unpackedData: Buffer = data as any;

      // 检测是否为gzip压缩数据 (gzip magic number: 0x1f 0x8b)
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      if ((data as any).length > 2 && data[0] === 0x1f && data[1] === 0x8b) {
        try {
          unpackedData = await gunzip(data);
        } catch (decompressError) {
          throw new Error(`Decompression failed: ${decompressError}`);
        }
      }

      // 尝试MessagePack解码
      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const decoded = msgpack.decode(unpackedData as any) as Message<T>;
        return decoded;
      } catch (msgpackError) {
        // 尝试JSON解码
        try {
          const jsonString = unpackedData.toString('utf-8');
          const decoded = JSON.parse(jsonString) as Message<T>;
          return decoded;
        } catch (jsonError) {
          throw new Error(`Deserialization failed. MessagePack: ${msgpackError}, JSON: ${jsonError}`);
        }
      }
    } catch (error) {
      this.encodeStats.errors++;
      throw error;
    }
  }

  /**
   * 同步反序列化
   * @param data - 要反序列化的数据
   * @returns 反序列化后的消息
   */
  deserializeSync<T>(data: Buffer): Message<T> {
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const buf = data as any;
      // 检测是否为gzip压缩数据
      if (buf.length > 2 && buf[0] === 0x1f && buf[1] === 0x8b) {
        throw new Error('Compressed data requires async deserialization. Use deserialize() instead.');
      }

      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return msgpack.decode(buf) as Message<T>;
      } catch (msgpackError) {
        try {
          const jsonString = buf.toString('utf-8');
          return JSON.parse(jsonString) as Message<T>;
        } catch (jsonError) {
          throw new Error(`Deserialization failed. MessagePack: ${msgpackError}, JSON: ${jsonError}`);
        }
      }
    } catch (error) {
      this.encodeStats.errors++;
      throw error;
    }
  }

  /**
   * 创建标准消息
   * @param type - 消息类型
   * @param payload - 消息负载
   * @param metadata - 可选元数据
   * @returns 消息对象
   */
  createMessage<T>(
    type: MessageType,
    payload: T,
    metadata?: Record<string, unknown>
  ): Message<T> {
    return {
      header: {
        type,
        messageId: this.generateMessageId(),
        timestamp: Date.now(),
        version: 2,
        flags: 0,
      },
      payload,
      metadata,
    };
  }

  /**
   * 生成唯一消息ID
   * @returns 消息ID
   */
  private generateMessageId(): string {
    return `${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 获取编码统计信息
   * @returns 统计信息
   */
  getStats(): typeof this.encodeStats {
    return { ...this.encodeStats };
  }

  /**
   * 重置统计信息
   */
  resetStats(): void {
    this.encodeStats = {
      totalEncoded: 0,
      totalBytesIn: 0,
      totalBytesOut: 0,
      compressedCount: 0,
      jsonFallbackCount: 0,
      errors: 0,
    };
  }

  /**
   * 计算序列化效率
   * @returns 效率统计
   */
  getEfficiencyMetrics(): {
    averageCompressionRatio: number;
    spaceSavingsPercent: number;
    msgpackUsageRate: number;
    compressionRate: number;
    errorRate: number;
  } {
    const total = this.encodeStats.totalEncoded;
    if (total === 0) {
      return {
        averageCompressionRatio: 1,
        spaceSavingsPercent: 0,
        msgpackUsageRate: 0,
        compressionRate: 0,
        errorRate: 0,
      };
    }

    const spaceSavings = this.encodeStats.totalBytesIn > 0
      ? (this.encodeStats.totalBytesIn - this.encodeStats.totalBytesOut) / this.encodeStats.totalBytesIn
      : 0;

    return {
      averageCompressionRatio: this.encodeStats.totalBytesIn > 0
        ? this.encodeStats.totalBytesOut / this.encodeStats.totalBytesIn
        : 1,
      spaceSavingsPercent: parseFloat((spaceSavings * 100).toFixed(2)),
      msgpackUsageRate: parseFloat(((total - this.encodeStats.jsonFallbackCount) / total * 100).toFixed(2)),
      compressionRate: parseFloat((this.encodeStats.compressedCount / total * 100).toFixed(2)),
      errorRate: parseFloat((this.encodeStats.errors / total * 100).toFixed(2)),
    };
  }
}

// 导出默认实例
export const defaultSerializer = new MessageSerializer();

export default MessageSerializer;
