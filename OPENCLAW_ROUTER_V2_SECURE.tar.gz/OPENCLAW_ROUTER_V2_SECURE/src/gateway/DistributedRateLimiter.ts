/**
 * DistributedRateLimiter - 分布式令牌桶限流器
 * 
 * 提供本地令牌桶算法实现，支持本地快速决策和异步批量同步
 * 实现分布式配额检查和突发流量处理
 * 
 * @version 2.0.0
 * @author OPENCLAW Router System
 */

import Redis, { RedisOptions } from 'ioredis';
import { EventEmitter } from 'events';

/**
 * 限流器配置
 */
export interface RateLimiterConfig {
  /** 每秒请求数 */
  requestsPerSecond: number;
  /** 突发容量 */
  burstSize: number;
  /** 令牌桶填充间隔 (毫秒) */
  refillInterval: number;
  /** 分布式同步间隔 (毫秒) */
  syncInterval: number;
  /** 最大等待时间 (毫秒) */
  maxWaitTime: number;
  /** 是否启用分布式模式 */
  distributed: boolean;
  /** Redis配置 */
  redis?: RedisOptions | Redis;
  /** 限流键前缀 */
  keyPrefix: string;
  /** 批量同步阈值 */
  batchSyncThreshold: number;
}

/**
 * 令牌桶状态
 */
interface TokenBucket {
  /** 当前令牌数 */
  tokens: number;
  /** 最后更新时间 */
  lastRefill: number;
  /** 等待队列 */
  waitQueue: Array<{
    resolve: (value: boolean) => void;
    reject: (reason: Error) => void;
    tokens: number;
    timeout: NodeJS.Timeout;
  }>;
}

/**
 * 限流决策结果
 */
export interface RateLimitResult {
  /** 是否允许 */
  allowed: boolean;
  /** 剩余令牌数 */
  remainingTokens: number;
  /** 重置时间戳 */
  resetTime: number;
  /** 等待时间 (毫秒) */
  waitTime?: number;
  /** 限流键 */
  key: string;
  /** 决策来源 */
  source: 'local' | 'distributed' | 'wait';
}

/**
 * 限流统计
 */
export interface RateLimitStats {
  totalRequests: number;
  allowedRequests: number;
  rejectedRequests: number;
  waitedRequests: number;
  localDecisions: number;
  distributedDecisions: number;
  syncOperations: number;
  syncErrors: number;
}

/**
 * 分布式配额信息
 */
interface DistributedQuota {
  /** 全局已使用配额 */
  globalUsed: number;
  /** 全局配额限制 */
  globalLimit: number;
  /** 上次同步时间 */
  lastSync: number;
  /** 节点配额分配 */
  nodeAllocation: number;
}

/**
 * 默认配置
 */
const DEFAULT_CONFIG: RateLimiterConfig = {
  requestsPerSecond: 100,
  burstSize: 150,
  refillInterval: 100,
  syncInterval: 1000,
  maxWaitTime: 5000,
  distributed: false,
  keyPrefix: 'ratelimit:',
  batchSyncThreshold: 10,
};

/**
 * 分布式令牌桶限流器
 */
export class DistributedRateLimiter extends EventEmitter {
  private config: RateLimiterConfig;
  private buckets: Map<string, TokenBucket>;
  private redis: Redis | null = null;
  private redisConnected = false;
  private stats: RateLimitStats;
  private syncTimer: NodeJS.Timeout | null = null;
  private pendingSyncs: Map<string, number> = new Map();
  private distributedQuotas: Map<string, DistributedQuota> = new Map();
  private nodeId: string;

  constructor(config: Partial<RateLimiterConfig> = {}) {
    super();
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.buckets = new Map();
    this.stats = {
      totalRequests: 0,
      allowedRequests: 0,
      rejectedRequests: 0,
      waitedRequests: 0,
      localDecisions: 0,
      distributedDecisions: 0,
      syncOperations: 0,
      syncErrors: 0,
    };
    this.nodeId = this.generateNodeId();

    this.initRedis();
    this.startSyncInterval();
    this.startRefillInterval();
  }

  /**
   * 生成节点ID
   */
  private generateNodeId(): string {
    return `${process.pid}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 初始化Redis连接
   */
  private initRedis(): void {
    if (this.config.distributed && this.config.redis) {
      if (this.config.redis instanceof Redis) {
        this.redis = this.config.redis;
      } else {
        this.redis = new Redis(this.config.redis);
      }

      this.redis.on('connect', () => {
        this.redisConnected = true;
        this.emit('redis:connect');
      });

      this.redis.on('error', (err) => {
        this.redisConnected = false;
        this.emit('redis:error', err);
      });

      this.redis.on('close', () => {
        this.redisConnected = false;
        this.emit('redis:close');
      });
    }
  }

  /**
   * 启动令牌填充定时器
   */
  private startRefillInterval(): void {
    setInterval(() => {
      this.refillAllBuckets();
    }, this.config.refillInterval);
  }

  /**
   * 启动同步定时器
   */
  private startSyncInterval(): void {
    if (!this.config.distributed) return;

    this.syncTimer = setInterval(() => {
      this.batchSyncToRedis();
    }, this.config.syncInterval);
  }

  /**
   * 检查限流 (非阻塞)
   * @param key - 限流键 (如用户ID、IP地址)
   * @param tokens - 需要的令牌数 (默认1)
   * @returns 限流结果
   */
  check(key: string, tokens: number = 1): RateLimitResult {
    this.stats.totalRequests++;
    const bucket = this.getOrCreateBucket(key);

    // 本地快速决策
    const now = Date.now();
    this.refillBucket(bucket, now);

    if (bucket.tokens >= tokens) {
      bucket.tokens -= tokens;
      this.recordPendingSync(key, tokens);
      this.stats.allowedRequests++;
      this.stats.localDecisions++;

      return {
        allowed: true,
        remainingTokens: Math.floor(bucket.tokens),
        resetTime: now + this.calculateResetTime(bucket),
        key,
        source: 'local',
      };
    }

    // 本地令牌不足，检查分布式配额
    if (this.config.distributed && this.redisConnected) {
      const distributedResult = this.checkDistributedQuota(key, tokens);
      if (distributedResult) {
        this.stats.allowedRequests++;
        this.stats.distributedDecisions++;
        return distributedResult;
      }
    }

    this.stats.rejectedRequests++;
    return {
      allowed: false,
      remainingTokens: Math.floor(bucket.tokens),
      resetTime: now + this.calculateResetTime(bucket),
      key,
      source: 'local',
    };
  }

  /**
   * 等待获取令牌 (阻塞式)
   * @param key - 限流键
   * @param tokens - 需要的令牌数
   * @param maxWaitTime - 最大等待时间
   * @returns 是否成功获取
   */
  async acquire(
    key: string,
    tokens: number = 1,
    maxWaitTime?: number
  ): Promise<RateLimitResult> {
    const result = this.check(key, tokens);
    
    if (result.allowed) {
      return result;
    }

    const bucket = this.getOrCreateBucket(key);
    const waitTime = maxWaitTime || this.config.maxWaitTime;

    // 尝试等待
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        // 从等待队列移除
        bucket.waitQueue = bucket.waitQueue.filter(w => w.timeout !== timeout);
        this.stats.rejectedRequests++;
        resolve({
          allowed: false,
          remainingTokens: Math.floor(bucket.tokens),
          resetTime: Date.now() + this.calculateResetTime(bucket),
          waitTime,
          key,
          source: 'wait',
        });
      }, waitTime);

      bucket.waitQueue.push({
        resolve: (allowed) => {
          clearTimeout(timeout);
          if (allowed) {
            this.stats.allowedRequests++;
            this.stats.waitedRequests++;
          } else {
            this.stats.rejectedRequests++;
          }
          resolve({
            allowed,
            remainingTokens: Math.floor(bucket.tokens),
            resetTime: Date.now() + this.calculateResetTime(bucket),
            key,
            source: 'wait',
          });
        },
        reject,
        tokens,
        timeout,
      });

      this.stats.waitedRequests++;
    });
  }

  /**
   * 尝试消费令牌
   * @param key - 限流键
   * @param tokens - 需要的令牌数
   * @returns 是否成功
   */
  tryConsume(key: string, tokens: number = 1): boolean {
    return this.check(key, tokens).allowed;
  }

  /**
   * 获取或创建令牌桶
   */
  private getOrCreateBucket(key: string): TokenBucket {
    let bucket = this.buckets.get(key);
    
    if (!bucket) {
      bucket = {
        tokens: this.config.burstSize,
        lastRefill: Date.now(),
        waitQueue: [],
      };
      this.buckets.set(key, bucket);
    }

    return bucket;
  }

  /**
   * 填充单个令牌桶
   */
  private refillBucket(bucket: TokenBucket, now: number): void {
    const timePassed = now - bucket.lastRefill;
    const tokensToAdd = (timePassed / 1000) * this.config.requestsPerSecond;
    
    bucket.tokens = Math.min(
      this.config.burstSize,
      bucket.tokens + tokensToAdd
    );
    bucket.lastRefill = now;

    // 处理等待队列
    this.processWaitQueue(bucket);
  }

  /**
   * 填充所有令牌桶
   */
  private refillAllBuckets(): void {
    const now = Date.now();
    
    for (const bucket of this.buckets.values()) {
      this.refillBucket(bucket, now);
    }
  }

  /**
   * 处理等待队列
   */
  private processWaitQueue(bucket: TokenBucket): void {
    while (bucket.waitQueue.length > 0 && bucket.tokens > 0) {
      const waiter = bucket.waitQueue[0];
      
      if (bucket.tokens >= waiter.tokens) {
        bucket.tokens -= waiter.tokens;
        bucket.waitQueue.shift();
        clearTimeout(waiter.timeout);
        waiter.resolve(true);
      } else {
        break;
      }
    }
  }

  /**
   * 记录待同步的请求
   */
  private recordPendingSync(key: string, tokens: number): void {
    if (!this.config.distributed) return;

    const current = this.pendingSyncs.get(key) || 0;
    this.pendingSyncs.set(key, current + tokens);

    // 如果超过阈值，立即同步
    if (this.pendingSyncs.size >= this.config.batchSyncThreshold) {
      setImmediate(() => this.batchSyncToRedis());
    }
  }

  /**
   * 批量同步到Redis
   */
  private async batchSyncToRedis(): Promise<void> {
    if (!this.redisConnected || this.pendingSyncs.size === 0) return;

    const syncData = new Map(this.pendingSyncs);
    this.pendingSyncs.clear();

    try {
      const pipeline = this.redis!.pipeline();
      
      for (const [key, tokens] of syncData) {
        const redisKey = `${this.config.keyPrefix}${key}`;
        pipeline.hincrbyfloat(redisKey, 'consumed', tokens);
        pipeline.hset(redisKey, 'lastUpdate', Date.now().toString());
        pipeline.expire(redisKey, 3600); // 1小时过期
      }

      await pipeline.exec();
      this.stats.syncOperations++;
    } catch (error) {
      this.stats.syncErrors++;
      this.emit('sync:error', error);
      
      // 恢复待同步数据
      for (const [key, tokens] of syncData) {
        const current = this.pendingSyncs.get(key) || 0;
        this.pendingSyncs.set(key, current + tokens);
      }
    }
  }

  /**
   * 检查分布式配额
   */
  private checkDistributedQuota(key: string, tokens: number): RateLimitResult | null {
    const quota = this.distributedQuotas.get(key);
    const now = Date.now();

    if (!quota || now - quota.lastSync > this.config.syncInterval) {
      // 异步获取最新配额
      this.refreshDistributedQuota(key);
      return null;
    }

    const remainingGlobal = quota.globalLimit - quota.globalUsed;
    
    if (remainingGlobal >= tokens) {
      quota.globalUsed += tokens;
      
      return {
        allowed: true,
        remainingTokens: Math.floor(remainingGlobal - tokens),
        resetTime: now + 1000,
        key,
        source: 'distributed',
      };
    }

    return null;
  }

  /**
   * 刷新分布式配额
   */
  private async refreshDistributedQuota(key: string): Promise<void> {
    if (!this.redisConnected) return;

    try {
      const redisKey = `${this.config.keyPrefix}${key}`;
      const data = await this.redis!.hgetall(redisKey);

      const quota: DistributedQuota = {
        globalUsed: parseFloat(data.consumed || '0'),
        globalLimit: this.config.requestsPerSecond * 60, // 1分钟配额
        lastSync: Date.now(),
        nodeAllocation: this.config.requestsPerSecond,
      };

      this.distributedQuotas.set(key, quota);
    } catch (error) {
      this.emit('quota:refresh:error', error);
    }
  }

  /**
   * 计算重置时间
   */
  private calculateResetTime(bucket: TokenBucket): number {
    const tokensNeeded = this.config.burstSize - bucket.tokens;
    return (tokensNeeded / this.config.requestsPerSecond) * 1000;
  }

  /**
   * 获取限流键的当前状态
   */
  getBucketStatus(key: string): {
    tokens: number;
    resetTime: number;
    queueLength: number;
  } | null {
    const bucket = this.buckets.get(key);
    if (!bucket) return null;

    return {
      tokens: Math.floor(bucket.tokens),
      resetTime: Date.now() + this.calculateResetTime(bucket),
      queueLength: bucket.waitQueue.length,
    };
  }

  /**
   * 重置限流键
   */
  reset(key: string): void {
    const bucket = this.buckets.get(key);
    if (bucket) {
      // 拒绝所有等待中的请求
      for (const waiter of bucket.waitQueue) {
        clearTimeout(waiter.timeout);
        waiter.resolve(false);
      }
      bucket.waitQueue = [];
    }

    this.buckets.delete(key);
    this.distributedQuotas.delete(key);
    this.pendingSyncs.delete(key);
  }

  /**
   * 获取统计信息
   */
  getStats(): RateLimitStats {
    return { ...this.stats };
  }

  /**
   * 获取限流摘要
   */
  getSummary(): {
    totalBuckets: number;
    totalWaitQueue: number;
    pendingSyncs: number;
    hitRate: number;
    waitRate: number;
  } {
    let totalWaitQueue = 0;
    for (const bucket of this.buckets.values()) {
      totalWaitQueue += bucket.waitQueue.length;
    }

    const total = this.stats.totalRequests;
    return {
      totalBuckets: this.buckets.size,
      totalWaitQueue,
      pendingSyncs: this.pendingSyncs.size,
      hitRate: total > 0 ? this.stats.allowedRequests / total : 0,
      waitRate: total > 0 ? this.stats.waitedRequests / total : 0,
    };
  }

  /**
   * 关闭限流器
   */
  async close(): Promise<void> {
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
      this.syncTimer = null;
    }

    // 最后同步
    await this.batchSyncToRedis();

    // 清理等待队列
    for (const bucket of this.buckets.values()) {
      for (const waiter of bucket.waitQueue) {
        clearTimeout(waiter.timeout);
        waiter.resolve(false);
      }
    }

    this.buckets.clear();
    this.pendingSyncs.clear();
    this.distributedQuotas.clear();

    if (this.redis) {
      await this.redis.quit();
      this.redis = null;
    }

    this.emit('closed');
  }
}

export default DistributedRateLimiter;
