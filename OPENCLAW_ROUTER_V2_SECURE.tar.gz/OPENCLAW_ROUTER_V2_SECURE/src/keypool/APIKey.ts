/**
 * @fileoverview API Key状态管理类
 * @module keypool/APIKey
 * @version 2.0.0
 * 
 * @description
 * API密钥的状态管理实现，包含使用计数追踪、失败次数追踪、
 * 速率限制监控和健康状态管理。
 * 
 * @performance
 * - 状态更新延迟: <1μs
 * - 内存占用: ~256 bytes/实例
 * 
 * @example
 * ```typescript
 * const key = new APIKeyImpl('key-1', 'sk-xxx', 'gpt-4');
 * if (key.isAvailable()) {
 *   key.markUsed();
 *   // 使用key进行API调用
 *   key.updateHealth(true, 150);
 * }
 * ```
 */

import { AtomicInt32, AtomicInt64 } from './AtomicInt32';

/**
 * API Key状态接口
 * @interface APIKeyState
 */
export interface APIKeyState {
  /** 使用计数 */
  usageCount: number;
  /** 失败计数 */
  failureCount: number;
  /** 最后使用时间戳 */
  lastUsed: number;
  /** 速率限制剩余次数 */
  rateLimitRemaining: number;
  /** 速率限制重置时间 */
  rateLimitResetTime: number;
  /** 平均延迟(ms) */
  averageLatency: number;
  /** 是否可用 */
  available: boolean;
  /** 连续失败次数 */
  consecutiveFailures: number;
}

/**
 * 健康检查配置
 * @interface HealthCheckConfig
 */
export interface HealthCheckConfig {
  /** 最大连续失败次数 */
  maxConsecutiveFailures: number;
  /** 最大失败率(0-1) */
  maxFailureRate: number;
  /** 最大平均延迟(ms) */
  maxAverageLatency: number;
  /** 最小速率限制剩余 */
  minRateLimitRemaining: number;
  /** 失败率计算窗口大小 */
  failureRateWindow: number;
}

/**
 * 默认健康检查配置
 */
export const DEFAULT_HEALTH_CONFIG: HealthCheckConfig = {
  maxConsecutiveFailures: 3,
  maxFailureRate: 0.5,
  maxAverageLatency: 5000,
  minRateLimitRemaining: 10,
  failureRateWindow: 100
};

/**
 * API Key实现类
 * @class APIKeyImpl
 * @implements APIKey
 */
export class APIKeyImpl {
  /** 密钥ID */
  readonly id: string;
  /** 密钥值 */
  readonly key: string;
  /** 关联模型ID */
  readonly modelId: string;
  /** 创建时间 */
  readonly createdAt: number;

  // 原子计数器
  private _usageCount: AtomicInt64;
  private _failureCount: AtomicInt64;
  private _lastUsed: AtomicInt64;
  private _rateLimitRemaining: AtomicInt32;
  private _rateLimitResetTime: AtomicInt64;
  private _consecutiveFailures: AtomicInt32;
  private _available: AtomicInt32;

  // 延迟历史 (用于计算平均延迟)
  private latencyHistory: number[] = [];
  private latencyHistoryLock = false;

  // 健康检查配置
  private healthConfig: HealthCheckConfig;

  /**
   * 创建API Key实例
   * @constructor
   * @param {string} id - 密钥ID
   * @param {string} key - 密钥值
   * @param {string} [modelId='default'] - 关联模型ID
   * @param {HealthCheckConfig} [healthConfig=DEFAULT_HEALTH_CONFIG] - 健康检查配置
   */
  constructor(
    id: string,
    key: string,
    modelId: string = 'default',
    healthConfig: HealthCheckConfig = DEFAULT_HEALTH_CONFIG
  ) {
    this.id = id;
    this.key = key;
    this.modelId = modelId;
    this.createdAt = Date.now();
    this.healthConfig = { ...DEFAULT_HEALTH_CONFIG, ...healthConfig };

    // 初始化原子计数器
    this._usageCount = new AtomicInt64(0n);
    this._failureCount = new AtomicInt64(0n);
    this._lastUsed = new AtomicInt64(0n);
    this._rateLimitRemaining = new AtomicInt32(1000);
    this._rateLimitResetTime = new AtomicInt64(BigInt(Date.now() + 60000));
    this._consecutiveFailures = new AtomicInt32(0);
    this._available = new AtomicInt32(1);
  }

  /**
   * 获取使用计数
   * @returns {number} 使用次数
   */
  get usageCount(): number {
    return Number(this._usageCount.load());
  }

  /**
   * 获取失败计数
   * @returns {number} 失败次数
   */
  get failureCount(): number {
    return Number(this._failureCount.load());
  }

  /**
   * 获取最后使用时间
   * @returns {number} 时间戳
   */
  get lastUsed(): number {
    return Number(this._lastUsed.load());
  }

  /**
   * 获取速率限制剩余
   * @returns {number} 剩余次数
   */
  get rateLimitRemaining(): number {
    return this._rateLimitRemaining.load();
  }

  /**
   * 获取速率限制重置时间
   * @returns {number} 时间戳
   */
  get rateLimitResetTime(): number {
    return Number(this._rateLimitResetTime.load());
  }

  /**
   * 检查是否可用
   * @returns {boolean} 是否可用
   * 
   * @description
   * 综合检查以下因素:
   * 1. 是否被显式标记为不可用
   * 2. 连续失败次数是否超限
   * 3. 失败率是否过高
   * 4. 速率限制是否充足
   * 5. 平均延迟是否过高
   */
  isAvailable(): boolean {
    // 1. 显式不可用
    if (this._available.load() === 0) {
      return false;
    }

    // 2. 连续失败检查
    if (this._consecutiveFailures.load() >= this.healthConfig.maxConsecutiveFailures) {
      return false;
    }

    // 3. 失败率检查
    const total = this.usageCount + this.failureCount;
    if (total > 0) {
      const failureRate = this.failureCount / total;
      if (failureRate > this.healthConfig.maxFailureRate) {
        return false;
      }
    }

    // 4. 速率限制检查
    if (this.rateLimitRemaining < this.healthConfig.minRateLimitRemaining) {
      // 检查是否已重置
      if (Date.now() > this.rateLimitResetTime) {
        this._rateLimitRemaining.store(1000);
      } else {
        return false;
      }
    }

    // 5. 延迟检查
    if (this.averageLatency > this.healthConfig.maxAverageLatency) {
      return false;
    }

    return true;
  }

  /**
   * 标记为已使用
   * @description 原子更新使用计数和最后使用时间
   */
  markUsed(): void {
    this._usageCount.incrementAndGet();
    this._lastUsed.store(BigInt(Date.now()));
    this._rateLimitRemaining.sub(1);
  }

  /**
   * 标记为失败
   * @param {Error} [error] - 错误对象
   */
  markFailed(error?: Error): void {
    this._failureCount.incrementAndGet();
    this._consecutiveFailures.incrementAndGet();

    // 检查是否需要标记为不可用
    if (this._consecutiveFailures.load() >= this.healthConfig.maxConsecutiveFailures) {
      this._available.store(0);
    }

    // 解析速率限制错误
    if (error?.message?.includes('rate limit')) {
      this._rateLimitRemaining.store(0);
      this._rateLimitResetTime.store(BigInt(Date.now() + 60000));
    }
  }

  /**
   * 重置状态
   * @description 重置所有计数器和状态为初始值
   */
  reset(): void {
    this._consecutiveFailures.store(0);
    this._available.store(1);
    this._rateLimitRemaining.store(1000);
    this._rateLimitResetTime.store(BigInt(Date.now() + 60000));
    
    // 清除延迟历史
    while (this.latencyHistoryLock) {
      // 自旋等待
    }
    this.latencyHistoryLock = true;
    this.latencyHistory = [];
    this.latencyHistoryLock = false;
  }

  /**
   * 更新健康状态
   * @param {boolean} healthy - 是否健康
   * @param {number} latency - 延迟(ms)
   */
  updateHealth(healthy: boolean, latency: number): void {
    if (healthy) {
      // 成功时重置连续失败计数
      this._consecutiveFailures.store(0);
      
      // 添加到延迟历史
      this.addLatency(latency);
    } else {
      this._consecutiveFailures.incrementAndGet();
      
      // 检查是否需要标记为不可用
      if (this._consecutiveFailures.load() >= this.healthConfig.maxConsecutiveFailures) {
        this._available.store(0);
      }
    }
  }

  /**
   * 更新速率限制信息
   * @param {number} remaining - 剩余次数
   * @param {number} resetTime - 重置时间戳
   */
  updateRateLimit(remaining: number, resetTime: number): void {
    this._rateLimitRemaining.store(remaining);
    this._rateLimitResetTime.store(BigInt(resetTime));
  }

  /**
   * 设置可用性
   * @param {boolean} available - 是否可用
   */
  setAvailable(available: boolean): void {
    this._available.store(available ? 1 : 0);
  }

  /**
   * 获取平均延迟
   * @returns {number} 平均延迟(ms)
   */
  get averageLatency(): number {
    while (this.latencyHistoryLock) {
      // 自旋等待
    }
    
    if (this.latencyHistory.length === 0) {
      return 0;
    }
    
    const sum = this.latencyHistory.reduce((a, b) => a + b, 0);
    return sum / this.latencyHistory.length;
  }

  /**
   * 获取连续失败次数
   * @returns {number} 连续失败次数
   */
  get consecutiveFailures(): number {
    return this._consecutiveFailures.load();
  }

  /**
   * 获取失败率
   * @returns {number} 失败率(0-1)
   */
  get failureRate(): number {
    const total = this.usageCount + this.failureCount;
    if (total === 0) return 0;
    return this.failureCount / total;
  }

  /**
   * 获取完整状态
   * @returns {APIKeyState} 当前状态
   */
  getState(): APIKeyState {
    return {
      usageCount: this.usageCount,
      failureCount: this.failureCount,
      lastUsed: this.lastUsed,
      rateLimitRemaining: this.rateLimitRemaining,
      rateLimitResetTime: this.rateLimitResetTime,
      averageLatency: this.averageLatency,
      available: this.isAvailable(),
      consecutiveFailures: this.consecutiveFailures
    };
  }

  /**
   * 序列化为JSON
   * @returns {object} 纯对象
   */
  toJSON(): object {
    return {
      id: this.id,
      modelId: this.modelId,
      createdAt: this.createdAt,
      ...this.getState()
    };
  }

  /**
   * 添加延迟记录
   * @private
   * @param {number} latency - 延迟值
   */
  private addLatency(latency: number): void {
    while (this.latencyHistoryLock) {
      // 自旋等待
    }
    
    this.latencyHistoryLock = true;
    try {
      this.latencyHistory.push(latency);
      // 限制历史大小
      if (this.latencyHistory.length > this.healthConfig.failureRateWindow) {
        this.latencyHistory.shift();
      }
    } finally {
      this.latencyHistoryLock = false;
    }
  }
}

export default APIKeyImpl;
