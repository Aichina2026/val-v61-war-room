/**
 * @fileoverview 自适应健康检查器
 * @module keypool/AdaptiveHealthChecker
 * @version 2.0.0
 * 
 * @description
 * 自适应健康检查机制，根据Key的历史表现动态调整检查间隔，
 * 支持并行健康检查和批量状态同步。
 * 
 * @performance
 * - 基础检查间隔: 5s
 * - 故障时最短间隔: 1s
 * - 并行检查并发数: 5
 * - 批量同步延迟: 100ms
 * 
 * @example
 * ```typescript
 * const checker = new AdaptiveHealthChecker(keys, {
 *   endpoint: 'https://api.example.com/health',
 *   checkIntervalMs: 5000
 * });
 * checker.start();
 * ```
 */

import { EventEmitter } from 'events';
import { APIKeyImpl } from './APIKey';

/**
 * 健康检查配置
 * @interface AdaptiveHealthCheckConfig
 */
export interface AdaptiveHealthCheckConfig {
  /** 基础检查间隔(ms) */
  checkIntervalMs: number;
  /** 最大并发检查数 */
  maxConcurrency: number;
  /** 健康检查超时(ms) */
  timeoutMs: number;
  /** 检查端点URL */
  endpoint: string;
  /** 自适应因子(0-1) */
  adaptiveFactor: number;
  /** 最小检查间隔(ms) */
  minIntervalMs: number;
  /** 批量同步间隔(ms) */
  batchSyncIntervalMs: number;
}

/**
 * 默认配置
 */
export const DEFAULT_ADAPTIVE_CONFIG: AdaptiveHealthCheckConfig = {
  checkIntervalMs: 5000,
  maxConcurrency: 5,
  timeoutMs: 5000,
  endpoint: '',
  adaptiveFactor: 0.5,
  minIntervalMs: 1000,
  batchSyncIntervalMs: 100
};

/**
 * 健康检查结果
 * @interface HealthCheckResult
 */
export interface HealthCheckResult {
  /** Key ID */
  keyId: string;
  /** 是否健康 */
  healthy: boolean;
  /** 延迟(ms) */
  latency: number;
  /** 错误信息 */
  error?: string;
  /** 速率限制剩余 */
  rateLimitRemaining?: number;
  /** 速率限制重置时间 */
  rateLimitResetTime?: number;
  /** 检查时间戳 */
  timestamp: number;
}

/**
 * 信号量实现
 * @class Semaphore
 */
class Semaphore {
  private permits: number;
  private waiters: (() => void)[] = [];

  constructor(permits: number) {
    this.permits = permits;
  }

  async acquire(): Promise<void> {
    if (this.permits > 0) {
      this.permits--;
      return;
    }

    return new Promise(resolve => {
      this.waiters.push(resolve);
    });
  }

  release(): void {
    if (this.waiters.length > 0) {
      const waiter = this.waiters.shift();
      waiter?.();
    } else {
      this.permits++;
    }
  }
}

/**
 * 自适应健康检查器
 * @class AdaptiveHealthChecker
 * @extends EventEmitter
 */
export class AdaptiveHealthChecker extends EventEmitter {
  /** 被检查的Keys */
  private keys: APIKeyImpl[];
  /** 配置 */
  private config: AdaptiveHealthCheckConfig;
  /** 运行状态 */
  private isRunning: boolean = false;
  /** 当前检查间隔 */
  private currentInterval: number;
  /** 连续失败计数 */
  private consecutiveFailures: number = 0;
  /** 信号量控制并发 */
  private semaphore: Semaphore;
  /** 待同步队列 */
  private syncQueue: HealthCheckResult[] = [];
  /** 同步定时器 */
  private syncTimer: NodeJS.Timeout | null = null;
  /** 检查定时器 */
  private checkTimer: NodeJS.Timeout | null = null;
  /** 统计信息 */
  private stats = {
    totalChecks: 0,
    successfulChecks: 0,
    failedChecks: 0,
    averageLatency: 0
  };

  /**
   * 创建健康检查器
   * @constructor
   * @param {APIKeyImpl[]} keys - 要检查的Keys
   * @param {Partial<AdaptiveHealthCheckConfig>} [config={}] - 配置
   */
  constructor(
    keys: APIKeyImpl[],
    config: Partial<AdaptiveHealthCheckConfig> = {}
  ) {
    super();
    this.keys = keys;
    this.config = { ...DEFAULT_ADAPTIVE_CONFIG, ...config };
    this.currentInterval = this.config.checkIntervalMs;
    this.semaphore = new Semaphore(this.config.maxConcurrency);
  }

  /**
   * 启动健康检查
   */
  start(): void {
    if (this.isRunning) return;

    this.isRunning = true;
    this.emit('started');

    // 启动批量同步
    this.startBatchSync();

    // 执行第一次检查
    this.performCheck();
  }

  /**
   * 停止健康检查
   */
  stop(): void {
    this.isRunning = false;

    if (this.checkTimer) {
      clearTimeout(this.checkTimer);
      this.checkTimer = null;
    }

    if (this.syncTimer) {
      clearInterval(this.syncTimer);
      this.syncTimer = null;
    }

    this.emit('stopped');
  }

  /**
   * 立即执行一次检查
   * @returns {Promise<HealthCheckResult[]>} 检查结果
   */
  async checkNow(): Promise<HealthCheckResult[]> {
    return this.performCheck();
  }

  /**
   * 获取当前检查间隔
   * @returns {number} 间隔(ms)
   */
  getCurrentInterval(): number {
    return this.currentInterval;
  }

  /**
   * 获取统计信息
   * @returns {object} 统计信息
   */
  getStats() {
    return { ...this.stats };
  }

  /**
   * 添加Key到检查列表
   * @param {APIKeyImpl} key - 要添加的Key
   */
  addKey(key: APIKeyImpl): void {
    this.keys.push(key);
    this.emit('keyAdded', { keyId: key.id });
  }

  /**
   * 从检查列表移除Key
   * @param {string} keyId - Key ID
   */
  removeKey(keyId: string): void {
    const index = this.keys.findIndex(k => k.id === keyId);
    if (index !== -1) {
      this.keys.splice(index, 1);
      this.emit('keyRemoved', { keyId });
    }
  }

  /**
   * 执行健康检查
   * @private
   * @returns {Promise<HealthCheckResult[]>} 检查结果
   */
  private async performCheck(): Promise<HealthCheckResult[]> {
    if (!this.isRunning) return [];

    const startTime = Date.now();
    const results: HealthCheckResult[] = [];

    // 并行检查所有Keys
    const checkPromises = this.keys.map(async key => {
      await this.semaphore.acquire();
      try {
        const result = await this.checkKey(key);
        results.push(result);
        this.queueForSync(result);
        return result;
      } finally {
        this.semaphore.release();
      }
    });

    await Promise.all(checkPromises);

    // 更新统计
    this.updateStats(results);

    // 自适应调整检查间隔
    this.adjustInterval(results);

    // 发出检查结果事件
    this.emit('checkComplete', {
      results,
      duration: Date.now() - startTime,
      timestamp: Date.now()
    });

    // 调度下一次检查
    if (this.isRunning) {
      this.checkTimer = setTimeout(() => {
        this.performCheck();
      }, this.currentInterval);
    }

    return results;
  }

  /**
   * 检查单个Key
   * @private
   * @param {APIKeyImpl} key - 要检查的Key
   * @returns {Promise<HealthCheckResult>} 检查结果
   */
  private async checkKey(key: APIKeyImpl): Promise<HealthCheckResult> {
    const startTime = Date.now();

    try {
      // 构建健康检查请求
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.timeoutMs);

      const response = await fetch(this.config.endpoint, {
        method: 'HEAD',
        headers: {
          'Authorization': `Bearer ${key.key}`,
          'X-Health-Check': 'true'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      const latency = Date.now() - startTime;

      // 解析响应头中的速率限制信息
      const rateLimitRemaining = response.headers.get('x-ratelimit-remaining');
      const rateLimitReset = response.headers.get('x-ratelimit-reset');

      const result: HealthCheckResult = {
        keyId: key.id,
        healthy: response.ok,
        latency,
        rateLimitRemaining: rateLimitRemaining ? parseInt(rateLimitRemaining, 10) : undefined,
        rateLimitResetTime: rateLimitReset ? parseInt(rateLimitReset, 10) * 1000 : undefined,
        timestamp: Date.now()
      };

      // 更新Key状态
      key.updateHealth(result.healthy, result.latency);
      if (result.rateLimitRemaining !== undefined) {
        key.updateRateLimit(
          result.rateLimitRemaining,
          result.rateLimitResetTime || Date.now() + 60000
        );
      }

      return result;

    } catch (error) {
      const latency = Date.now() - startTime;
      
      key.markFailed(error instanceof Error ? error : new Error(String(error)));

      return {
        keyId: key.id,
        healthy: false,
        latency,
        error: error instanceof Error ? error.message : String(error),
        timestamp: Date.now()
      };
    }
  }

  /**
   * 启动批量同步
   * @private
   */
  private startBatchSync(): void {
    this.syncTimer = setInterval(() => {
      this.flushSyncQueue();
    }, this.config.batchSyncIntervalMs);
  }

  /**
   * 将结果加入同步队列
   * @private
   * @param {HealthCheckResult} result - 检查结果
   */
  private queueForSync(result: HealthCheckResult): void {
    this.syncQueue.push(result);

    // 如果队列过长，立即同步
    if (this.syncQueue.length >= this.config.maxConcurrency * 2) {
      this.flushSyncQueue();
    }
  }

  /**
   * 刷新同步队列
   * @private
   */
  private flushSyncQueue(): void {
    if (this.syncQueue.length === 0) return;

    const batch = this.syncQueue.splice(0, this.syncQueue.length);
    
    this.emit('batchSync', {
      count: batch.length,
      results: batch,
      timestamp: Date.now()
    });
  }

  /**
   * 更新统计信息
   * @private
   * @param {HealthCheckResult[]} results - 检查结果
   */
  private updateStats(results: HealthCheckResult[]): void {
    this.stats.totalChecks += results.length;
    
    const successful = results.filter(r => r.healthy).length;
    this.stats.successfulChecks += successful;
    this.stats.failedChecks += results.length - successful;

    // 更新平均延迟
    const totalLatency = results.reduce((sum, r) => sum + r.latency, 0);
    const avgLatency = totalLatency / results.length;
    
    // 指数移动平均
    this.stats.averageLatency = 
      this.stats.averageLatency * 0.7 + avgLatency * 0.3;
  }

  /**
   * 自适应调整检查间隔
   * @private
   * @param {HealthCheckResult[]} results - 检查结果
   */
  private adjustInterval(results: HealthCheckResult[]): void {
    const failedCount = results.filter(r => !r.healthy).length;
    const failureRate = failedCount / results.length;

    if (failureRate > 0.5) {
      // 高失败率，缩短检查间隔
      this.consecutiveFailures++;
      this.currentInterval = Math.max(
        this.config.minIntervalMs,
        this.currentInterval * (1 - this.config.adaptiveFactor)
      );
    } else if (failureRate === 0) {
      // 无失败，恢复检查间隔
      this.consecutiveFailures = Math.max(0, this.consecutiveFailures - 1);
      this.currentInterval = Math.min(
        this.config.checkIntervalMs,
        this.currentInterval * (1 + this.config.adaptiveFactor * 0.5)
      );
    }

    this.emit('intervalAdjusted', {
      newInterval: this.currentInterval,
      failureRate,
      consecutiveFailures: this.consecutiveFailures
    });
  }
}

export default AdaptiveHealthChecker;
