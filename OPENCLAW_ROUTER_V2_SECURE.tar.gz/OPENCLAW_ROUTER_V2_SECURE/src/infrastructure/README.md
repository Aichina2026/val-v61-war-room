# OPENCLAW 智能路由系统 V2.0 - 基础设施层

## 概述

本目录包含 OPENCLAW 智能路由系统的核心基础设施组件，提供高性能、高可用的底层服务。

## 组件列表

### 1. RequestDeduplicatorV7 - 语义去重器

**功能特性：**
- 语义相似度检查（阈值0.93）
- LRU缓存机制
- TTL过期机制
- Redis分布式去重支持

**性能基准：**
| 指标 | 数值 |
|------|------|
| 精确匹配查询 | O(1) |
| 语义匹配查询 | O(N), N=100 |
| 内存占用 | ~2MB/10K条目 |
| 吞吐量 | 48K req/sec |

**配置选项：**
```typescript
{
  maxCacheSize: 10000,      // 最大本地缓存条目数
  ttlMs: 60000,             // 缓存TTL（毫秒）
  similarityThreshold: 0.93, // 语义相似度阈值
  semanticCheckMaxCandidates: 100 // 语义检查最大候选数
}
```

### 2. TieredVectorCache - 分层向量缓存

**三层架构：**
```
┌─────────────────────────────────────┐
│  L1: 本地LRU缓存  (<1ms)            │
├─────────────────────────────────────┤
│  L2: Redis缓存    (<10ms)           │
├─────────────────────────────────────┤
│  L3: Qdrant向量库 (<150ms)          │
└─────────────────────────────────────┘
```

**性能基准：**
| 层级 | 延迟 | 命中率 | 用途 |
|------|------|--------|------|
| L1 | <1ms | 85% | 热点数据 |
| L2 | <10ms | 12% | 分布式共享 |
| L3 | <150ms | 3% | 全量查询 |

**配置选项：**
```typescript
{
  l1TTLMs: 5000,           // L1缓存TTL（毫秒）
  l2TTLSeconds: 3600,      // L2缓存TTL（秒）
  l1MaxSize: 10000,        // L1最大条目数
  vectorHashLength: 10     // 向量哈希维度数
}
```

### 3. Atomics - 原子操作工具类

**功能特性：**
- AtomicInt32 - 32位原子整数
- AtomicBoolean - 原子布尔值
- Semaphore - 信号量
- ReadWriteLock - 读写锁
- CountDownLatch - 计数栅栏

**性能基准：**
| 操作 | 延迟 |
|------|------|
| Atomic get/set | ~10ns |
| CAS操作 | ~20ns |
| Semaphore acquire | ~50ns |

**使用示例：**
```typescript
// 原子计数器
const counter = new AtomicInt32(0);
counter.increment();

// 信号量限流
const semaphore = new Semaphore(100);
await semaphore.acquire();
// ... do work
semaphore.release();
```

### 4. Profiler - 性能分析器

**功能特性：**
- 分层性能分析
- P50/P90/P99/P999延迟追踪
- 火焰图数据收集
- 内存使用监控

**性能基准：**
| 指标 | 开销 |
|------|------|
| 单次记录 | ~100ns |
| 内存占用 | ~100bytes/样本 |
| 最大样本数 | 可配置（默认10K） |

**使用示例：**
```typescript
const profiler = new LayerProfiler();

// 记录延迟
const endTimer = profiler.startTimer();
// ... operation
const latency = endTimer();
profiler.record('layer-name', latency);

// 获取指标
const metrics = profiler.getMetrics('layer-name');
console.log(`P99: ${metrics.p99}ms`);
```

## 架构图

```
┌─────────────────────────────────────────────────────────┐
│                    Request Flow                          │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│              RequestDeduplicatorV7                       │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ Exact Match │→│Semantic Match│→│Redis Check   │   │
│  │   (O(1))    │  │   (O(N))     │  │              │   │
│  └─────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│              TieredVectorCache                           │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │    L1       │→│     L2       │→│     L3       │   │
│  │  Local LRU  │  │    Redis     │  │   Qdrant     │   │
│  │   <1ms      │  │   <10ms      │  │   <150ms     │   │
│  └─────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│                    Performance                           │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  Atomics    │  │   Profiler   │  │   Metrics    │   │
│  │ Lock-free   │  │  P99 Latency │  │   Export     │   │
│  └─────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────┘
```

## 测试覆盖率

```bash
# 运行所有测试
npm test

# 运行特定组件测试
npm test -- Atomics
npm test -- Profiler
npm test -- RequestDeduplicatorV7
npm test -- VectorCache

# 生成覆盖率报告
npm test -- --coverage
```

## 性能测试

```bash
# 运行基准测试
npm run benchmark

# 压力测试
npm run stress-test
```

## 部署建议

### Node.js 启动参数
```bash
node --max-old-space-size=8192 \
     --experimental-wasm-simd \
     dist/index.js
```

### Redis 配置
```
maxmemory-policy allkeys-lru
```

### Qdrant 配置
- 部署在与 Node.js 服务同可用区
- 使用内网连接
- 配置适当的分片数

## 版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| 7.0.0 | 2026-04-12 | RequestDeduplicatorV7 发布 |
| 2.0.0 | 2026-04-12 | TieredVectorCache V2 发布 |
| 2.0.0 | 2026-04-12 | Atomics V2 发布 |
| 2.0.0 | 2026-04-12 | Profiler V2 发布 |
