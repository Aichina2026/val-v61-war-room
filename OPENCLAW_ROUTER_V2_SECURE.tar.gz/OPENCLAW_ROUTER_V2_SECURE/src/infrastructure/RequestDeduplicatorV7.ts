/**
 * OPENCLAW SmartRouter V2.0 - Request Deduplicator V7
 * @version 7.0.0
 * @description 语义去重器，支持LRU缓存、TTL过期、Redis分布式去重
 */

import { createHash } from 'crypto';
import { Redis } from 'ioredis';
import { RoutingDecision } from '../types/index';

/**
 * 去重结果接口
 */
export interface DeduplicationResult {
  /** 是否重复 */
  isDuplicate: boolean;
  /** 缓存的响应 */
  cachedResponse: RoutingDecision | null;
  /** 置信度 0-1 */
  confidence: number;
  /** 匹配类型 */
  matchType?: 'exact' | 'semantic' | 'none';
}

/**
 * 向量查询接口
 */
export interface VectorQuery {
  /** 查询文本 */
  text: string;
  /** 上下文信息 */
  context?: Record<string, any>;
  /** 查询ID */
  queryId?: string;
}

/**
 * 本地缓存项
 */
interface CacheEntry {
  /** 请求指纹 */
  fingerprint: string;
  /** 向量表示 */
  vector: number[];
  /** 决策结果 */
  response: RoutingDecision;
  /** 创建时间 */
  createdAt: number;
  /** 过期时间 */
  expiresAt: number;
  /** 访问计数 */
  accessCount: number;
}

/**
 * LRU缓存节点
 */
interface LRUCacheNode {
  key: string;
  entry: CacheEntry;
  prev: LRUCacheNode | null;
  next: LRUCacheNode | null;
}

/**
 * 请求去重器 V7
 * 支持语义相似度检查（阈值0.93）、LRU缓存、TTL过期、Redis分布式去重
 */
export class RequestDeduplicatorV7 {
  private localCache: Map<string, CacheEntry>;
  private lruHead: LRUCacheNode | null = null;
  private lruTail: LRUCacheNode | null = null;
  private lruMap: Map<string, LRUCacheNode> = new Map();
  
  private readonly maxCacheSize: number;
  private readonly similarityThreshold: number;
  private readonly ttlMs: number;
  private readonly semanticCheckMaxCandidates: number;
  private redisClient: Redis | null = null;
  private redisEnabled: boolean = false;

  /**
   * 清理定时器
   */
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor(
    options: {
      maxCacheSize?: number;
      ttlMs?: number;
      similarityThreshold?: number;
      semanticCheckMaxCandidates?: number;
      redisClient?: Redis;
    } = {}
  ) {
    this.localCache = new Map();
    this.maxCacheSize = options.maxCacheSize ?? 10000;
    this.ttlMs = options.ttlMs ?? 60000;
    this.similarityThreshold = options.similarityThreshold ?? 0.93;
    this.semanticCheckMaxCandidates = options.semanticCheckMaxCandidates ?? 100;

    if (options.redisClient) {
      this.redisClient = options.redisClient;
      this.redisEnabled = true;
    }

    // 启动定期清理
    this.startCleanupTimer();
  }

  /**
   * 生成请求指纹（SHA-256）
   */
  public generateFingerprint(request: VectorQuery): string {
    const payload = JSON.stringify({
      text: request.text.toLowerCase().trim(),
      context: request.context
    });
    return createHash('sha256').update(payload).digest('hex');
  }

  /**
   * 计算余弦相似度
   */
  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    if (vecA.length !== vecB.length) {
      throw new Error('Vector dimensions must match');
    }

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }

    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * 检查重复请求
   */
  public async checkDuplicate(request: VectorQuery, vector: number[]): Promise<DeduplicationResult> {
    const fingerprint = this.generateFingerprint(request);
    const now = Date.now();

    // 1. 精确匹配（O(1)）
    const exactMatch = this.localCache.get(fingerprint);
    if (exactMatch && exactMatch.expiresAt > now) {
      this.touchEntry(fingerprint);
      return {
        isDuplicate: true,
        cachedResponse: exactMatch.response,
        confidence: 1.0,
        matchType: 'exact'
      };
    }

    // 2. 语义匹配（仅在LRU前N个候选中检查）
    const semanticMatch = this.findSemanticMatch(vector, this.semanticCheckMaxCandidates);
    if (semanticMatch) {
      return {
        isDuplicate: true,
        cachedResponse: semanticMatch.response,
        confidence: semanticMatch.confidence,
        matchType: 'semantic'
      };
    }

    // 3. Redis分布式检查（如启用）
    if (this.redisEnabled && this.redisClient) {
      try {
        const redisRes = await this.redisClient.get(`dedup:${fingerprint}`);
        if (redisRes) {
          const parsed = JSON.parse(redisRes);
          return {
            isDuplicate: true,
            cachedResponse: parsed,
            confidence: 1.0,
            matchType: 'exact'
          };
        }
      } catch (error) {
        console.warn('[DeduplicatorV7] Redis check failed:', error);
      }
    }

    return {
      isDuplicate: false,
      cachedResponse: null,
      confidence: 0,
      matchType: 'none'
    };
  }

  /**
   * 查找语义匹配
   */
  private findSemanticMatch(vector: number[], maxCandidates: number): { response: RoutingDecision; confidence: number } | null {
    const now = Date.now();
    let bestMatch: { response: RoutingDecision; confidence: number } | null = null;
    let candidatesChecked = 0;

    // 按LRU顺序检查（最近使用的优先）
    for (const [, entry] of this.localCache) {
      if (entry.expiresAt <= now) continue;
      if (candidatesChecked >= maxCandidates) break;

      const similarity = this.cosineSimilarity(vector, entry.vector);
      if (similarity >= this.similarityThreshold) {
        if (!bestMatch || similarity > bestMatch.confidence) {
          bestMatch = { response: entry.response, confidence: similarity };
        }
      }
      candidatesChecked++;
    }

    return bestMatch;
  }

  /**
   * 缓存请求结果
   */
  public async cacheRequest(
    request: VectorQuery,
    vector: number[],
    response: RoutingDecision
  ): Promise<void> {
    const fingerprint = this.generateFingerprint(request);
    const now = Date.now();
    const expiresAt = now + this.ttlMs;

    const entry: CacheEntry = {
      fingerprint,
      vector: [...vector], // 复制向量
      response,
      createdAt: now,
      expiresAt,
      accessCount: 1
    };

    // 添加到本地缓存
    this.addToCache(fingerprint, entry);

    // 异步写入Redis（如启用）
    if (this.redisEnabled && this.redisClient) {
      this.redisClient
        .setex(`dedup:${fingerprint}`, Math.ceil(this.ttlMs / 1000), JSON.stringify(response))
        .catch((error) => {
          console.warn('[DeduplicatorV7] Redis cache failed:', error);
        });
    }
  }

  /**
   * 添加到缓存（带LRU淘汰）
   */
  private addToCache(key: string, entry: CacheEntry): void {
    // 如果已存在，更新并移到头部
    if (this.localCache.has(key)) {
      this.localCache.set(key, entry);
      this.moveToHead(key);
      return;
    }

    // 检查容量，执行LRU淘汰
    if (this.localCache.size >= this.maxCacheSize) {
      this.evictLRU();
    }

    // 添加新条目
    this.localCache.set(key, entry);
    this.addNode(key, entry);
  }

  /**
   * 触摸条目（更新访问时间）
   */
  private touchEntry(key: string): void {
    const entry = this.localCache.get(key);
    if (entry) {
      entry.accessCount++;
      this.moveToHead(key);
    }
  }

  /**
   * 将节点移到头部（最近使用）
   */
  private moveToHead(key: string): void {
    const node = this.lruMap.get(key);
    if (!node) return;

    // 已在头部
    if (node === this.lruHead) return;

    // 从当前位置移除
    if (node.prev) node.prev.next = node.next;
    if (node.next) node.next.prev = node.prev;
    if (node === this.lruTail) this.lruTail = node.prev;

    // 插入头部
    node.prev = null;
    node.next = this.lruHead;
    if (this.lruHead) this.lruHead.prev = node;
    this.lruHead = node;
    if (!this.lruTail) this.lruTail = node;
  }

  /**
   * 添加LRU节点
   */
  private addNode(key: string, entry: CacheEntry): void {
    const node: LRUCacheNode = {
      key,
      entry,
      prev: null,
      next: this.lruHead
    };

    if (this.lruHead) this.lruHead.prev = node;
    this.lruHead = node;
    if (!this.lruTail) this.lruTail = node;

    this.lruMap.set(key, node);
  }

  /**
   * 淘汰最久未使用的条目
   */
  private evictLRU(): void {
    if (!this.lruTail) return;

    const key = this.lruTail.key;
    this.localCache.delete(key);
    this.lruMap.delete(key);

    this.lruTail = this.lruTail.prev;
    if (this.lruTail) this.lruTail.next = null;
    else this.lruHead = null;
  }

  /**
   * 启动清理定时器
   */
  private startCleanupTimer(): void {
    // 每30秒清理过期条目
    this.cleanupInterval = setInterval(() => {
      this.cleanupExpired();
    }, 30000);
  }

  /**
   * 清理过期条目
   */
  private cleanupExpired(): void {
    const now = Date.now();
    const expiredKeys: string[] = [];

    for (const [key, entry] of this.localCache) {
      if (entry.expiresAt <= now) {
        expiredKeys.push(key);
      }
    }

    for (const key of expiredKeys) {
      this.removeFromCache(key);
    }

    if (expiredKeys.length > 0) {
      console.log(`[DeduplicatorV7] Cleaned ${expiredKeys.length} expired entries`);
    }
  }

  /**
   * 从缓存中移除
   */
  private removeFromCache(key: string): void {
    const node = this.lruMap.get(key);
    if (node) {
      if (node.prev) node.prev.next = node.next;
      if (node.next) node.next.prev = node.prev;
      if (node === this.lruHead) this.lruHead = node.next;
      if (node === this.lruTail) this.lruTail = node.prev;
      this.lruMap.delete(key);
    }
    this.localCache.delete(key);
  }

  /**
   * 获取缓存统计
   */
  public getStats(): {
    localCacheSize: number;
    maxCacheSize: number;
    similarityThreshold: number;
    ttlMs: number;
    redisEnabled: boolean;
  } {
    return {
      localCacheSize: this.localCache.size,
      maxCacheSize: this.maxCacheSize,
      similarityThreshold: this.similarityThreshold,
      ttlMs: this.ttlMs,
      redisEnabled: this.redisEnabled
    };
  }

  /**
   * 清除所有缓存
   */
  public clear(): void {
    this.localCache.clear();
    this.lruMap.clear();
    this.lruHead = null;
    this.lruTail = null;

    if (this.redisEnabled && this.redisClient) {
      // 异步清除Redis中的dedup键
      this.redisClient.keys('dedup:*').then((keys) => {
        if (keys.length > 0) {
          return this.redisClient?.del(...keys);
        }
      }).catch((error) => {
        console.warn('[DeduplicatorV7] Redis clear failed:', error);
      });
    }
  }

  /**
   * 销毁（清理资源）
   */
  public destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    this.clear();
  }
}
