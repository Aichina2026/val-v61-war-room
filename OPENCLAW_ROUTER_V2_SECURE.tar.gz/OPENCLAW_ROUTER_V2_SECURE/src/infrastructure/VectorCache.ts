/**
 * OPENCLAW SmartRouter V2.0 - Tiered Vector Cache
 * @version 2.0.0
 * @description 三级分层向量缓存：L1本地LRU、L2 Redis、L3 Qdrant
 */

import { Redis } from 'ioredis';
import { AtomicInt32 } from '../utils/Atomics';

/**
 * 向量结果接口
 */
export interface VectorResult {
  /** 结果ID */
  id: string;
  /** 相似度分数 */
  score: number;
  /** 向量数据 */
  vector?: number[];
  /** 元数据 */
  metadata?: Record<string, any>;
}

/**
 * L1本地缓存项
 */
interface L1CacheEntry {
  data: VectorResult[];
  expiresAt: number;
  accessCount: number;
}

/**
 * Qdrant查询结果
 */
interface QdrantSearchResult {
  id: string | number;
  score: number;
  vector?: number[];
  payload?: Record<string, any>;
}

/**
 * Qdrant客户端接口
 */
interface QdrantClient {
  search(collection: string, params: {
    vector: number[];
    limit: number;
    with_vector?: boolean;
    with_payload?: boolean;
  }): Promise<QdrantSearchResult[]>;
}

/**
 * 缓存统计
 */
export interface CacheStats {
  L1: number;
  L2: number;
  L3: number;
  total: number;
  hitRate: number;
}

/**
 * 分层向量缓存
 * L1: 本地LRU (<1ms)
 * L2: Redis (<10ms)
 * L3: Qdrant (<150ms)
 */
export class TieredVectorCache {
  private l1Cache: Map<string, L1CacheEntry>;
  private redis: Redis | null = null;
  private qdrantClient: QdrantClient | null = null;
  private redisEnabled: boolean = false;
  private qdrantEnabled: boolean = false;

  // 命中率统计
  private l1Hits = new AtomicInt32(0);
  private l2Hits = new AtomicInt32(0);
  private l3Hits = new AtomicInt32(0);
  private totalRequests = new AtomicInt32(0);

  // 配置
  private readonly l1TTLMs: number;
  private readonly l2TTLSeconds: number;
  private readonly l1MaxSize: number;
  private readonly vectorHashLength: number;

  /**
   * 构造函数
   */
  constructor(options: {
    redis?: Redis;
    qdrantClient?: QdrantClient;
    l1TTLMs?: number;
    l2TTLSeconds?: number;
    l1MaxSize?: number;
    vectorHashLength?: number;
  } = {}) {
    this.l1Cache = new Map();
    this.l1TTLMs = options.l1TTLMs ?? 5000;
    this.l2TTLSeconds = options.l2TTLSeconds ?? 3600;
    this.l1MaxSize = options.l1MaxSize ?? 10000;
    this.vectorHashLength = options.vectorHashLength ?? 10;

    if (options.redis) {
      this.redis = options.redis;
      this.redisEnabled = true;
    }

    if (options.qdrantClient) {
      this.qdrantClient = options.qdrantClient;
      this.qdrantEnabled = true;
    }
  }

  /**
   * 生成向量哈希键
   * 使用局部敏感哈希(LSH)思想，取前N维的近似值
   */
  private hashVector(vector: number[]): string {
    // 取前N维，量化为2位小数
    return vector
      .slice(0, this.vectorHashLength)
      .map((v) => v.toFixed(2))
      .join('|');
  }

  /**
   * 搜索向量
   * 按L1 -> L2 -> L3顺序查询
   */
  public async search(vector: number[], topK: number = 5): Promise<VectorResult[]> {
    this.totalRequests.add(1);
    const hashKey = this.hashVector(vector);
    const now = Date.now();

    // L1: 本地LRU缓存 (<1ms)
    const l1Res = this.l1Cache.get(hashKey);
    if (l1Res && l1Res.expiresAt > now) {
      l1Res.accessCount++;
      this.l1Hits.add(1);
      return l1Res.data;
    }

    // L2: Redis缓存 (<10ms)
    if (this.redisEnabled && this.redis) {
      try {
        const l2Res = await this.redis.get(`vec:${hashKey}`);
        if (l2Res) {
          const parsed = JSON.parse(l2Res) as VectorResult[];
          // 回填L1
          this.setL1Cache(hashKey, parsed);
          this.l2Hits.add(1);
          return parsed;
        }
      } catch (error) {
        console.warn('[VectorCache] L2 cache error, degrading to L3:', error);
      }
    }

    // L3: Qdrant原始查询 (<150ms)
    if (this.qdrantEnabled && this.qdrantClient) {
      try {
        const l3Res = await this.qdrantClient.search('openclaw_collection', {
          vector: vector,
          limit: topK,
          with_vector: false,
          with_payload: true
        });

        // 处理空结果
        if (!l3Res || l3Res.length === 0) {
          return [];
        }

        // 转换为VectorResult格式
        const results: VectorResult[] = l3Res.map((item) => ({
          id: String(item.id),
          score: item.score,
          metadata: item.payload
        }));

        // 异步回填L1 & L2
        this.setL1Cache(hashKey, results);
        this.backfillL2(hashKey, results);

        this.l3Hits.add(1);
        return results;
      } catch (error: any) {
        // 修复404漏洞：优雅降级
        if (error.status === 404 || error.message?.includes('404')) {
          console.warn('[VectorCache] Qdrant 404, returning empty result');
          return [];
        }
        throw new Error(`L3 Query Failed: ${error.message}`);
      }
    }

    // 所有层级都未命中
    return [];
  }

  /**
   * 批量搜索多个向量
   */
  public async batchSearch(vectors: number[][], topK: number = 5): Promise<VectorResult[][]> {
    return Promise.all(vectors.map((vec) => this.search(vec, topK)));
  }

  /**
   * 设置L1缓存
   */
  private setL1Cache(hashKey: string, data: VectorResult[]): void {
    // LRU淘汰
    if (this.l1Cache.size >= this.l1MaxSize) {
      const firstKey = this.l1Cache.keys().next().value;
      this.l1Cache.delete(firstKey);
    }

    this.l1Cache.set(hashKey, {
      data,
      expiresAt: Date.now() + this.l1TTLMs,
      accessCount: 1
    });
  }

  /**
   * 异步回填L2缓存
   */
  private backfillL2(hashKey: string, data: VectorResult[]): void {
    if (!this.redisEnabled || !this.redis) return;

    this.redis
      .setex(`vec:${hashKey}`, this.l2TTLSeconds, JSON.stringify(data))
      .catch((error) => {
        console.warn('[VectorCache] L2 backfill failed:', error);
      });
  }

  /**
   * 手动设置缓存
   */
  public async set(vector: number[], data: VectorResult[]): Promise<void> {
    const hashKey = this.hashVector(vector);
    this.setL1Cache(hashKey, data);

    if (this.redisEnabled && this.redis) {
      await this.redis.setex(`vec:${hashKey}`, this.l2TTLSeconds, JSON.stringify(data));
    }
  }

  /**
   * 使缓存失效
   */
  public async invalidate(vector?: number[]): Promise<void> {
    if (vector) {
      const hashKey = this.hashVector(vector);
      this.l1Cache.delete(hashKey);

      if (this.redisEnabled && this.redis) {
        await this.redis.del(`vec:${hashKey}`);
      }
    } else {
      // 清除所有缓存
      this.l1Cache.clear();

      if (this.redisEnabled && this.redis) {
        const keys = await this.redis.keys('vec:*');
        if (keys.length > 0) {
          await this.redis.del(...keys);
        }
      }
    }
  }

  /**
   * 获取缓存统计
   */
  public getStats(): CacheStats {
    const l1 = this.l1Hits.get();
    const l2 = this.l2Hits.get();
    const l3 = this.l3Hits.get();
    const total = this.totalRequests.get();

    return {
      L1: l1,
      L2: l2,
      L3: l3,
      total,
      hitRate: total > 0 ? ((l1 + l2) / total) * 100 : 0
    };
  }

  /**
   * 获取L1缓存大小
   */
  public getL1Size(): number {
    return this.l1Cache.size;
  }

  /**
   * 重置统计
   */
  public resetStats(): void {
    this.l1Hits.set(0);
    this.l2Hits.set(0);
    this.l3Hits.set(0);
    this.totalRequests.set(0);
  }

  /**
   * 预热缓存
   */
  public async warmup(vectors: number[], results: VectorResult[]): Promise<void> {
    await this.set(vectors, results);
  }

  /**
   * 健康检查
   */
  public async healthCheck(): Promise<{
    L1: boolean;
    L2: boolean;
    L3: boolean;
  }> {
    const health = {
      L1: this.l1Cache instanceof Map,
      L2: false,
      L3: false
    };

    if (this.redisEnabled && this.redis) {
      try {
        await this.redis.ping();
        health.L2 = true;
      } catch {
        health.L2 = false;
      }
    }

    if (this.qdrantEnabled && this.qdrantClient) {
      try {
        // 尝试执行一个空搜索来检查连接
        await this.qdrantClient.search('openclaw_collection', {
          vector: new Array(1536).fill(0),
          limit: 1
        });
        health.L3 = true;
      } catch {
        health.L3 = false;
      }
    }

    return health;
  }
}
