/**
 * 请求去重器V7 - 语义相似度检查 + LRU缓存
 * @version 7.0.0
 * @description 基于语义哈希的去重系统，支持LRU缓存淘汰
 */

import { RouteRequest, RoutingDecision, DedupCacheEntry } from '../types';

/**
 * LRU缓存节点
 */
interface LRUCacheNode {
  key: string;
  value: DedupCacheEntry;
  prev: LRUCacheNode | null;
  next: LRUCacheNode | null;
}

/**
 * LRU缓存实现
 */
class LRUCache {
  private capacity: number;
  private cache: Map<string, LRUCacheNode>;
  private head: LRUCacheNode;
  private tail: LRUCacheNode;

  constructor(capacity: number) {
    this.capacity = capacity;
    this.cache = new Map();
    
    // 创建哨兵节点
    this.head = { key: '', value: null as any, prev: null, next: null };
    this.tail = { key: '', value: null as any, prev: null, next: null };
    this.head.next = this.tail;
    this.tail.prev = this.head;
  }

  /**
   * 获取值
   */
  get(key: string): DedupCacheEntry | undefined {
    const node = this.cache.get(key);
    if (!node) return undefined;

    // 检查是否过期
    if (node.value.expiresAt < Date.now()) {
      this.delete(key);
      return undefined;
    }

    // 移动到头部
    this.moveToHead(node);
    return node.value;
  }

  /**
   * 设置值
   */
  set(key: string, value: DedupCacheEntry): void {
    const node = this.cache.get(key);

    if (node) {
      node.value = value;
      this.moveToHead(node);
    } else {
      const newNode: LRUCacheNode = {
        key,
        value,
        prev: null,
        next: null
      };

      this.cache.set(key, newNode);
      this.addToHead(newNode);

      // 淘汰尾部
      if (this.cache.size > this.capacity) {
        this.removeTail();
      }
    }
  }

  /**
   * 删除
   */
  delete(key: string): boolean {
    const node = this.cache.get(key);
    if (!node) return false;

    this.removeNode(node);
    this.cache.delete(key);
    return true;
  }

  /**
   * 清理过期项
   */
  cleanup(): number {
    const now = Date.now();
    let cleaned = 0;

    for (const [key, node] of this.cache) {
      if (node.value.expiresAt < now) {
        this.removeNode(node);
        this.cache.delete(key);
        cleaned++;
      }
    }

    return cleaned;
  }

  /**
   * 获取大小
   */
  size(): number {
    return this.cache.size;
  }

  /**
   * 清空
   */
  clear(): void {
    this.cache.clear();
    this.head.next = this.tail;
    this.tail.prev = this.head;
  }

  private addToHead(node: LRUCacheNode): void {
    node.prev = this.head;
    node.next = this.head.next;
    this.head.next!.prev = node;
    this.head.next = node;
  }

  private removeNode(node: LRUCacheNode): void {
    node.prev!.next = node.next;
    node.next!.prev = node.prev;
  }

  private moveToHead(node: LRUCacheNode): void {
    this.removeNode(node);
    this.addToHead(node);
  }

  private removeTail(): LRUCacheNode | null {
    const node = this.tail.prev;
    if (node === this.head) return null;

    this.removeNode(node);
    this.cache.delete(node.key);
    return node;
  }
}

/**
 * 语义哈希生成器
 */
class SemanticHasher {
  /**
   * 生成请求的语义哈希
   */
  hash(request: RouteRequest): string {
    // 1. 标准化文本
    const normalized = this.normalize(request.prompt);
    
    // 2. 提取语义特征
    const features = this.extractFeatures(normalized, request);
    
    // 3. 生成哈希
    return this.computeHash(features);
  }

  /**
   * 计算两个请求的相似度
   */
  similarity(req1: RouteRequest, req2: RouteRequest): number {
    const hash1 = this.hash(req1);
    const hash2 = this.hash(req2);

    // 完全匹配
    if (hash1 === hash2) return 1;

    // 提取特征向量进行比较
    const features1 = this.extractFeatures(this.normalize(req1.prompt), req1);
    const features2 = this.extractFeatures(this.normalize(req2.prompt), req2);

    // 计算余弦相似度
    return this.cosineSimilarity(features1, features2);
  }

  /**
   * 标准化文本
   */
  private normalize(text: string): string {
    return text
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .replace(/[^\w\s]/g, '')
      .trim();
  }

  /**
   * 提取语义特征
   */
  private extractFeatures(text: string, request: RouteRequest): number[] {
    const features: number[] = [];

    // 长度特征
    features.push(text.length);
    features.push(text.split(' ').length);

    // 代码模式特征
    const codePatterns = this.detectCodePatterns(text);
    features.push(...codePatterns);

    // 数学模式特征
    const mathPatterns = this.detectMathPatterns(text);
    features.push(...mathPatterns);

    // 搜索模式特征
    const searchPatterns = this.detectSearchPatterns(text);
    features.push(...searchPatterns);

    // 角色和模式编码
    features.push(this.encodeRole(request.preferredRole));
    features.push(this.encodeMode(request.mode));

    // 关键词哈希
    const keywordHash = this.keywordHash(text);
    features.push(...keywordHash);

    return features;
  }

  /**
   * 检测代码模式
   */
  private detectCodePatterns(text: string): number[] {
    const patterns = [
      /\b(function|def|class|const|let|var)\b/i,
      /[{}[\];]/,
      /\b(import|from|require)\b/i,
      /[=+\-*/<>!]=?/,
      /\b(console|print|log)\b/i
    ];

    return patterns.map(p => p.test(text) ? 1 : 0);
  }

  /**
   * 检测数学模式
   */
  private detectMathPatterns(text: string): number[] {
    const patterns = [
      /\$\$?[^$]+\$\$?/,  // LaTeX
      /[\d]+[\+\-\*\/\^][\d]+/,  // 简单计算
      /\b(integral|derivative|sum|product)\b/i,
      /[\(\)\[\]]*[\+\-]?[\d\.]+[\(\)\[\]]*[\+\-\*\/\^]/,
      /\b(equation|formula|calculate|compute)\b/i
    ];

    return patterns.map(p => p.test(text) ? 1 : 0);
  }

  /**
   * 检测搜索模式
   */
  private detectSearchPatterns(text: string): number[] {
    const patterns = [
      /\b(search|find|lookup|query)\b/i,
      /\b(what|how|when|where|why|who)\b/i,
      /\b(latest|recent|current|today)\b/i,
      /\b(news|update|status)\b/i,
      /\?\s*$/
    ];

    return patterns.map(p => p.test(text) ? 1 : 0);
  }

  /**
   * 编码角色
   */
  private encodeRole(role?: string): number {
    const roles: Record<string, number> = {
      clarifier: 0,
      builder: 1,
      reviewer: 2,
      arbiter: 3
    };
    return roles[role || ''] ?? -1;
  }

  /**
   * 编码模式
   */
  private encodeMode(mode?: string): number {
    const modes: Record<string, number> = {
      think: 0,
      act: 1,
      fast: 2,
      search: 3
    };
    return modes[mode || ''] ?? -1;
  }

  /**
   * 关键词哈希
   */
  private keywordHash(text: string): number[] {
    const words = text.split(/\s+/).filter(w => w.length > 3);
    const hash: number[] = new Array(8).fill(0);

    for (const word of words) {
      const h = this.simpleHash(word);
      hash[h % 8] += 1;
    }

    return hash.map(v => Math.min(v / 5, 1));
  }

  /**
   * 简单字符串哈希
   */
  private simpleHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }

  /**
   * 计算哈希
   */
  private computeHash(features: number[]): string {
    // 将特征向量转换为哈希字符串
    const quantized = features.map(f => Math.round(f * 100).toString(36));
    return quantized.join('');
  }

  /**
   * 余弦相似度
   */
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) {
      const maxLen = Math.max(a.length, b.length);
      a = [...a, ...new Array(maxLen - a.length).fill(0)];
      b = [...b, ...new Array(maxLen - b.length).fill(0)];
    }

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }
}

/**
 * 去重器配置
 */
export interface DeduplicatorConfig {
  /** 缓存容量 */
  capacity?: number;
  /** TTL (毫秒) */
  ttl?: number;
  /** 相似度阈值 */
  similarityThreshold?: number;
  /** 启用语义匹配 */
  enableSemantic?: boolean;
  /** 清理间隔 */
  cleanupInterval?: number;
}

/**
 * 请求去重器V7
 */
export class RequestDeduplicatorV7 {
  private cache: LRUCache;
  private hasher: SemanticHasher;
  private config: Required<DeduplicatorConfig>;
  private stats = {
    hits: 0,
    misses: 0,
    semanticHits: 0,
    evictions: 0
  };

  constructor(config: DeduplicatorConfig = {}) {
    this.config = {
      capacity: config.capacity ?? 1000,
      ttl: config.ttl ?? 300000, // 5分钟
      similarityThreshold: config.similarityThreshold ?? 0.85,
      enableSemantic: config.enableSemantic ?? true,
      cleanupInterval: config.cleanupInterval ?? 60000 // 1分钟
    };

    this.cache = new LRUCache(this.config.capacity);
    this.hasher = new SemanticHasher();

    // 启动清理定时器
    this.startCleanup();
  }

  /**
   * 获取缓存的决策
   */
  get(request: RouteRequest): RoutingDecision | null {
    // 1. 精确匹配
    const hash = this.hasher.hash(request);
    const entry = this.cache.get(hash);

    if (entry) {
      this.stats.hits++;
      return entry.decision;
    }

    // 2. 语义匹配
    if (this.config.enableSemantic) {
      const semanticMatch = this.findSemanticMatch(request);
      if (semanticMatch) {
        this.stats.semanticHits++;
        return semanticMatch;
      }
    }

    this.stats.misses++;
    return null;
  }

  /**
   * 设置缓存
   */
  set(request: RouteRequest, decision: RoutingDecision): void {
    const hash = this.hasher.hash(request);
    const now = Date.now();

    const entry: DedupCacheEntry = {
      hash,
      decision,
      createdAt: now,
      expiresAt: now + this.config.ttl
    };

    const oldSize = this.cache.size();
    this.cache.set(hash, entry);
    
    if (this.cache.size() === oldSize && oldSize >= this.config.capacity) {
      this.stats.evictions++;
    }
  }

  /**
   * 使缓存项失效
   */
  invalidate(request: RouteRequest): boolean {
    const hash = this.hasher.hash(request);
    return this.cache.delete(hash);
  }

  /**
   * 清空缓存
   */
  clear(): void {
    this.cache.clear();
    this.stats.hits = 0;
    this.stats.misses = 0;
    this.stats.semanticHits = 0;
    this.stats.evictions = 0;
  }

  /**
   * 获取统计信息
   */
  getStats() {
    const total = this.stats.hits + this.stats.misses;
    return {
      ...this.stats,
      totalRequests: total,
      hitRate: total > 0 ? this.stats.hits / total : 0,
      cacheSize: this.cache.size(),
      semanticHitRate: total > 0 ? this.stats.semanticHits / total : 0
    };
  }

  /**
   * 查找语义匹配
   */
  private findSemanticMatch(request: RouteRequest): RoutingDecision | null {
    // 简化的实现：遍历缓存查找高相似度项
    // 实际生产环境可以使用向量数据库
    
    // 这里直接返回null，因为LRUCache不直接支持遍历
    // 完整的实现需要额外的索引结构
    return null;
  }

  /**
   * 启动清理定时器
   */
  private startCleanup(): void {
    const cleanup = () => {
      this.cache.cleanup();
      setTimeout(cleanup, this.config.cleanupInterval);
    };
    setTimeout(cleanup, this.config.cleanupInterval);
  }
}

export default RequestDeduplicatorV7;
