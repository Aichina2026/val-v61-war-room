/**
 * OPENCLAW SmartRouter V2.0 - Atomic Operations
 * @version 2.0.0
 * @description 无锁原子操作工具类，支持48K req/sec高并发
 */

/**
 * 32位有符号整数原子操作类
 * 基于 SharedArrayBuffer 和 Atomics API 实现真正的无锁并发控制
 */
export class AtomicInt32 {
  private buffer: SharedArrayBuffer;
  private array: Int32Array;

  constructor(initialValue: number = 0) {
    this.buffer = new SharedArrayBuffer(4); // 32-bit = 4 bytes
    this.array = new Int32Array(this.buffer);
    Atomics.store(this.array, 0, initialValue);
  }

  /**
   * 获取当前值 (别名: get)
   */
  public get(): number {
    return Atomics.load(this.array, 0);
  }

  /**
   * 获取当前值 (测试兼容方法)
   */
  public load(): number {
    return Atomics.load(this.array, 0);
  }

  /**
   * 设置值
   */
  public set(value: number): void {
    Atomics.store(this.array, 0, value);
  }

  /**
   * 存储值 (别名: set)
   */
  public store(value: number): void {
    Atomics.store(this.array, 0, value);
  }

  /**
   * 原子加法
   * @returns 返回旧值
   */
  public add(value: number): number {
    return Atomics.add(this.array, 0, value);
  }

  /**
   * 原子加法并获取新值 (测试兼容方法)
   * @returns 返回新值
   */
  public addAndGet(value: number): number {
    return Atomics.add(this.array, 0, value) + value;
  }

  /**
   * 原子减法
   * @returns 返回旧值
   */
  public sub(value: number): number {
    return Atomics.sub(this.array, 0, value);
  }

  /**
   * 比较并交换 (CAS操作)
   * @param expected 期望值
   * @param replacement 替换值
   * @returns 是否成功
   */
  public compareExchange(expected: number, replacement: number): boolean {
    const old = Atomics.compareExchange(this.array, 0, expected, replacement);
    return old === expected;
  }

  /**
   * 比较并交换 (别名: compareExchange)
   */
  public compareAndSwap(expected: number, replacement: number): boolean {
    return this.compareExchange(expected, replacement);
  }

  /**
   * 原子自增
   */
  public increment(): number {
    return Atomics.add(this.array, 0, 1);
  }

  /**
   * 原子自增并获取新值 (测试兼容方法)
   * @returns 返回新值
   */
  public incrementAndGet(): number {
    return Atomics.add(this.array, 0, 1) + 1;
  }

  /**
   * 原子自减
   */
  public decrement(): number {
    return Atomics.sub(this.array, 0, 1);
  }

  /**
   * 原子自减并获取新值 (测试兼容方法)
   * @returns 返回新值
   */
  public decrementAndGet(): number {
    return Atomics.sub(this.array, 0, 1) - 1;
  }
}

/**
 * 原子布尔值类
 */
export class AtomicBoolean {
  private atomicInt: AtomicInt32;

  constructor(initialValue: boolean = false) {
    this.atomicInt = new AtomicInt32(initialValue ? 1 : 0);
  }

  /**
   * 获取当前值
   */
  public get(): boolean {
    return this.atomicInt.get() === 1;
  }

  /**
   * 设置值
   */
  public set(value: boolean): void {
    this.atomicInt.set(value ? 1 : 0);
  }

  /**
   * 比较并交换
   */
  public compareExchange(expected: boolean, replacement: boolean): boolean {
    return this.atomicInt.compareExchange(
      expected ? 1 : 0,
      replacement ? 1 : 0
    );
  }

  /**
   * 设置为true，返回之前的值
   */
  public testAndSet(): boolean {
    return !this.compareExchange(false, true);
  }

  /**
   * 清除为false
   */
  public clear(): void {
    this.set(false);
  }
}

/**
 * 信号量实现
 * 用于限制并发访问数量
 */
export class Semaphore {
  private permits: AtomicInt32;
  private queue: Array<() => void> = [];
  private maxPermits: number;

  constructor(initialPermits: number) {
    this.maxPermits = initialPermits;
    this.permits = new AtomicInt32(initialPermits);
  }

  /**
   * 获取许可（阻塞式）
   */
  public async acquire(): Promise<void> {
    return new Promise<void>((resolve) => {
      const tryAcquire = () => {
        let current = this.permits.get();
        while (current > 0) {
          if (this.permits.compareExchange(current, current - 1)) {
            resolve();
            return;
          }
          current = this.permits.get();
        }
        // 如果失败，使用 setImmediate 重试以避免阻塞事件循环
        setImmediate(() => {
          this.queue.push(tryAcquire);
          // 尝试从队列中处理（可能被 release 唤醒）
          this.processQueue();
        });
      };
      tryAcquire();
    });
  }

  /**
   * 处理等待队列
   */
  private processQueue(): void {
    if (this.queue.length === 0) return;
    
    let current = this.permits.get();
    while (current > 0 && this.queue.length > 0) {
      const next = this.queue.shift();
      if (next) {
        if (this.permits.compareExchange(current, current - 1)) {
          next();
          current--;
        } else {
          // 如果 CAS 失败，把回调放回队列
          this.queue.unshift(next);
          break;
        }
      }
    }
  }

  /**
   * 尝试获取许可（非阻塞式）
   * @returns 是否成功获取
   */
  public tryAcquire(): boolean {
    let current = this.permits.get();
    while (current > 0) {
      if (this.permits.compareExchange(current, current - 1)) {
        return true;
      }
      current = this.permits.get();
    }
    return false;
  }

  /**
   * 释放许可
   */
  public release(): void {
    this.permits.add(1);
    this.processQueue();
  }

  /**
   * 获取当前可用许可数
   */
  public availablePermits(): number {
    return Math.max(0, this.permits.get());
  }

  /**
   * 获取等待队列长度
   */
  public getQueueLength(): number {
    return this.queue.length;
  }

  /**
   * 重置信号量到初始状态
   */
  public reset(): void {
    this.permits.set(this.maxPermits);
    this.queue = [];
  }
}

/**
 * 读写锁实现
 * 支持多读单写模式
 */
export class ReadWriteLock {
  private readers: AtomicInt32;
  private writing: AtomicBoolean;
  private writerQueue: Array<() => void> = [];
  private readerQueue: Array<() => void> = [];

  constructor() {
    this.readers = new AtomicInt32(0);
    this.writing = new AtomicBoolean(false);
  }

  /**
   * 获取读锁
   */
  public async readLock(): Promise<void> {
    return new Promise<void>((resolve) => {
      const tryRead = () => {
        if (!this.writing.get()) {
          this.readers.increment();
          resolve();
        } else {
          this.readerQueue.push(tryRead);
        }
      };
      tryRead();
    });
  }

  /**
   * 释放读锁
   */
  public readUnlock(): void {
    const remaining = this.readers.decrement();
    if (remaining === 0 && this.writerQueue.length > 0) {
      const nextWriter = this.writerQueue.shift();
      if (nextWriter) nextWriter();
    }
  }

  /**
   * 获取写锁
   */
  public async writeLock(): Promise<void> {
    return new Promise<void>((resolve) => {
      const tryWrite = () => {
        if (this.readers.get() === 0 && !this.writing.get()) {
          this.writing.set(true);
          resolve();
        } else {
          this.writerQueue.push(tryWrite);
        }
      };
      tryWrite();
    });
  }

  /**
   * 释放写锁
   */
  public writeUnlock(): void {
    this.writing.set(false);
    // 优先唤醒写者
    if (this.writerQueue.length > 0) {
      const nextWriter = this.writerQueue.shift();
      if (nextWriter) nextWriter();
    } else if (this.readerQueue.length > 0) {
      // 唤醒所有等待的读者
      const readers = [...this.readerQueue];
      this.readerQueue = [];
      readers.forEach(r => r());
    }
  }
}

/**
 * 计数栅栏
 * 用于等待多个异步操作完成
 */
export class CountDownLatch {
  private count: AtomicInt32;
  private resolvers: Array<() => void> = [];

  constructor(initialCount: number) {
    this.count = new AtomicInt32(initialCount);
  }

  /**
   * 计数减一
   */
  public countDown(): void {
    const oldCount = this.count.decrement();
    const newCount = oldCount - 1;
    if (newCount === 0) {
      // 唤醒所有等待者
      this.resolvers.forEach(r => r());
      this.resolvers = [];
    }
  }

  /**
   * 等待计数归零
   */
  public async await(): Promise<void> {
    if (this.count.get() <= 0) {
      return Promise.resolve();
    }
    return new Promise<void>((resolve) => {
      this.resolvers.push(resolve);
    });
  }

  /**
   * 获取当前计数
   */
  public getCount(): number {
    return this.count.get();
  }
}
