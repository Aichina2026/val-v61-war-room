/**
 * OPENCLAW SmartRouter V2.0 - Performance Profiler
 * @version 2.0.0
 * @description 分层性能分析器，支持火焰图数据收集和P99延迟追踪
 */

/**
 * 性能指标接口
 */
export interface ProfileMetrics {
  /** 层级名称 */
  layer: string;
  /** P50延迟（毫秒） */
  p50: number;
  /** P90延迟（毫秒） */
  p90: number;
  /** P99延迟（毫秒） */
  p99: number;
  /** P999延迟（毫秒） */
  p999: number;
  /** 平均延迟 */
  avg: number;
  /** 最小延迟 */
  min: number;
  /** 最大延迟 */
  max: number;
  /** 样本数量 */
  sampleCount: number;
  /** 内存使用（MB） */
  memoryUsageMB: number;
  /** CPU使用率 */
  cpuUsage?: number;
}

/**
 * 火焰图节点接口
 */
export interface FlameNode {
  /** 节点名称 */
  name: string;
  /** 总耗时（毫秒） */
  value: number;
  /** 子节点 */
  children: FlameNode[];
  /** 调用次数 */
  calls?: number;
}

/**
 * 调用栈帧
 */
interface StackFrame {
  name: string;
  startTime: number;
  children: StackFrame[];
}

/**
 * 分层性能分析器
 */
export class LayerProfiler {
  private latencies: Map<string, number[]> = new Map();
  private readonly maxSamples: number;
  private activeTraces: Map<string, StackFrame> = new Map();
  private traceHistory: StackFrame[] = [];
  private readonly maxTraceHistory: number;

  constructor(maxSamples = 10000, maxTraceHistory = 1000) {
    this.maxSamples = maxSamples;
    this.maxTraceHistory = maxTraceHistory;
  }

  /**
   * 启动计时器
   * @returns 结束计时函数，返回耗时（毫秒）
   */
  public startTimer(): () => number {
    const start = process.hrtime.bigint();
    return () => {
      const end = process.hrtime.bigint();
      return Number(end - start) / 1_000_000; // 转换为毫秒
    };
  }

  /**
   * 开始追踪一个调用栈
   * @param traceId 追踪ID
   * @param name 调用名称
   */
  public startTrace(traceId: string, name: string): void {
    const frame: StackFrame = {
      name,
      startTime: performance.now(),
      children: []
    };
    this.activeTraces.set(traceId, frame);
  }

  /**
   * 结束追踪
   * @param traceId 追踪ID
   * @returns 总耗时（毫秒）
   */
  public endTrace(traceId: string): number | null {
    const frame = this.activeTraces.get(traceId);
    if (!frame) return null;

    const duration = performance.now() - frame.startTime;
    this.activeTraces.delete(traceId);

    // 保存到历史
    this.traceHistory.push(frame);
    if (this.traceHistory.length > this.maxTraceHistory) {
      this.traceHistory.shift();
    }

    return duration;
  }

  /**
   * 记录延迟数据
   * @param layer 层级名称
   * @param latencyMs 延迟（毫秒）
   */
  public record(layer: string, latencyMs: number): void {
    if (!this.latencies.has(layer)) {
      this.latencies.set(layer, []);
    }
    const samples = this.latencies.get(layer)!;
    samples.push(latencyMs);

    // 防止内存泄漏：限制样本数量
    if (samples.length > this.maxSamples) {
      samples.shift();
    }
  }

  /**
   * 获取指定层级的性能指标
   * @param layer 层级名称
   */
  public getMetrics(layer: string): ProfileMetrics | null {
    const samples = this.latencies.get(layer);
    if (!samples || samples.length === 0) return null;

    // 复制并排序以计算分位数
    const sorted = [...samples].sort((a, b) => a - b);
    const count = sorted.length;

    const p50 = this.getPercentile(sorted, 0.50);
    const p90 = this.getPercentile(sorted, 0.90);
    const p99 = this.getPercentile(sorted, 0.99);
    const p999 = this.getPercentile(sorted, 0.999);

    const sum = sorted.reduce((a, b) => a + b, 0);
    const avg = sum / count;
    const min = sorted[0];
    const max = sorted[count - 1];

    const mem = process.memoryUsage();

    return {
      layer,
      p50,
      p90,
      p99,
      p999,
      avg,
      min,
      max,
      sampleCount: count,
      memoryUsageMB: Math.round((mem.heapUsed / 1024 / 1024) * 100) / 100
    };
  }

  /**
   * 获取所有层级的性能指标
   */
  public getAllMetrics(): ProfileMetrics[] {
    const metrics: ProfileMetrics[] = [];
    for (const layer of this.latencies.keys()) {
      const metric = this.getMetrics(layer);
      if (metric) metrics.push(metric);
    }
    return metrics;
  }

  /**
   * 计算百分位数
   */
  private getPercentile(sorted: number[], percentile: number): number {
    const index = Math.ceil(sorted.length * percentile) - 1;
    return sorted[Math.max(0, index)];
  }

  /**
   * 生成火焰图数据
   */
  public generateFlameGraphData(): FlameNode {
    const root: FlameNode = { name: 'root', value: 0, children: [] };

    for (const [layer, samples] of this.latencies.entries()) {
      const totalTime = samples.reduce((a, b) => a + b, 0);
      const avgTime = totalTime / samples.length;

      root.children.push({
        name: layer,
        value: totalTime,
        children: [],
        calls: samples.length
      });
      root.value += totalTime;
    }

    return root;
  }

  /**
   * 生成详细的火焰图数据（包含调用栈）
   */
  public generateDetailedFlameGraph(): FlameNode {
    const root: FlameNode = { name: 'root', value: 0, children: [] };

    for (const trace of this.traceHistory) {
      this.addFrameToFlameGraph(root, trace);
    }

    return root;
  }

  /**
   * 将栈帧添加到火焰图
   */
  private addFrameToFlameGraph(parent: FlameNode, frame: StackFrame): void {
    const duration = performance.now() - frame.startTime;

    let node = parent.children.find(c => c.name === frame.name);
    if (!node) {
      node = { name: frame.name, value: 0, children: [] };
      parent.children.push(node);
    }

    node.value += duration;
    parent.value += duration;

    for (const child of frame.children) {
      this.addFrameToFlameGraph(node, child);
    }
  }

  /**
   * 获取延迟分布直方图数据
   * @param layer 层级名称
   * @param buckets 分桶数量
   */
  public getLatencyHistogram(layer: string, buckets: number = 10): { ranges: string[], counts: number[] } | null {
    const samples = this.latencies.get(layer);
    if (!samples || samples.length === 0) return null;

    const sorted = [...samples].sort((a, b) => a - b);
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    const range = max - min;
    const bucketSize = range / buckets;

    const counts = new Array(buckets).fill(0);
    const ranges: string[] = [];

    for (let i = 0; i < buckets; i++) {
      const start = min + i * bucketSize;
      const end = min + (i + 1) * bucketSize;
      ranges.push(`${start.toFixed(2)}-${end.toFixed(2)}ms`);
    }

    for (const latency of samples) {
      const bucketIndex = Math.min(Math.floor((latency - min) / bucketSize), buckets - 1);
      counts[bucketIndex]++;
    }

    return { ranges, counts };
  }

  /**
   * 清除指定层级的数据
   */
  public clear(layer?: string): void {
    if (layer) {
      this.latencies.delete(layer);
    } else {
      this.latencies.clear();
      this.traceHistory = [];
      this.activeTraces.clear();
    }
  }

  /**
   * 导出性能报告
   */
  public exportReport(): string {
    const metrics = this.getAllMetrics();
    const report: string[] = ['=== Performance Report ===', ''];

    for (const m of metrics) {
      report.push(`Layer: ${m.layer}`);
      report.push(`  P50: ${m.p50.toFixed(2)}ms`);
      report.push(`  P90: ${m.p90.toFixed(2)}ms`);
      report.push(`  P99: ${m.p99.toFixed(2)}ms`);
      report.push(`  P99.9: ${m.p999.toFixed(2)}ms`);
      report.push(`  Avg: ${m.avg.toFixed(2)}ms`);
      report.push(`  Min: ${m.min.toFixed(2)}ms`);
      report.push(`  Max: ${m.max.toFixed(2)}ms`);
      report.push(`  Samples: ${m.sampleCount}`);
      report.push(`  Memory: ${m.memoryUsageMB}MB`);
      report.push('');
    }

    return report.join('\n');
  }
}

/**
 * 简单的计时器装饰器
 */
export function timed(profiler: LayerProfiler, layer: string) {
  return function(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value;

    descriptor.value = async function(...args: any[]) {
      const endTimer = profiler.startTimer();
      try {
        return await originalMethod.apply(this, args);
      } finally {
        const latency = endTimer();
        profiler.record(layer, latency);
      }
    };

    return descriptor;
  };
}
