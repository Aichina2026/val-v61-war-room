/**
 * free-code适配器
 * @module adapter/FreeCodeAdapter
 * @version 2.0.0
 * @description 将free-code项目整合到OpenClaw智能路由系统
 * 
 * 核心功能:
 * - MCP协议桥接
 * - 端到端编排能力
 * - 文件系统操作
 * - 代码生成与执行
 * 
 * 集成特性:
 * - 4AI工作流调用
 * - 零错误系统支持
 * - 智能路由决策
 * - 状态同步
 */

import { EventEmitter } from 'events';
import { FourAIWorkflowAdapter, FourAIRole } from './4AIWorkflowAdapter';
import { OhMyCodexAdapter, OhMyCodexMode } from './OhMyCodexAdapter';
import { SmartRouter } from '../router/SmartRouter';

/**
 * free-code项目配置
 */
export interface FreeCodeProjectConfig {
  name: string;
  path: string;
  language: string;
  framework?: string;
  entryPoint?: string;
  dependencies?: string[];
  testCommand?: string;
  buildCommand?: string;
}

/**
 * free-code任务类型
 */
export type FreeCodeTaskType = 
  | 'generate'
  | 'modify'
  | 'review'
  | 'test'
  | 'debug'
  | 'refactor'
  | 'document';

/**
 * free-code请求
 */
export interface FreeCodeRequest {
  task: FreeCodeTaskType;
  project: FreeCodeProjectConfig;
  targetFiles?: string[];
  requirements?: string;
  constraints?: string[];
  context?: Record<string, any>;
  use4AI?: boolean;
  ohMyCodexMode?: OhMyCodexMode;
}

/**
 * free-code结果
 */
export interface FreeCodeResult {
  taskId: string;
  success: boolean;
  files: FileOperation[];
  tests?: TestResult[];
  review?: CodeReviewResult;
  documentation?: string;
  metadata: {
    duration: number;
    tokensUsed: number;
    confidence: number;
  };
}

/**
 * 文件操作
 */
export interface FileOperation {
  path: string;
  operation: 'create' | 'modify' | 'delete' | 'rename';
  content?: string;
  previousContent?: string;
  diff?: string;
}

/**
 * 测试结果
 */
export interface TestResult {
  name: string;
  passed: boolean;
  duration: number;
  output?: string;
  error?: string;
}

/**
 * 代码审查结果
 */
export interface CodeReviewResult {
  overallScore: number;
  issues: CodeIssue[];
  suggestions: string[];
  securityChecks: SecurityCheck[];
  performanceNotes: string[];
}

/**
 * 代码问题
 */
export interface CodeIssue {
  severity: 'info' | 'warning' | 'error' | 'critical';
  file: string;
  line?: number;
  message: string;
  rule?: string;
  fix?: string;
}

/**
 * 安全检查
 */
export interface SecurityCheck {
  name: string;
  passed: boolean;
  severity: 'low' | 'medium' | 'high' | 'critical';
  details?: string;
}

/**
 * MCP工具定义
 */
export interface MCPTool {
  name: string;
  description: string;
  parameters: Record<string, any>;
  handler: (args: any) => Promise<any>;
}

/**
 * free-code适配器
 */
export class FreeCodeAdapter extends EventEmitter {
  private fourAI: FourAIWorkflowAdapter;
  private ohMyCodex: OhMyCodexAdapter;
  private router: SmartRouter;
  private mcpTools: Map<string, MCPTool>;
  private activeTasks: Map<string, FreeCodeTask>;

  /**
   * 构造函数
   */
  constructor() {
    super();

    this.fourAI = new FourAIWorkflowAdapter({
      mode: 'parallel',
      timeout: 180000,
      enableArbiter: true
    });

    this.ohMyCodex = new OhMyCodexAdapter({
      mode: 'auto',
      teamSize: 3,
      maxIterations: 5
    });

    this.router = new SmartRouter();
    this.mcpTools = new Map();
    this.activeTasks = new Map();

    this.registerMCPTools();
    this.setupEventHandlers();
  }

  /**
   * 执行free-code任务
   */
  async execute(request: FreeCodeRequest): Promise<FreeCodeResult> {
    const taskId = this.generateTaskId();
    const startTime = Date.now();

    this.emit('task-start', { taskId, task: request.task, project: request.project.name });

    try {
      let result: FreeCodeResult;

      switch (request.task) {
        case 'generate':
          result = await this.executeGenerate(taskId, request);
          break;
        case 'modify':
          result = await this.executeModify(taskId, request);
          break;
        case 'review':
          result = await this.executeReview(taskId, request);
          break;
        case 'test':
          result = await this.executeTest(taskId, request);
          break;
        case 'debug':
          result = await this.executeDebug(taskId, request);
          break;
        case 'refactor':
          result = await this.executeRefactor(taskId, request);
          break;
        case 'document':
          result = await this.executeDocument(taskId, request);
          break;
        default:
          throw new Error(`Unknown task type: ${request.task}`);
      }

      this.emit('task-complete', { taskId, duration: Date.now() - startTime });
      return result;

    } catch (error) {
      this.emit('task-error', { taskId, error });
      throw error;
    }
  }

  /**
   * 代码生成任务
   */
  private async executeGenerate(taskId: string, request: FreeCodeRequest): Promise<FreeCodeResult> {
    const { use4AI, ohMyCodexMode, project, requirements, targetFiles } = request;

    let generationResult: string;

    if (use4AI) {
      // 使用4AI工作流生成
      const fourAIResult = await this.fourAI.executeWorkflow(
        this.buildGenerationPrompt(project, requirements, targetFiles),
        { project, task: 'generate' }
      );
      generationResult = fourAIResult.finalOutput;
    } else if (ohMyCodexMode) {
      // 使用oh-my-codex生成
      const omcResult = await this.ohMyCodex.execute({
        prompt: this.buildGenerationPrompt(project, requirements, targetFiles),
        mode: ohMyCodexMode,
        context: { project, task: 'generate' }
      });
      generationResult = 'finalOutput' in omcResult ? omcResult.finalOutput : 
                        'primaryOutput' in omcResult ? omcResult.primaryOutput :
                        'architecture' in omcResult ? omcResult.architecture : '';
    } else {
      // 使用智能路由
      const decision = await this.router.route({
        prompt: this.buildGenerationPrompt(project, requirements, targetFiles),
        preferredRole: 'builder'
      });
      generationResult = await this.callModel(decision);
    }

    // 解析生成的文件
    const files = this.parseGeneratedFiles(generationResult, project.path);

    return {
      taskId,
      success: files.length > 0,
      files,
      metadata: {
        duration: 0,
        tokensUsed: 0,
        confidence: 0.85
      }
    };
  }

  /**
   * 代码修改任务
   */
  private async executeModify(taskId: string, request: FreeCodeRequest): Promise<FreeCodeResult> {
    const { project, targetFiles, requirements } = request;

    // 读取目标文件
    const fileContents = await this.readFiles(targetFiles || []);

    // 构建修改提示
    const prompt = this.buildModificationPrompt(project, fileContents, requirements);

    // 使用4AI生成修改
    const fourAIResult = await this.fourAI.executeWorkflow(prompt, {
      project,
      existingFiles: fileContents,
      task: 'modify'
    });

    // 解析修改
    const files = this.parseModifications(fourAIResult.builderOutput, fileContents);

    return {
      taskId,
      success: files.length > 0,
      files,
      metadata: {
        duration: 0,
        tokensUsed: fourAIResult.metadata.totalTokens,
        confidence: fourAIResult.metadata.confidenceScore
      }
    };
  }

  /**
   * 代码审查任务
   */
  private async executeReview(taskId: string, request: FreeCodeRequest): Promise<FreeCodeResult> {
    const { project, targetFiles } = request;

    // 读取目标文件
    const fileContents = await this.readFiles(targetFiles || []);

    // 使用oh-my-codex的team模式进行多维度审查
    const reviewResult = await this.ohMyCodex.execute({
      prompt: this.buildReviewPrompt(project, fileContents),
      mode: 'team',
      context: { project, files: fileContents, task: 'review' }
    });

    if (!('peerReviews' in reviewResult)) {
      throw new Error('Unexpected review result format');
    }

    // 解析审查结果
    const codeReview: CodeReviewResult = {
      overallScore: reviewResult.consensusScore,
      issues: this.parseIssues(reviewResult.peerReviews),
      suggestions: reviewResult.peerReviews.flatMap(r => r.suggestions),
      securityChecks: this.parseSecurityChecks(reviewResult.peerReviews),
      performanceNotes: this.parsePerformanceNotes(reviewResult.peerReviews)
    };

    return {
      taskId,
      success: true,
      files: [],
      review: codeReview,
      metadata: {
        duration: 0,
        tokensUsed: 0,
        confidence: reviewResult.consensusScore / 100
      }
    };
  }

  /**
   * 测试任务
   */
  private async executeTest(taskId: string, request: FreeCodeRequest): Promise<FreeCodeResult> {
    const { project } = request;

    // 使用MCP工具执行测试
    const testTool = this.mcpTools.get('execute_command');
    if (!testTool) {
      throw new Error('Test execution tool not available');
    }

    const testCommand = project.testCommand || 'npm test';
    const testOutput = await testTool.handler({
      command: testCommand,
      cwd: project.path,
      timeout: 120000
    });

    // 解析测试结果
    const tests = this.parseTestResults(testOutput.output || '');

    return {
      taskId,
      success: tests.every(t => t.passed),
      files: [],
      tests,
      metadata: {
        duration: testOutput.duration,
        tokensUsed: 0,
        confidence: tests.filter(t => t.passed).length / tests.length
      }
    };
  }

  /**
   * 调试任务
   */
  private async executeDebug(taskId: string, request: FreeCodeRequest): Promise<FreeCodeResult> {
    const { project, requirements } = request;

    // 使用oh-my-codex的ri模式进行迭代调试
    const debugResult = await this.ohMyCodex.execute({
      prompt: this.buildDebugPrompt(project, requirements),
      mode: 'ri',
      context: { project, task: 'debug', errorLogs: requirements }
    });

    if (!('iterations' in debugResult)) {
      throw new Error('Unexpected debug result format');
    }

    // 提取最终修复
    const files = this.parseModifications(debugResult.finalOutput, new Map());

    return {
      taskId,
      success: debugResult.convergenceScore > 80,
      files,
      metadata: {
        duration: 0,
        tokensUsed: 0,
        confidence: debugResult.convergenceScore / 100
      }
    };
  }

  /**
   * 重构任务
   */
  private async executeRefactor(taskId: string, request: FreeCodeRequest): Promise<FreeCodeResult> {
    const { project, targetFiles, constraints } = request;

    // 读取目标文件
    const fileContents = await this.readFiles(targetFiles || []);

    // 使用oh-my-codex的ralph模式进行架构级重构
    const refactorResult = await this.ohMyCodex.execute({
      prompt: this.buildRefactorPrompt(project, fileContents, constraints),
      mode: 'ralph',
      context: { project, files: fileContents, task: 'refactor' }
    });

    if (!('architecture' in refactorResult)) {
      throw new Error('Unexpected refactor result format');
    }

    // 解析重构方案
    const files = this.parseGeneratedFiles(refactorResult.architecture, project.path);

    return {
      taskId,
      success: refactorResult.validationReport.passed,
      files,
      review: {
        overallScore: refactorResult.validationReport.overallScore,
        issues: [],
        suggestions: refactorResult.recommendations,
        securityChecks: [],
        performanceNotes: refactorResult.riskAssessment.mitigations
      },
      metadata: {
        duration: 0,
        tokensUsed: 0,
        confidence: refactorResult.validationReport.overallScore / 100
      }
    };
  }

  /**
   * 文档生成任务
   */
  private async executeDocument(taskId: string, request: FreeCodeRequest): Promise<FreeCodeResult> {
    const { project, targetFiles } = request;

    // 读取目标文件
    const fileContents = await this.readFiles(targetFiles || []);

    // 使用4AI生成文档
    const fourAIResult = await this.fourAI.executeWorkflow(
      this.buildDocumentationPrompt(project, fileContents),
      { project, files: fileContents, task: 'document' }
    );

    return {
      taskId,
      success: true,
      files: [],
      documentation: fourAIResult.finalOutput,
      metadata: {
        duration: 0,
        tokensUsed: fourAIResult.metadata.totalTokens,
        confidence: fourAIResult.metadata.confidenceScore
      }
    };
  }

  /**
   * 注册MCP工具
   */
  private registerMCPTools(): void {
    // 文件系统工具
    this.mcpTools.set('read_file', {
      name: 'read_file',
      description: 'Read file contents',
      parameters: {
        path: { type: 'string', required: true }
      },
      handler: async (args) => {
        const fs = await import('fs/promises');
        const content = await fs.readFile(args.path, 'utf-8');
        return { content };
      }
    });

    this.mcpTools.set('write_file', {
      name: 'write_file',
      description: 'Write file contents',
      parameters: {
        path: { type: 'string', required: true },
        content: { type: 'string', required: true }
      },
      handler: async (args) => {
        const fs = await import('fs/promises');
        await fs.writeFile(args.path, args.content, 'utf-8');
        return { success: true };
      }
    });

    this.mcpTools.set('list_directory', {
      name: 'list_directory',
      description: 'List directory contents',
      parameters: {
        path: { type: 'string', required: true }
      },
      handler: async (args) => {
        const fs = await import('fs/promises');
        const entries = await fs.readdir(args.path, { withFileTypes: true });
        return {
          entries: entries.map(e => ({
            name: e.name,
            isDirectory: e.isDirectory(),
            isFile: e.isFile()
          }))
        };
      }
    });

    // 命令执行工具
    this.mcpTools.set('execute_command', {
      name: 'execute_command',
      description: 'Execute shell command',
      parameters: {
        command: { type: 'string', required: true },
        cwd: { type: 'string', required: false },
        timeout: { type: 'number', required: false, default: 60000 }
      },
      handler: async (args) => {
        const { exec } = await import('child_process');
        const { promisify } = await import('util');
        const execAsync = promisify(exec);
        
        const start = Date.now();
        try {
          const { stdout, stderr } = await execAsync(args.command, {
            cwd: args.cwd,
            timeout: args.timeout
          });
          return {
            output: stdout,
            error: stderr,
            duration: Date.now() - start,
            success: true
          };
        } catch (error: any) {
          return {
            output: error.stdout || '',
            error: error.stderr || error.message,
            duration: Date.now() - start,
            success: false
          };
        }
      }
    });

    // 代码搜索工具
    this.mcpTools.set('search_code', {
      name: 'search_code',
      description: 'Search code patterns',
      parameters: {
        pattern: { type: 'string', required: true },
        path: { type: 'string', required: true }
      },
      handler: async (args) => {
        // 简化实现，实际应使用更复杂的搜索
        return { matches: [] };
      }
    });
  }

  /**
   * 构建生成提示
   */
  private buildGenerationPrompt(
    project: FreeCodeProjectConfig,
    requirements?: string,
    targetFiles?: string[]
  ): string {
    return `请为以下项目生成代码：

项目名称: ${project.name}
语言: ${project.language}
框架: ${project.framework || '无'}
入口点: ${project.entryPoint || '未指定'}

需求描述:
${requirements || '根据项目配置生成基础结构'}

目标文件:
${targetFiles?.join('\n') || '根据需求自动生成'}

请生成完整的、可直接运行的代码。包含：
1. 文件结构
2. 完整代码实现
3. 必要的注释
4. 错误处理

输出格式：
�?-- filename.ext --
代码内容
�?-- end --`;
  }

  /**
   * 构建修改提示
   */
  private buildModificationPrompt(
    project: FreeCodeProjectConfig,
    files: Map<string, string>,
    requirements?: string
  ): string {
    const filesStr = Array.from(files.entries())
      .map(([path, content]) => `File: ${path}\n\`\`\`\n${content}\n\`\`\``)
      .join('\n\n');

    return `请修改以下代码文件：

项目: ${project.name}

现有文件:
${filesStr}

修改需求:
${requirements}

请输出修改后的完整文件内容，使用以下格式：
�?-- filename.ext --
修改后的代码
�?-- end --`;
  }

  /**
   * 构建审查提示
   */
  private buildReviewPrompt(
    project: FreeCodeProjectConfig,
    files: Map<string, string>
  ): string {
    const filesStr = Array.from(files.entries())
      .map(([path, content]) => `File: ${path}\n\`\`\`\n${content}\n\`\`\``)
      .join('\n\n');

    return `请审查以下代码：

项目: ${project.name}
语言: ${project.language}

文件内容:
${filesStr}

请从以下维度进行审查：
1. 代码质量
2. 安全性
3. 性能
4. 可维护性

输出格式：
- 评分（0-100）
- 发现的问题（按严重程度分类）
- 改进建议`;
  }

  /**
   * 构建调试提示
   */
  private buildDebugPrompt(project: FreeCodeProjectConfig, errorLogs?: string): string {
    return `请帮助调试以下问题：

项目: ${project.name}
语言: ${project.language}

错误日志:
${errorLogs || '请提供错误日志'}

请分析错误原因并提供修复方案。`;
  }

  /**
   * 构建重构提示
   */
  private buildRefactorPrompt(
    project: FreeCodeProjectConfig,
    files: Map<string, string>,
    constraints?: string[]
  ): string {
    const filesStr = Array.from(files.entries())
      .map(([path, content]) => `File: ${path}\n\`\`\`\n${content}\n\`\`\``)
      .join('\n\n');

    return `请重构以下代码：

项目: ${project.name}
语言: ${project.language}

现有代码:
${filesStr}

约束条件:
${constraints?.join('\n') || '保持功能不变，提升代码质量'}

请提供重构后的架构设计和代码实现。`;
  }

  /**
   * 构建文档生成提示
   */
  private buildDocumentationPrompt(
    project: FreeCodeProjectConfig,
    files: Map<string, string>
  ): string {
    const filesStr = Array.from(files.entries())
      .map(([path, content]) => `File: ${path}\n\`\`\`\n${content}\n\`\`\``)
      .join('\n\n');

    return `请为以下项目生成文档：

项目: ${project.name}
语言: ${project.language}

文件内容:
${filesStr}

请生成：
1. 项目概述
2. API文档
3. 使用示例
4. 架构说明`;
  }

  /**
   * 读取文件
   */
  private async readFiles(paths: string[]): Promise<Map<string, string>> {
    const fs = await import('fs/promises');
    const contents = new Map<string, string>();

    for (const path of paths) {
      try {
        const content = await fs.readFile(path, 'utf-8');
        contents.set(path, content);
      } catch (error) {
        console.warn(`Failed to read file: ${path}`);
      }
    }

    return contents;
  }

  /**
   * 解析生成的文件
   */
  private parseGeneratedFiles(output: string, basePath: string): FileOperation[] {
    const files: FileOperation[] = [];
    const regex = /\ufffd?--\s*(.+?)\s*--\s*\n([\s\S]*?)\n\ufffd?--\s*end\s*--/g;
    
    let match;
    while ((match = regex.exec(output)) !== null) {
      const filename = match[1].trim();
      const content = match[2].trim();
      
      files.push({
        path: `${basePath}/${filename}`,
        operation: 'create',
        content
      });
    }

    return files;
  }

  /**
   * 解析修改
   */
  private parseModifications(
    output: string,
    existingFiles: Map<string, string>
  ): FileOperation[] {
    const files = this.parseGeneratedFiles(output, '');
    
    return files.map(f => {
      const existing = existingFiles.get(f.path);
      return {
        ...f,
        operation: existing ? 'modify' : 'create',
        previousContent: existing,
        diff: existing ? this.generateDiff(existing, f.content || '') : undefined
      };
    });
  }

  /**
   * 生成差异
   */
  private generateDiff(oldContent: string, newContent: string): string {
    // 简化实现，实际应使用diff库
    return `--- old\n+++ new\n@@ -1,1 +1,1 @@\n- ${oldContent.substring(0, 50)}...\n+ ${newContent.substring(0, 50)}...`;
  }

  /**
   * 解析问题
   */
  private parseIssues(reviews: any[]): CodeIssue[] {
    const issues: CodeIssue[] = [];
    
    for (const review of reviews) {
      const lines = review.feedback.split('\n');
      for (const line of lines) {
        if (line.includes('错误') || line.includes('error')) {
          issues.push({
            severity: 'error',
            file: 'unknown',
            message: line
          });
        } else if (line.includes('警告') || line.includes('warning')) {
          issues.push({
            severity: 'warning',
            file: 'unknown',
            message: line
          });
        }
      }
    }

    return issues;
  }

  /**
   * 解析安全检查
   */
  private parseSecurityChecks(reviews: any[]): SecurityCheck[] {
    return reviews.map((r, i) => ({
      name: `Security Check ${i + 1}`,
      passed: !r.feedback.toLowerCase().includes('security') || 
              !r.feedback.toLowerCase().includes('vulnerability'),
      severity: 'medium'
    }));
  }

  /**
   * 解析性能说明
   */
  private parsePerformanceNotes(reviews: any[]): string[] {
    return reviews
      .filter(r => r.feedback.toLowerCase().includes('performance'))
      .map(r => r.feedback);
  }

  /**
   * 解析测试结果
   */
  private parseTestResults(output: string): TestResult[] {
    const tests: TestResult[] = [];
    
    // 解析常见的测试输出格式
    const passMatches = output.matchAll(/\u2713\s*(.+)/g);
    for (const match of passMatches) {
      tests.push({
        name: match[1].trim(),
        passed: true,
        duration: 0
      });
    }

    const failMatches = output.matchAll(/\u2717\s*(.+)/g);
    for (const match of failMatches) {
      tests.push({
        name: match[1].trim(),
        passed: false,
        duration: 0
      });
    }

    return tests;
  }

  /**
   * 调用模型
   */
  private async callModel(decision: any): Promise<string> {
    // 实际项目中应实现真实API调用
    return 'Model output placeholder';
  }

  /**
   * 生成任务ID
   */
  private generateTaskId(): string {
    return `fc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 设置事件处理器
   */
  private setupEventHandlers(): void {
    this.on('task-start', (event) => {
      console.log(`[free-code] Task started: ${event.taskId}`);
    });

    this.on('task-complete', (event) => {
      console.log(`[free-code] Task completed: ${event.taskId}`);
    });
  }

  /**
   * 获取MCP工具
   */
  getMCPTool(name: string): MCPTool | undefined {
    return this.mcpTools.get(name);
  }

  /**
   * 列出所有MCP工具
   */
  listMCPTools(): string[] {
    return Array.from(this.mcpTools.keys());
  }

  /**
   * 关闭适配器
   */
  shutdown(): void {
    this.fourAI.shutdown();
    this.ohMyCodex.shutdown();
    this.removeAllListeners();
  }
}

/**
 * free-code任务
 */
interface FreeCodeTask {
  id: string;
  request: FreeCodeRequest;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: FreeCodeResult;
  startTime: number;
}

export default FreeCodeAdapter;
