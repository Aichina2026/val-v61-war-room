/**
 * 4AI工作流适配器
 * @module adapter/4AIWorkflowAdapter
 * @version 2.0.0
 * @description 4AI原生工作流适配器，支持Clarifier/Builder/Reviewer/Arbiter角色调用
 * 
 * 特性:
 * - 原生4AI角色调用
 * - 并行执行支持
 * - 结果聚合与裁决
 * - 熔断器保护
 * - 去重缓存
 */

import { EventEmitter } from 'events';
import {
  AIRequest,
  AIResponse,
  FourAIWorkflowConfig,
  FourAIWorkflowResult,
  AIModelConfig,
  RoutingDecision,
  Message,
  TokenUsage
} from '../types';
import { SmartRouter } from '../router/SmartRouter';
import { LockFreeKeyPool } from '../keypool/LockFreeKeyPool';

/**
 * 4AI角色定义
 */
export type FourAIRole = 'clarifier' | 'builder' | 'reviewer' | 'arbiter';

/**
 * 角色输出结果
 */
export interface RoleOutput {
  role: FourAIRole;
  content: string;
  model: string;
  latency: number;
  tokens: TokenUsage;
  confidence: number;
  timestamp: number;
}

/**
 * 并行执行结果
 */
export interface ParallelExecutionResult {
  outputs: Map<FourAIRole, RoleOutput>;
  completed: FourAIRole[];
  failed: FourAIRole[];
  totalLatency: number;
  arbiterDecision?: ArbiterDecision;
}

/**
 * 仲裁决策
 */
export interface ArbiterDecision {
  finalOutput: string;
  reasoning: string;
  selectedRoles: FourAIRole[];
  confidence: number;
  aggregationStrategy: 'best' | 'merge' | 'voting' | 'hierarchical';
}

/**
 * 工作流执行配置
 */
export interface WorkflowExecutionConfig {
  mode: 'parallel' | 'sequential' | 'hybrid';
  timeout: number;
  enableArbiter: boolean;
  retryFailed: boolean;
  maxRetries: number;
  aggregationStrategy: ArbiterDecision['aggregationStrategy'];
}

/**
 * 4SAPI角色模型配置
 */
const ROLE_MODELS: Record<FourAIRole, AIModelConfig> = {
  clarifier: {
    model: 'gemini-3.1-pro-preview-04-05',
    temperature: 0.3,
    maxTokens: 4096,
    priority: 1,
    fallbacks: ['claude-opus-4.6-04-05']
  },
  builder: {
    model: 'deepseek-v3.2-0324',
    temperature: 0.2,
    maxTokens: 8192,
    priority: 2,
    fallbacks: ['gpt-5.4-04-08']
  },
  reviewer: {
    model: 'claude-opus-4.6-04-05',
    temperature: 0.1,
    maxTokens: 4096,
    priority: 3,
    fallbacks: ['gemini-3.1-pro-preview-04-05']
  },
  arbiter: {
    model: 'gpt-5.4-04-08',
    temperature: 0.2,
    maxTokens: 4096,
    priority: 4,
    fallbacks: ['claude-opus-4.6-04-05']
  }
};

/**
 * 4SAPI密钥池
 */
const FOUR_SAPI_KEYS = [
  'sk-bbufOP32qhZ2gXNvuZyUdvhWPtheQBhthvMIQxTeuQmjCTQl',
  'sk-KNDw0lmVt1a7Q98MUlD1aH4TUZgdqx0tTjfrfhZODS6hL9Se',
  'sk-ZR8zAmgxyIIM8qFB76J23HPI1LixgRnkx6iYphBcKYsgLozP',
  'sk-wO2l0uybCG6DTUZ9iLMo0lOAmIEtMUPuPwSpDsculMcCr4vX'
];

/**
 * 4AI工作流适配器
 */
export class FourAIWorkflowAdapter extends EventEmitter {
  private router: SmartRouter;
  private keyPool: LockFreeKeyPool;
  private config: WorkflowExecutionConfig;
  private roleOutputs: Map<string, Map<FourAIRole, RoleOutput>>;

  /**
   * 构造函数
   */
  constructor(config?: Partial<WorkflowExecutionConfig>) {
    super();
    
    this.config = {
      mode: 'parallel',
      timeout: 120000,
      enableArbiter: true,
      retryFailed: true,
      maxRetries: 2,
      aggregationStrategy: 'hierarchical',
      ...config
    };

    this.keyPool = new LockFreeKeyPool(FOUR_SAPI_KEYS);
    this.router = new SmartRouter({
      keys: FOUR_SAPI_KEYS,
      defaultTimeout: this.config.timeout
    });
    
    this.roleOutputs = new Map();
    this.setupEventHandlers();
  }

  /**
   * 执行完整4AI工作流
   * 
   * @param prompt 用户输入
   * @param context 可选上下文
   * @returns 4AI工作流结果
   */
  async executeWorkflow(
    prompt: string,
    context?: Record<string, any>
  ): Promise<FourAIWorkflowResult> {
    const workflowId = this.generateWorkflowId();
    this.emit('workflow-start', { workflowId, prompt, timestamp: Date.now() });

    try {
      // 根据模式执行
      let result: ParallelExecutionResult;
      
      switch (this.config.mode) {
        case 'sequential':
          result = await this.executeSequential(workflowId, prompt, context);
          break;
        case 'hybrid':
          result = await this.executeHybrid(workflowId, prompt, context);
          break;
        case 'parallel':
        default:
          result = await this.executeParallel(workflowId, prompt, context);
          break;
      }

      // 聚合结果
      const finalResult = this.aggregateResults(result);
      
      this.emit('workflow-complete', { 
        workflowId, 
        result: finalResult, 
        timestamp: Date.now() 
      });

      return finalResult;

    } catch (error) {
      this.emit('workflow-error', { workflowId, error, timestamp: Date.now() });
      throw error;
    }
  }

  /**
   * 并行执行所有角色
   */
  private async executeParallel(
    workflowId: string,
    prompt: string,
    context?: Record<string, any>
  ): Promise<ParallelExecutionResult> {
    const roles: FourAIRole[] = ['clarifier', 'builder', 'reviewer'];
    
    if (this.config.enableArbiter) {
      roles.push('arbiter');
    }

    const outputs = new Map<FourAIRole, RoleOutput>();
    const completed: FourAIRole[] = [];
    const failed: FourAIRole[] = [];
    const startTime = Date.now();

    // 并行执行所有角色
    const promises = roles.map(async (role) => {
      try {
        const output = await this.executeRole(role, prompt, context);
        outputs.set(role, output);
        completed.push(role);
        this.emit('role-complete', { workflowId, role, output });
      } catch (error) {
        failed.push(role);
        this.emit('role-error', { workflowId, role, error });
        
        if (this.config.retryFailed) {
          await this.retryRole(workflowId, role, prompt, context, outputs);
        }
      }
    });

    await Promise.all(promises);

    // 如果Arbiter失败但其他角色成功，尝试用简单聚合替代
    let arbiterDecision: ArbiterDecision | undefined;
    if (this.config.enableArbiter) {
      if (completed.includes('arbiter')) {
        arbiterDecision = this.parseArbiterDecision(outputs.get('arbiter')!);
      } else if (completed.length >= 2) {
        arbiterDecision = this.fallbackAggregation(outputs);
      }
    }

    return {
      outputs,
      completed,
      failed,
      totalLatency: Date.now() - startTime,
      arbiterDecision
    };
  }

  /**
   * 顺序执行（用于特定场景）
   */
  private async executeSequential(
    workflowId: string,
    prompt: string,
    context?: Record<string, any>
  ): Promise<ParallelExecutionResult> {
    const outputs = new Map<FourAIRole, RoleOutput>();
    const completed: FourAIRole[] = [];
    const failed: FourAIRole[] = [];
    const startTime = Date.now();

    // Clarifier → Builder → Reviewer → Arbiter
    const sequence: FourAIRole[] = ['clarifier', 'builder', 'reviewer', 'arbiter'];

    for (const role of sequence) {
      try {
        const roleContext = this.buildSequentialContext(role, outputs);
        const output = await this.executeRole(role, prompt, { ...context, ...roleContext });
        outputs.set(role, output);
        completed.push(role);
        this.emit('role-complete', { workflowId, role, output });
      } catch (error) {
        failed.push(role);
        this.emit('role-error', { workflowId, role, error });
        if (!this.config.retryFailed || !await this.retryRole(workflowId, role, prompt, context, outputs)) {
          break; // 顺序模式下，失败即停止
        }
      }
    }

    return {
      outputs,
      completed,
      failed,
      totalLatency: Date.now() - startTime,
      arbiterDecision: outputs.has('arbiter') 
        ? this.parseArbiterDecision(outputs.get('arbiter')!)
        : undefined
    };
  }

  /**
   * 混合执行（Clarifier+Builder并行，然后Reviewer，最后Arbiter）
   */
  private async executeHybrid(
    workflowId: string,
    prompt: string,
    context?: Record<string, any>
  ): Promise<ParallelExecutionResult> {
    const outputs = new Map<FourAIRole, RoleOutput>();
    const completed: FourAIRole[] = [];
    const failed: FourAIRole[] = [];
    const startTime = Date.now();

    // Phase 1: Clarifier + Builder 并行
    await Promise.all([
      this.executeRole('clarifier', prompt, context)
        .then(o => { outputs.set('clarifier', o); completed.push('clarifier'); })
        .catch(e => { failed.push('clarifier'); }),
      this.executeRole('builder', prompt, context)
        .then(o => { outputs.set('builder', o); completed.push('builder'); })
        .catch(e => { failed.push('builder'); })
    ]);

    // Phase 2: Reviewer（基于Phase 1结果）
    if (completed.length >= 1) {
      try {
        const reviewContext = this.buildSequentialContext('reviewer', outputs);
        const reviewerOutput = await this.executeRole('reviewer', prompt, { ...context, ...reviewContext });
        outputs.set('reviewer', reviewerOutput);
        completed.push('reviewer');
      } catch (error) {
        failed.push('reviewer');
      }
    }

    // Phase 3: Arbiter（基于所有结果）
    if (this.config.enableArbiter && completed.length >= 2) {
      try {
        const arbiterContext = this.buildSequentialContext('arbiter', outputs);
        const arbiterOutput = await this.executeRole('arbiter', prompt, { ...context, ...arbiterContext });
        outputs.set('arbiter', arbiterOutput);
        completed.push('arbiter');
      } catch (error) {
        failed.push('arbiter');
      }
    }

    return {
      outputs,
      completed,
      failed,
      totalLatency: Date.now() - startTime,
      arbiterDecision: outputs.has('arbiter')
        ? this.parseArbiterDecision(outputs.get('arbiter')!)
        : this.fallbackAggregation(outputs)
    };
  }

  /**
   * 执行单个角色
   */
  private async executeRole(
    role: FourAIRole,
    prompt: string,
    context?: Record<string, any>
  ): Promise<RoleOutput> {
    const startTime = Date.now();
    const roleConfig = ROLE_MODELS[role];

    // 构建角色特定的系统提示
    const systemPrompt = this.buildSystemPrompt(role);
    
    // 构建消息
    const messages: Message[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: this.buildUserPrompt(role, prompt, context) }
    ];

    // 路由请求
    const routingDecision = await this.router.route({
      prompt: messages.map(m => m.content).join('\n'),
      preferredRole: role,
      mode: role === 'arbiter' ? 'think' : 'fast'
    });

    // 模拟API调用（实际项目中应替换为真实API调用）
    const response = await this.callModelAPI(routingDecision, messages);

    return {
      role,
      content: response.content,
      model: routingDecision.model,
      latency: Date.now() - startTime,
      tokens: response.usage,
      confidence: this.calculateConfidence(role, response),
      timestamp: Date.now()
    };
  }

  /**
   * 重试失败的角色
   */
  private async retryRole(
    workflowId: string,
    role: FourAIRole,
    prompt: string,
    context: Record<string, any> | undefined,
    outputs: Map<FourAIRole, RoleOutput>
  ): Promise<boolean> {
    for (let i = 0; i < this.config.maxRetries; i++) {
      this.emit('role-retry', { workflowId, role, attempt: i + 1 });
      
      try {
        await new Promise(r => setTimeout(r, 1000 * (i + 1))); // 指数退避
        const output = await this.executeRole(role, prompt, context);
        outputs.set(role, output);
        this.emit('role-retry-success', { workflowId, role, attempt: i + 1 });
        return true;
      } catch (error) {
        this.emit('role-retry-failed', { workflowId, role, attempt: i + 1, error });
      }
    }
    return false;
  }

  /**
   * 调用模型API
   */
  private async callModelAPI(
    decision: RoutingDecision,
    messages: Message[]
  ): Promise<{ content: string; usage: TokenUsage }> {
    const key = this.keyPool.getNextKey();
    if (!key) {
      throw new Error('No available API keys');
    }

    // 实际API调用（示例）
    const response = await fetch('https://api.4sapi.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: decision.model,
        messages,
        temperature: 0.2,
        max_tokens: 4096
      })
    });

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status}`);
    }

    const data = await response.json() as { choices: Array<{ message: { content: string } }>; usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number } };
    
    return {
      content: data.choices[0].message.content,
      usage: {
        promptTokens: data.usage.prompt_tokens,
        completionTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens
      }
    };
  }

  /**
   * 构建系统提示
   */
  private buildSystemPrompt(role: FourAIRole): string {
    const prompts: Record<FourAIRole, string> = {
      clarifier: `你是4AI工作流的Clarifier角色。你的任务是：
1. 深入分析用户需求，提取关键信息
2. 识别潜在的模糊点和边界条件
3. 将复杂需求分解为可执行的任务
4. 输出结构化的需求分析文档

输出格式要求：
- 需求摘要（一句话概括）
- 核心目标（3-5条）
- 约束条件
- 潜在风险
- 建议方案`,

      builder: `你是4AI工作流的Builder角色。你的任务是：
1. 基于需求分析，设计技术方案
2. 生成高质量的代码/架构设计
3. 考虑性能、可维护性和扩展性
4. 输出完整的实现方案

输出格式要求：
- 架构设计
- 核心模块说明
- 代码实现（如适用）
- 依赖关系
- 部署建议`,

      reviewer: `你是4AI工作流的Reviewer角色。你的任务是：
1. 审查Builder生成的方案/代码
2. 识别潜在问题和改进点
3. 评估质量和安全性
4. 输出审查报告

输出格式要求：
- 审查摘要
- 发现的问题（按严重程度分类）
- 改进建议
- 质量评分（0-100）
- 是否通过审查`,

      arbiter: `你是4AI工作流的Arbiter角色。你的任务是：
1. 综合所有角色的输出
2. 做出最终决策
3. 解决角色间的分歧
4. 输出最终方案

输出格式要求：
- 决策依据
- 最终输出（整合后的方案）
- 采用的角色建议
- 置信度评估
- 后续步骤`
    };

    return prompts[role];
  }

  /**
   * 构建用户提示
   */
  private buildUserPrompt(
    role: FourAIRole,
    prompt: string,
    context?: Record<string, any>
  ): string {
    let userPrompt = `原始需求：\n${prompt}\n\n`;

    if (context) {
      userPrompt += `上下文信息：\n${JSON.stringify(context, null, 2)}\n\n`;
    }

    userPrompt += `请以${role}角色的身份，按照系统提示的要求输出结果。`;

    return userPrompt;
  }

  /**
   * 构建顺序执行上下文
   */
  private buildSequentialContext(
    currentRole: FourAIRole,
    outputs: Map<FourAIRole, RoleOutput>
  ): Record<string, any> {
    const context: Record<string, any> = {};

    switch (currentRole) {
      case 'builder':
        if (outputs.has('clarifier')) {
          context.clarifierOutput = outputs.get('clarifier')!.content;
        }
        break;
      case 'reviewer':
        if (outputs.has('clarifier')) {
          context.clarifierOutput = outputs.get('clarifier')!.content;
        }
        if (outputs.has('builder')) {
          context.builderOutput = outputs.get('builder')!.content;
        }
        break;
      case 'arbiter':
        outputs.forEach((output, role) => {
          if (role !== 'arbiter') {
            context[`${role}Output`] = output.content;
          }
        });
        break;
    }

    return context;
  }

  /**
   * 解析Arbiter决策
   */
  private parseArbiterDecision(output: RoleOutput): ArbiterDecision {
    try {
      // 尝试从Arbiter输出中提取结构化决策
      const content = output.content;
      
      // 简单的启发式解析
      const confidenceMatch = content.match(/置信度[:：]\s*(\d+(?:\.\d+)?)/);
      const confidence = confidenceMatch ? parseFloat(confidenceMatch[1]) / 100 : 0.85;

      return {
        finalOutput: content,
        reasoning: 'Arbiter综合决策',
        selectedRoles: ['clarifier', 'builder', 'reviewer'],
        confidence,
        aggregationStrategy: this.config.aggregationStrategy
      };
    } catch {
      return {
        finalOutput: output.content,
        reasoning: 'Arbiter原始输出',
        selectedRoles: ['arbiter'],
        confidence: 0.8,
        aggregationStrategy: 'best'
      };
    }
  }

  /**
   * 备用聚合策略（当Arbiter失败时）
   */
  private fallbackAggregation(outputs: Map<FourAIRole, RoleOutput>): ArbiterDecision {
    const availableOutputs = Array.from(outputs.entries());
    
    switch (this.config.aggregationStrategy) {
      case 'best': {
        // 选择置信度最高的输出
        let bestRole = availableOutputs[0][0];
        let bestOutput = availableOutputs[0][1];
        for (const [role, output] of availableOutputs) {
          if (output.confidence > bestOutput.confidence) {
            bestRole = role;
            bestOutput = output;
          }
        }
        return {
          finalOutput: bestOutput.content,
          reasoning: `选择${bestRole}的输出（置信度最高）`,
          selectedRoles: [bestRole],
          confidence: bestOutput.confidence,
          aggregationStrategy: 'best'
        };
      }

      case 'merge':
        // 合并所有输出
        const merged = availableOutputs.map(([role, output]) => 
          `=== ${role.toUpperCase()} ===\n${output.content}`
        ).join('\n\n');
        return {
          finalOutput: merged,
          reasoning: '合并所有角色的输出',
          selectedRoles: availableOutputs.map(([role]) => role),
          confidence: availableOutputs.reduce((sum, [, o]) => sum + o.confidence, 0) / availableOutputs.length,
          aggregationStrategy: 'merge'
        };

      case 'voting':
        // 简单多数（简化实现）
        return {
          finalOutput: availableOutputs[0][1].content,
          reasoning: '基于投票的决策',
          selectedRoles: availableOutputs.map(([role]) => role),
          confidence: 0.75,
          aggregationStrategy: 'voting'
        };

      case 'hierarchical':
      default:
        // 优先级：Arbiter > Reviewer > Builder > Clarifier
        const priority: FourAIRole[] = ['arbiter', 'reviewer', 'builder', 'clarifier'];
        for (const role of priority) {
          if (outputs.has(role)) {
            const output = outputs.get(role)!;
            return {
              finalOutput: output.content,
              reasoning: `选择优先级最高的${role}输出`,
              selectedRoles: [role],
              confidence: output.confidence,
              aggregationStrategy: 'hierarchical'
            };
          }
        }
        return {
          finalOutput: '',
          reasoning: '无可用输出',
          selectedRoles: [],
          confidence: 0,
          aggregationStrategy: 'hierarchical'
        };
    }
  }

  /**
   * 聚合执行结果
   */
  private aggregateResults(result: ParallelExecutionResult): FourAIWorkflowResult {
    const outputs = result.outputs;

    return {
      clarifierOutput: outputs.get('clarifier')?.content || '',
      builderOutput: outputs.get('builder')?.content || '',
      reviewerOutput: outputs.get('reviewer')?.content || '',
      arbiterOutput: outputs.get('arbiter')?.content || '',
      finalOutput: result.arbiterDecision?.finalOutput || outputs.get('builder')?.content || '',
      metadata: {
        totalDuration: result.totalLatency,
        totalTokens: Array.from(outputs.values()).reduce(
          (sum, o) => sum + o.tokens.totalTokens, 0
        ),
        confidenceScore: result.arbiterDecision?.confidence || 
          Array.from(outputs.values()).reduce((sum, o) => sum + o.confidence, 0) / outputs.size
      }
    };
  }

  /**
   * 计算置信度
   */
  private calculateConfidence(role: FourAIRole, response: { content: string }): number {
    // 简化的置信度计算
    const content = response.content;
    let confidence = 0.8;

    // 基于内容质量的启发式评分
    if (content.length > 500) confidence += 0.05;
    if (content.includes('```')) confidence += 0.05;
    if (content.includes('结论') || content.includes('总结')) confidence += 0.05;
    
    return Math.min(confidence, 0.98);
  }

  /**
   * 生成工作流ID
   */
  private generateWorkflowId(): string {
    return `4ai-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 设置事件处理器
   */
  private setupEventHandlers(): void {
    this.on('workflow-start', (event) => {
      console.log(`[4AI] Workflow started: ${event.workflowId}`);
    });

    this.on('workflow-complete', (event) => {
      console.log(`[4AI] Workflow completed: ${event.workflowId}`);
    });

    this.on('role-error', (event) => {
      console.warn(`[4AI] Role ${event.role} failed in workflow ${event.workflowId}`);
    });
  }

  /**
   * 获取配置
   */
  getConfig(): WorkflowExecutionConfig {
    return { ...this.config };
  }

  /**
   * 更新配置
   */
  updateConfig(config: Partial<WorkflowExecutionConfig>): void {
    this.config = { ...this.config, ...config };
  }

  /**
   * 关闭适配器
   */
  shutdown(): void {
    this.router.shutdown();
    this.removeAllListeners();
  }
}

export default FourAIWorkflowAdapter;
