/**
 * oh-my-codex适配器
 * @module adapter/OhMyCodexAdapter
 * @version 2.0.0
 * @description 将oh-my-codex工作流映射到4AI角色系统
 * 
 * oh-my-codex模式映射:
 * - $team 模式 → 4AI并行审查
 * - $ri   模式 → 4AI持久执行循环
 * - $ralph模式 → 4AI架构师验证
 * 
 * 特性:
 * - 模式自动识别
 * - 工作流转换
 * - 结果后处理
 * - 状态持久化
 */

import { EventEmitter } from 'events';
import { FourAIWorkflowAdapter, FourAIRole, RoleOutput, WorkflowExecutionConfig } from './4AIWorkflowAdapter';
import { RoutingDecision, TokenUsage } from '../types';

/**
 * oh-my-codex工作流模式
 */
export type OhMyCodexMode = 'team' | 'ri' | 'ralph' | 'auto';

/**
 * oh-my-codex配置
 */
export interface OhMyCodexConfig {
  mode: OhMyCodexMode;
  teamSize?: number;
  maxIterations?: number;
  confidenceThreshold?: number;
  enablePersistence?: boolean;
  workspacePath?: string;
}

/**
 * $team模式结果
 */
export interface TeamModeResult {
  primaryOutput: string;
  peerReviews: PeerReview[];
  consensusScore: number;
  finalDecision: string;
  dissentingOpinions?: string[];
}

/**
 * 同行评审
 */
export interface PeerReview {
  reviewer: string;
  feedback: string;
  score: number;
  suggestions: string[];
}

/**
 * $ri模式结果
 */
export interface RiModeResult {
  iterations: RiIteration[];
  finalOutput: string;
  improvementHistory: ImprovementRecord[];
  convergenceScore: number;
}

/**
 * $ri迭代
 */
export interface RiIteration {
  iteration: number;
  output: string;
  qualityScore: number;
  reviewerFeedback: string;
  improvements: string[];
}

/**
 * 改进记录
 */
export interface ImprovementRecord {
  iteration: number;
  metric: string;
  before: number;
  after: number;
  delta: number;
}

/**
 * $ralph模式结果
 */
export interface RalphModeResult {
  architecture: string;
  validationReport: ValidationReport;
  riskAssessment: RiskAssessment;
  recommendations: string[];
}

/**
 * 验证报告
 */
export interface ValidationReport {
  passed: boolean;
  checks: ValidationCheck[];
  overallScore: number;
}

/**
 * 验证检查项
 */
export interface ValidationCheck {
  name: string;
  passed: boolean;
  score: number;
  details: string;
}

/**
 * 风险评估
 */
export interface RiskAssessment {
  level: 'low' | 'medium' | 'high' | 'critical';
  risks: RiskItem[];
  mitigations: string[];
}

/**
 * 风险项
 */
export interface RiskItem {
  category: string;
  description: string;
  probability: number;
  impact: number;
  mitigation: string;
}

/**
 * oh-my-codex请求
 */
export interface OhMyCodexRequest {
  prompt: string;
  mode?: OhMyCodexMode;
  context?: Record<string, any>;
  constraints?: string[];
  previousIterations?: RiIteration[];
}

/**
 * oh-my-codex适配器
 */
export class OhMyCodexAdapter extends EventEmitter {
  private fourAI: FourAIWorkflowAdapter;
  private config: OhMyCodexConfig;
  private executionHistory: Map<string, any>;

  /**
   * 构造函数
   */
  constructor(config?: Partial<OhMyCodexConfig>) {
    super();

    this.config = {
      mode: 'auto',
      teamSize: 3,
      maxIterations: 5,
      confidenceThreshold: 0.85,
      enablePersistence: true,
      workspacePath: './.oh-my-codex',
      ...config
    };

    this.executionHistory = new Map();
    this.fourAI = new FourAIWorkflowAdapter({
      mode: 'parallel',
      timeout: 120000,
      enableArbiter: true,
      retryFailed: true,
      maxRetries: 2,
      aggregationStrategy: 'hierarchical'
    });

    this.setupEventHandlers();
  }

  /**
   * 执行oh-my-codex工作流
   */
  async execute(request: OhMyCodexRequest): Promise<TeamModeResult | RiModeResult | RalphModeResult> {
    const executionId = this.generateExecutionId();
    const mode = request.mode || this.detectMode(request.prompt);

    this.emit('execution-start', { executionId, mode, prompt: request.prompt });

    try {
      let result: TeamModeResult | RiModeResult | RalphModeResult;

      switch (mode) {
        case 'team':
          result = await this.executeTeamMode(request, executionId);
          break;
        case 'ri':
          result = await this.executeRiMode(request, executionId);
          break;
        case 'ralph':
          result = await this.executeRalphMode(request, executionId);
          break;
        default:
          throw new Error(`Unknown mode: ${mode}`);
      }

      if (this.config.enablePersistence) {
        this.persistResult(executionId, result);
      }

      this.emit('execution-complete', { executionId, mode, result });
      return result;

    } catch (error) {
      this.emit('execution-error', { executionId, mode, error });
      throw error;
    }
  }

  /**
   * $team模式 - 4AI并行审查
   * 
 * 映射关系:
   * - Clarifier → 需求分析师
   * - Builder → 主开发者
   * - Reviewer → 代码审查员
   * - Arbiter → 技术负责人（裁决）
   */
  private async executeTeamMode(
    request: OhMyCodexRequest,
    executionId: string
  ): Promise<TeamModeResult> {
    this.emit('team-mode-start', { executionId, teamSize: this.config.teamSize });

    // 步骤1: Clarifier分析需求
    const clarifierOutput = await this.executeSingleRole('clarifier', request);
    
    // 步骤2: Builder并行开发
    const builderOutput = await this.executeSingleRole('builder', {
      ...request,
      context: { ...request.context, clarifierAnalysis: clarifierOutput.content }
    });

    // 步骤3: Reviewer并行审查（可配置多个reviewer）
    const peerReviews: PeerReview[] = [];
    const reviewPromises = Array.from({ length: this.config.teamSize! }, async (_, i) => {
      const review = await this.executeSingleRole('reviewer', {
        ...request,
        context: {
          ...request.context,
          implementation: builderOutput.content,
          reviewerIndex: i + 1
        }
      });
      
      return this.parsePeerReview(review);
    });

    peerReviews.push(...await Promise.all(reviewPromises));

    // 步骤4: Arbiter最终裁决
    const arbiterOutput = await this.executeSingleRole('arbiter', {
      ...request,
      context: {
        ...request.context,
        implementation: builderOutput.content,
        peerReviews: peerReviews.map(r => ({ reviewer: r.reviewer, score: r.score, feedback: r.feedback }))
      }
    });

    // 计算共识度
    const consensusScore = this.calculateConsensus(peerReviews);
    const dissentingOpinions = this.extractDissent(peerReviews);

    return {
      primaryOutput: builderOutput.content,
      peerReviews,
      consensusScore,
      finalDecision: arbiterOutput.content,
      dissentingOpinions: dissentingOpinions.length > 0 ? dissentingOpinions : undefined
    };
  }

  /**
   * $ri模式 - 4AI持久执行循环
   * 
   * 映射关系:
   * - Clarifier → 初始需求分析
   * - Builder → 迭代生成（多轮）
   * - Reviewer → 质量评估（每轮）
   * - Arbiter → 收敛判断
   */
  private async executeRiMode(
    request: OhMyCodexRequest,
    executionId: string
  ): Promise<RiModeResult> {
    this.emit('ri-mode-start', { executionId, maxIterations: this.config.maxIterations });

    const iterations: RiIteration[] = [];
    const improvementHistory: ImprovementRecord[] = [];
    let currentOutput = '';
    let converged = false;

    // 步骤1: Clarifier初始分析
    const clarifierOutput = await this.executeSingleRole('clarifier', request);
    
    for (let iteration = 1; iteration <= this.config.maxIterations!; iteration++) {
      this.emit('ri-iteration-start', { executionId, iteration });

      // 步骤2: Builder生成/改进
      const builderOutput = await this.executeSingleRole('builder', {
        ...request,
        context: {
          ...request.context,
          clarifierAnalysis: clarifierOutput.content,
          previousOutput: currentOutput,
          iteration,
          reviewerFeedback: iterations.length > 0 ? iterations[iterations.length - 1].reviewerFeedback : undefined
        }
      });

      currentOutput = builderOutput.content;

      // 步骤3: Reviewer评估
      const reviewerOutput = await this.executeSingleRole('reviewer', {
        ...request,
        context: {
          ...request.context,
          currentOutput,
          iteration
        }
      });

      const qualityScore = this.extractQualityScore(reviewerOutput);
      const improvements = this.extractImprovements(reviewerOutput);

      iterations.push({
        iteration,
        output: currentOutput,
        qualityScore,
        reviewerFeedback: reviewerOutput.content,
        improvements
      });

      // 记录改进
      if (iteration > 1) {
        const prevScore = iterations[iteration - 2].qualityScore;
        improvementHistory.push({
          iteration,
          metric: 'quality_score',
          before: prevScore,
          after: qualityScore,
          delta: qualityScore - prevScore
        });
      }

      this.emit('ri-iteration-complete', { executionId, iteration, qualityScore });

      // 步骤4: Arbiter判断是否收敛
      if (iteration >= 2) {
        const arbiterOutput = await this.executeSingleRole('arbiter', {
          ...request,
          context: {
            iterations: iterations.map(i => ({ iteration: i.iteration, score: i.qualityScore })),
            checkConvergence: true
          }
        });

        converged = this.checkConvergence(arbiterOutput, qualityScore);
        if (converged) {
          this.emit('ri-converged', { executionId, iteration });
          break;
        }
      }
    }

    return {
      iterations,
      finalOutput: currentOutput,
      improvementHistory,
      convergenceScore: iterations[iterations.length - 1]?.qualityScore || 0
    };
  }

  /**
   * $ralph模式 - 4AI架构师验证
   * 
   * 映射关系:
   * - Clarifier → 架构需求分析
   * - Builder → 架构设计
   * - Reviewer → 架构审查（安全/性能/可扩展性）
   * - Arbiter → 架构决策
   */
  private async executeRalphMode(
    request: OhMyCodexRequest,
    executionId: string
  ): Promise<RalphModeResult> {
    this.emit('ralph-mode-start', { executionId });

    // 步骤1: Clarifier架构需求分析
    const clarifierOutput = await this.executeSingleRole('clarifier', {
      ...request,
      context: { ...request.context, focus: 'architecture' }
    });

    // 步骤2: Builder架构设计
    const builderOutput = await this.executeSingleRole('builder', {
      ...request,
      context: {
        ...request.context,
        architectureRequirements: clarifierOutput.content,
        outputFormat: 'architecture_spec'
      }
    });

    // 步骤3: Reviewer架构审查（多维度）
    const validationChecks: ValidationCheck[] = [];
    
    const checkDimensions = [
      { name: '安全性检查', focus: 'security' },
      { name: '性能检查', focus: 'performance' },
      { name: '可扩展性检查', focus: 'scalability' },
      { name: '可维护性检查', focus: 'maintainability' }
    ];

    for (const dimension of checkDimensions) {
      const review = await this.executeSingleRole('reviewer', {
        ...request,
        context: {
          ...request.context,
          architecture: builderOutput.content,
          reviewFocus: dimension.focus
        }
      });

      validationChecks.push(this.parseValidationCheck(dimension.name, review));
    }

    // 步骤4: Arbiter架构决策
    const arbiterOutput = await this.executeSingleRole('arbiter', {
      ...request,
      context: {
        ...request.context,
        architecture: builderOutput.content,
        validationChecks: validationChecks.map(c => ({ name: c.name, passed: c.passed, score: c.score }))
      }
    });

    const validationReport: ValidationReport = {
      passed: validationChecks.every(c => c.passed),
      checks: validationChecks,
      overallScore: validationChecks.reduce((sum, c) => sum + c.score, 0) / validationChecks.length
    };

    return {
      architecture: builderOutput.content,
      validationReport,
      riskAssessment: this.parseRiskAssessment(arbiterOutput),
      recommendations: this.extractRecommendations(arbiterOutput)
    };
  }

  /**
   * 执行单个角色
   */
  private async executeSingleRole(
    role: FourAIRole,
    request: OhMyCodexRequest
  ): Promise<RoleOutput> {
    // 通过4AI执行单个角色
    const workflowConfig: WorkflowExecutionConfig = {
      mode: 'sequential',
      timeout: 60000,
      enableArbiter: false,
      retryFailed: true,
      maxRetries: 2,
      aggregationStrategy: 'best'
    };

    // 这里简化实现，实际应调用4AIWorkflowAdapter的单个角色执行
    // 为简化，我们使用完整工作流但只取对应角色输出
    const result = await this.fourAI.executeWorkflow(request.prompt, request.context);
    
    return {
      role,
      content: this.getRoleOutput(role, result),
      model: '4sapi',
      latency: result.metadata.totalDuration,
      tokens: {
        promptTokens: Math.floor(result.metadata.totalTokens * 0.3),
        completionTokens: Math.floor(result.metadata.totalTokens * 0.7),
        totalTokens: result.metadata.totalTokens
      },
      confidence: result.metadata.confidenceScore,
      timestamp: Date.now()
    };
  }

  /**
   * 获取角色输出
   */
  private getRoleOutput(role: FourAIRole, result: any): string {
    switch (role) {
      case 'clarifier': return result.clarifierOutput;
      case 'builder': return result.builderOutput;
      case 'reviewer': return result.reviewerOutput;
      case 'arbiter': return result.arbiterOutput;
      default: return '';
    }
  }

  /**
   * 解析同行评审
   */
  private parsePeerReview(review: RoleOutput): PeerReview {
    const content = review.content;
    
    // 启发式解析评分
    const scoreMatch = content.match(/评分[:：]\s*(\d+)/) || 
                      content.match(/(\d+)\s*分/) ||
                      content.match(/score[:\s]+(\d+)/i);
    const score = scoreMatch ? parseInt(scoreMatch[1]) : 80;

    // 解析建议
    const suggestions: string[] = [];
    const suggestionMatches = content.matchAll(/[-*]\s*(.+)/g);
    for (const match of suggestionMatches) {
      if (match[1].length > 10) {
        suggestions.push(match[1].trim());
      }
    }

    return {
      reviewer: `Reviewer-${review.timestamp}`,
      feedback: content,
      score: Math.min(score, 100),
      suggestions: suggestions.slice(0, 5)
    };
  }

  /**
   * 解析验证检查
   */
  private parseValidationCheck(name: string, review: RoleOutput): ValidationCheck {
    const content = review.content;
    const passed = content.includes('通过') || content.includes('passed') || content.includes('✓');
    
    const scoreMatch = content.match(/(\d+)\s*分/) || content.match(/score[:\s]+(\d+)/i);
    const score = scoreMatch ? parseInt(scoreMatch[1]) : (passed ? 85 : 50);

    return {
      name,
      passed,
      score: Math.min(score, 100),
      details: content
    };
  }

  /**
   * 解析风险评估
   */
  private parseRiskAssessment(arbiterOutput: RoleOutput): RiskAssessment {
    const content = arbiterOutput.content;
    
    // 判断风险等级
    let level: RiskAssessment['level'] = 'low';
    if (content.includes('高风险') || content.includes('critical')) level = 'critical';
    else if (content.includes('中高风险') || content.includes('high')) level = 'high';
    else if (content.includes('中等风险') || content.includes('medium')) level = 'medium';

    // 提取风险项
    const risks: RiskItem[] = [];
    const riskMatches = content.matchAll(/风险[：:]\s*(.+)/g);
    for (const match of riskMatches) {
      risks.push({
        category: 'general',
        description: match[1],
        probability: 0.5,
        impact: 0.5,
        mitigation: '待评估'
      });
    }

    // 提取缓解措施
    const mitigations: string[] = [];
    const mitigationMatches = content.matchAll(/缓解[：:]\s*(.+)/g);
    for (const match of mitigationMatches) {
      mitigations.push(match[1]);
    }

    return { level, risks, mitigations };
  }

  /**
   * 提取质量分数
   */
  private extractQualityScore(review: RoleOutput): number {
    const content = review.content;
    const scoreMatch = content.match(/(\d+)\s*分/) || 
                      content.match(/quality[:\s]+(\d+)/i) ||
                      content.match(/score[:\s]+(\d+)/i);
    return scoreMatch ? parseInt(scoreMatch[1]) : 75;
  }

  /**
   * 提取改进点
   */
  private extractImprovements(review: RoleOutput): string[] {
    const content = review.content;
    const improvements: string[] = [];
    
    const matches = content.matchAll(/改进[：:]\s*(.+)/g);
    for (const match of matches) {
      improvements.push(match[1]);
    }

    return improvements;
  }

  /**
   * 提取建议
   */
  private extractRecommendations(arbiterOutput: RoleOutput): string[] {
    const content = arbiterOutput.content;
    const recommendations: string[] = [];
    
    const matches = content.matchAll(/建议[：:]\s*(.+)/g);
    for (const match of matches) {
      recommendations.push(match[1]);
    }

    return recommendations;
  }

  /**
   * 计算共识度
   */
  private calculateConsensus(reviews: PeerReview[]): number {
    if (reviews.length === 0) return 0;
    
    const avgScore = reviews.reduce((sum, r) => sum + r.score, 0) / reviews.length;
    const variance = reviews.reduce((sum, r) => sum + Math.pow(r.score - avgScore, 2), 0) / reviews.length;
    const stdDev = Math.sqrt(variance);
    
    // 共识度 = 100 - 标准差
    return Math.max(0, 100 - stdDev);
  }

  /**
   * 提取分歧意见
   */
  private extractDissent(reviews: PeerReview[]): string[] {
    const avgScore = reviews.reduce((sum, r) => sum + r.score, 0) / reviews.length;
    const dissenters = reviews.filter(r => r.score < avgScore - 15);
    
    return dissenters.map(r => r.feedback.substring(0, 200));
  }

  /**
   * 检查收敛
   */
  private checkConvergence(arbiterOutput: RoleOutput, currentScore: number): boolean {
    const content = arbiterOutput.content;
    
    // 基于内容判断
    if (content.includes('收敛') || content.includes('converged')) return true;
    if (content.includes('完成') || content.includes('sufficient')) return true;
    
    // 基于分数判断
    return currentScore >= (this.config.confidenceThreshold! * 100);
  }

  /**
   * 检测模式
   */
  private detectMode(prompt: string): OhMyCodexMode {
    const lowerPrompt = prompt.toLowerCase();
    
    if (lowerPrompt.includes('$team') || lowerPrompt.includes('team review')) {
      return 'team';
    }
    if (lowerPrompt.includes('$ri') || lowerPrompt.includes('iterative') || lowerPrompt.includes('迭代')) {
      return 'ri';
    }
    if (lowerPrompt.includes('$ralph') || lowerPrompt.includes('architecture') || lowerPrompt.includes('架构')) {
      return 'ralph';
    }
    
    // 默认模式
    return 'team';
  }

  /**
   * 持久化结果
   */
  private persistResult(executionId: string, result: any): void {
    this.executionHistory.set(executionId, {
      timestamp: Date.now(),
      result
    });
  }

  /**
   * 获取执行历史
   */
  getExecutionHistory(executionId?: string): any {
    if (executionId) {
      return this.executionHistory.get(executionId);
    }
    return Array.from(this.executionHistory.entries());
  }

  /**
   * 生成执行ID
   */
  private generateExecutionId(): string {
    return `omc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 设置事件处理器
   */
  private setupEventHandlers(): void {
    this.on('execution-start', (event) => {
      console.log(`[oh-my-codex] ${event.mode} mode started: ${event.executionId}`);
    });

    this.on('execution-complete', (event) => {
      console.log(`[oh-my-codex] ${event.mode} mode completed: ${event.executionId}`);
    });
  }

  /**
   * 关闭适配器
   */
  shutdown(): void {
    this.fourAI.shutdown();
    this.removeAllListeners();
  }
}

export default OhMyCodexAdapter;
