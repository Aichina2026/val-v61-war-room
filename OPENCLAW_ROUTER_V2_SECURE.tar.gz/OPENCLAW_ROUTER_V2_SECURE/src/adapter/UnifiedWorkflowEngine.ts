/**
 * 统一工作流引擎
 * @module adapter/UnifiedWorkflowEngine
 * @version 2.0.0
 * @description 统一工作流引擎，协调4AI/oh-my-codex/free-code工作流
 * 
 * 核心功能:
 * - 4AI工作流调度
 * - oh-my-codex工作流调度
 * - free-code工作流调度
 * - 工作流状态管理
 * - 智能工作流选择
 * 
 * 工作流选择策略:
 * - 基于任务类型自动选择
 * - 基于复杂度自适应
 * - 用户显式指定
 */

import { EventEmitter } from 'events';
import { FourAIWorkflowAdapter } from './4AIWorkflowAdapter';
import { FourAIWorkflowResult } from '../types';
import { OhMyCodexAdapter, OhMyCodexMode, TeamModeResult, RiModeResult, RalphModeResult } from './OhMyCodexAdapter';
import { FreeCodeAdapter, FreeCodeRequest, FreeCodeResult, FreeCodeTaskType } from './FreeCodeAdapter';

/**
 * 工作流类型
 */
export type WorkflowType = '4ai' | 'oh-my-codex' | 'free-code' | 'auto';

/**
 * 工作流状态
 */
export type WorkflowStatus = 
  | 'pending'
  | 'queued'
  | 'running'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'cancelled';

/**
 * 统一工作流请求
 */
export interface UnifiedWorkflowRequest {
  /** 工作流类型 */
  type?: WorkflowType;
  /** 用户提示 */
  prompt: string;
  /** 上下文 */
  context?: Record<string, any>;
  /** 工作流特定配置 */
  config?: WorkflowConfig;
  /** 优先级 */
  priority?: number;
  /** 超时时间（毫秒） */
  timeout?: number;
  /** 标签 */
  tags?: string[];
}

/**
 * 工作流配置
 */
export interface WorkflowConfig {
  /** 4AI配置 */
  fourAI?: {
    mode?: 'parallel' | 'sequential' | 'hybrid';
    enableArbiter?: boolean;
    aggregationStrategy?: 'best' | 'merge' | 'voting' | 'hierarchical';
  };
  /** oh-my-codex配置 */
  ohMyCodex?: {
    mode?: OhMyCodexMode;
    teamSize?: number;
    maxIterations?: number;
  };
  /** free-code配置 */
  freeCode?: {
    task?: FreeCodeTaskType;
    project?: {
      name: string;
      path: string;
      language: string;
    };
  };
}

/**
 * 统一工作流结果
 */
export interface UnifiedWorkflowResult {
  /** 工作流ID */
  workflowId: string;
  /** 工作流类型 */
  type: WorkflowType;
  /** 执行状态 */
  status: WorkflowStatus;
  /** 结果内容 */
  content: string;
  /** 原始结果 */
  rawResult: FourAIWorkflowResult | TeamModeResult | RiModeResult | RalphModeResult | FreeCodeResult;
  /** 执行元数据 */
  metadata: WorkflowMetadata;
  /** 执行历史 */
  history: WorkflowStep[];
}

/**
 * 工作流元数据
 */
export interface WorkflowMetadata {
  /** 总耗时（毫秒） */
  duration: number;
  /** Token使用量 */
  tokensUsed: number;
  /** 置信度（0-1） */
  confidence: number;
  /** 开始时间 */
  startTime: number;
  /** 结束时间 */
  endTime: number;
  /** 重试次数 */
  retries: number;
  /** 实际使用的工作流 */
  resolvedType: WorkflowType;
}

/**
 * 工作流步骤
 */
export interface WorkflowStep {
  /** 步骤名称 */
  name: string;
  /** 步骤类型 */
  type: string;
  /** 开始时间 */
  startTime: number;
  /** 结束时间 */
  endTime?: number;
  /** 状态 */
  status: WorkflowStatus;
  /** 输出 */
  output?: string;
  /** 错误信息 */
  error?: string;
}

/**
 * 工作流队列项
 */
interface WorkflowQueueItem {
  id: string;
  request: UnifiedWorkflowRequest;
  resolve: (value: UnifiedWorkflowResult) => void;
  reject: (reason: any) => void;
  enqueueTime: number;
  priority: number;
}

/**
 * 活跃工作流
 */
interface ActiveWorkflow {
  id: string;
  request: UnifiedWorkflowRequest;
  status: WorkflowStatus;
  startTime: number;
  steps: WorkflowStep[];
  abortController: AbortController;
}

/**
 * 工作流统计
 */
export interface WorkflowStats {
  total: number;
  pending: number;
  running: number;
  completed: number;
  failed: number;
  avgDuration: number;
  avgConfidence: number;
}

/**
 * 统一工作流引擎
 */
export class UnifiedWorkflowEngine extends EventEmitter {
  private fourAI: FourAIWorkflowAdapter;
  private ohMyCodex: OhMyCodexAdapter;
  private freeCode: FreeCodeAdapter;
  
  private queue: WorkflowQueueItem[];
  private activeWorkflows: Map<string, ActiveWorkflow>;
  private completedWorkflows: Map<string, UnifiedWorkflowResult>;
  
  private maxConcurrent: number;
  private isProcessing: boolean;
  private defaultTimeout: number;

  /**
   * 构造函数
   */
  constructor(options?: {
    maxConcurrent?: number;
    defaultTimeout?: number;
  }) {
    super();

    this.fourAI = new FourAIWorkflowAdapter();
    this.ohMyCodex = new OhMyCodexAdapter();
    this.freeCode = new FreeCodeAdapter();

    this.queue = [];
    this.activeWorkflows = new Map();
    this.completedWorkflows = new Map();

    this.maxConcurrent = options?.maxConcurrent || 5;
    this.defaultTimeout = options?.defaultTimeout || 300000;
    this.isProcessing = false;

    this.setupEventHandlers();
  }

  /**
   * 执行工作流
   */
  async execute(request: UnifiedWorkflowRequest): Promise<UnifiedWorkflowResult> {
    const workflowId = this.generateWorkflowId();
    
    this.emit('workflow-queued', { workflowId, request });

    return new Promise((resolve, reject) => {
      const queueItem: WorkflowQueueItem = {
        id: workflowId,
        request,
        resolve,
        reject,
        enqueueTime: Date.now(),
        priority: request.priority || 0
      };

      // 添加到队列（按优先级排序）
      this.insertByPriority(queueItem);
      
      // 启动处理
      this.processQueue();
    });
  }

  /**
   * 批量执行工作流
   */
  async executeBatch(
    requests: UnifiedWorkflowRequest[],
    options?: { concurrency?: number; stopOnError?: boolean }
  ): Promise<UnifiedWorkflowResult[]> {
    const concurrency = options?.concurrency || this.maxConcurrent;
    const stopOnError = options?.stopOnError ?? false;
    
    const results: UnifiedWorkflowResult[] = [];
    const errors: { index: number; error: any }[] = [];

    // 使用信号量控制并发
    const semaphore = new Semaphore(concurrency);

    await Promise.all(
      requests.map(async (request, index) => {
        await semaphore.acquire();
        try {
          const result = await this.execute(request);
          results[index] = result;
        } catch (error) {
          errors.push({ index, error });
          if (stopOnError) {
            throw error;
          }
        } finally {
          semaphore.release();
        }
      })
    );

    if (stopOnError && errors.length > 0) {
      throw errors[0].error;
    }

    return results;
  }

  /**
   * 取消工作流
   */
  cancel(workflowId: string): boolean {
    // 检查活跃工作流
    const active = this.activeWorkflows.get(workflowId);
    if (active) {
      active.abortController.abort();
      active.status = 'cancelled';
      this.activeWorkflows.delete(workflowId);
      this.emit('workflow-cancelled', { workflowId });
      return true;
    }

    // 检查队列
    const queueIndex = this.queue.findIndex(item => item.id === workflowId);
    if (queueIndex !== -1) {
      const item = this.queue.splice(queueIndex, 1)[0];
      item.reject(new Error('Workflow cancelled'));
      this.emit('workflow-cancelled', { workflowId });
      return true;
    }

    return false;
  }

  /**
   * 暂停工作流
   */
  pause(workflowId: string): boolean {
    const active = this.activeWorkflows.get(workflowId);
    if (active && active.status === 'running') {
      active.status = 'paused';
      this.emit('workflow-paused', { workflowId });
      return true;
    }
    return false;
  }

  /**
   * 恢复工作流
   */
  resume(workflowId: string): boolean {
    const active = this.activeWorkflows.get(workflowId);
    if (active && active.status === 'paused') {
      active.status = 'running';
      this.emit('workflow-resumed', { workflowId });
      return true;
    }
    return false;
  }

  /**
   * 获取工作流状态
   */
  getWorkflowStatus(workflowId: string): WorkflowStatus | null {
    const active = this.activeWorkflows.get(workflowId);
    if (active) return active.status;

    const completed = this.completedWorkflows.get(workflowId);
    if (completed) return completed.status;

    const queued = this.queue.find(item => item.id === workflowId);
    if (queued) return 'queued';

    return null;
  }

  /**
   * 获取工作流结果
   */
  getWorkflowResult(workflowId: string): UnifiedWorkflowResult | null {
    return this.completedWorkflows.get(workflowId) || null;
  }

  /**
   * 获取统计信息
   */
  getStats(): WorkflowStats {
    const completed = Array.from(this.completedWorkflows.values());
    const totalDuration = completed.reduce((sum, r) => sum + r.metadata.duration, 0);
    const totalConfidence = completed.reduce((sum, r) => sum + r.metadata.confidence, 0);

    return {
      total: this.completedWorkflows.size + this.activeWorkflows.size + this.queue.length,
      pending: this.queue.length,
      running: this.activeWorkflows.size,
      completed: completed.filter(r => r.status === 'completed').length,
      failed: completed.filter(r => r.status === 'failed').length,
      avgDuration: completed.length > 0 ? totalDuration / completed.length : 0,
      avgConfidence: completed.length > 0 ? totalConfidence / completed.length : 0
    };
  }

  /**
   * 处理队列
   */
  private async processQueue(): Promise<void> {
    if (this.isProcessing) return;
    if (this.queue.length === 0) return;
    if (this.activeWorkflows.size >= this.maxConcurrent) return;

    this.isProcessing = true;

    try {
      while (
        this.queue.length > 0 && 
        this.activeWorkflows.size < this.maxConcurrent
      ) {
        const item = this.queue.shift()!;
        this.processWorkflow(item);
      }
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * 处理单个工作流
   */
  private async processWorkflow(item: WorkflowQueueItem): Promise<void> {
    const { id, request } = item;
    const startTime = Date.now();
    const abortController = new AbortController();

    const activeWorkflow: ActiveWorkflow = {
      id,
      request,
      status: 'running',
      startTime,
      steps: [],
      abortController
    };

    this.activeWorkflows.set(id, activeWorkflow);
    this.emit('workflow-start', { workflowId: id, request });

    try {
      const timeout = request.timeout || this.defaultTimeout;
      
      // 设置超时
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('Workflow timeout')), timeout);
      });

      // 执行工作流
      const executePromise = this.executeByType(request, activeWorkflow);

      const result = await Promise.race([executePromise, timeoutPromise]);

      // 构建统一结果
      const unifiedResult: UnifiedWorkflowResult = {
        workflowId: id,
        type: result.type,
        status: 'completed',
        content: result.content,
        rawResult: result.rawResult,
        metadata: {
          duration: Date.now() - startTime,
          tokensUsed: result.tokensUsed,
          confidence: result.confidence,
          startTime,
          endTime: Date.now(),
          retries: 0,
          resolvedType: result.type
        },
        history: activeWorkflow.steps
      };

      this.completedWorkflows.set(id, unifiedResult);
      this.activeWorkflows.delete(id);
      
      this.emit('workflow-complete', { workflowId: id, result: unifiedResult });
      item.resolve(unifiedResult);

    } catch (error) {
      activeWorkflow.status = 'failed';
      
      const failedResult: UnifiedWorkflowResult = {
        workflowId: id,
        type: this.resolveWorkflowType(request),
        status: 'failed',
        content: error instanceof Error ? error.message : String(error),
        rawResult: {} as any,
        metadata: {
          duration: Date.now() - startTime,
          tokensUsed: 0,
          confidence: 0,
          startTime,
          endTime: Date.now(),
          retries: 0,
          resolvedType: this.resolveWorkflowType(request)
        },
        history: activeWorkflow.steps
      };

      this.completedWorkflows.set(id, failedResult);
      this.activeWorkflows.delete(id);
      
      this.emit('workflow-error', { workflowId: id, error });
      item.reject(error);

    } finally {
      // 继续处理队列
      this.processQueue();
    }
  }

  /**
   * 根据类型执行工作流
   */
  private async executeByType(
    request: UnifiedWorkflowRequest,
    activeWorkflow: ActiveWorkflow
  ): Promise<{
    type: WorkflowType;
    content: string;
    rawResult: any;
    tokensUsed: number;
    confidence: number;
  }> {
    const type = this.resolveWorkflowType(request);
    
    this.addStep(activeWorkflow, 'resolve-type', 'system', { resolvedType: type });

    switch (type) {
      case '4ai':
        return this.execute4AI(request, activeWorkflow);
      case 'oh-my-codex':
        return this.executeOhMyCodex(request, activeWorkflow);
      case 'free-code':
        return this.executeFreeCode(request, activeWorkflow);
      default:
        throw new Error(`Unknown workflow type: ${type}`);
    }
  }

  /**
   * 执行4AI工作流
   */
  private async execute4AI(
    request: UnifiedWorkflowRequest,
    activeWorkflow: ActiveWorkflow
  ): Promise<{ type: WorkflowType; content: string; rawResult: any; tokensUsed: number; confidence: number }> {
    this.addStep(activeWorkflow, '4ai-execution', '4ai');

    const result = await this.fourAI.executeWorkflow(
      request.prompt,
      request.context
    );

    this.completeStep(activeWorkflow, '4ai-execution', { output: result.finalOutput });

    return {
      type: '4ai',
      content: result.finalOutput,
      rawResult: result,
      tokensUsed: result.metadata.totalTokens,
      confidence: result.metadata.confidenceScore
    };
  }

  /**
   * 执行oh-my-codex工作流
   */
  private async executeOhMyCodex(
    request: UnifiedWorkflowRequest,
    activeWorkflow: ActiveWorkflow
  ): Promise<{ type: WorkflowType; content: string; rawResult: any; tokensUsed: number; confidence: number }> {
    const mode = request.config?.ohMyCodex?.mode || 'auto';
    
    this.addStep(activeWorkflow, 'oh-my-codex-execution', 'oh-my-codex', { mode });

    const result = await this.ohMyCodex.execute({
      prompt: request.prompt,
      mode,
      context: request.context
    });

    this.completeStep(activeWorkflow, 'oh-my-codex-execution');

    const content = 'finalOutput' in result ? result.finalOutput :
                   'primaryOutput' in result ? result.primaryOutput :
                   'architecture' in result ? result.architecture : '';

    const confidence = 'consensusScore' in result ? result.consensusScore / 100 :
                      'convergenceScore' in result ? result.convergenceScore / 100 :
                      'validationReport' in result ? result.validationReport.overallScore / 100 : 0.8;

    return {
      type: 'oh-my-codex',
      content,
      rawResult: result,
      tokensUsed: 0,
      confidence
    };
  }

  /**
   * 执行free-code工作流
   */
  private async executeFreeCode(
    request: UnifiedWorkflowRequest,
    activeWorkflow: ActiveWorkflow
  ): Promise<{ type: WorkflowType; content: string; rawResult: any; tokensUsed: number; confidence: number }> {
    const task = request.config?.freeCode?.task || 'generate';
    
    this.addStep(activeWorkflow, 'free-code-execution', 'free-code', { task });

    const fcRequest: FreeCodeRequest = {
      task,
      project: request.config?.freeCode?.project || {
        name: 'default',
        path: '.',
        language: 'typescript'
      },
      requirements: request.prompt,
      context: request.context,
      use4AI: true
    };

    const result = await this.freeCode.execute(fcRequest);

    this.completeStep(activeWorkflow, 'free-code-execution');

    const content = result.documentation || 
                   result.files.map(f => `File: ${f.path}\n${f.content}`).join('\n\n') ||
                   result.review?.overallScore.toString() || '';

    return {
      type: 'free-code',
      content,
      rawResult: result,
      tokensUsed: result.metadata.tokensUsed,
      confidence: result.metadata.confidence
    };
  }

  /**
   * 解析工作流类型
   */
  private resolveWorkflowType(request: UnifiedWorkflowRequest): WorkflowType {
    // 1. 用户显式指定
    if (request.type && request.type !== 'auto') {
      return request.type;
    }

    // 2. 基于提示词内容自动检测
    const prompt = request.prompt.toLowerCase();

    // free-code关键词
    if (
      prompt.includes('$free-code') ||
      prompt.includes('生成代码') ||
      prompt.includes('code generation') ||
      prompt.includes('写代码') ||
      prompt.includes('实现功能') ||
      prompt.includes('create file') ||
      prompt.includes('generate code') ||
      (prompt.includes('项目') && prompt.includes('代码'))
    ) {
      return 'free-code';
    }

    // oh-my-codex关键词
    if (
      prompt.includes('$team') ||
      prompt.includes('$ri') ||
      prompt.includes('$ralph') ||
      prompt.includes('team review') ||
      prompt.includes('迭代优化') ||
      prompt.includes('架构设计')
    ) {
      return 'oh-my-codex';
    }

    // 3. 基于配置推断
    if (request.config?.freeCode) {
      return 'free-code';
    }
    if (request.config?.ohMyCodex) {
      return 'oh-my-codex';
    }

    // 4. 默认使用4AI
    return '4ai';
  }

  /**
   * 添加步骤
   */
  private addStep(
    workflow: ActiveWorkflow,
    name: string,
    type: string,
    data?: Record<string, any>
  ): void {
    workflow.steps.push({
      name,
      type,
      startTime: Date.now(),
      status: 'running',
      output: data ? JSON.stringify(data) : undefined
    });
  }

  /**
   * 完成步骤
   */
  private completeStep(
    workflow: ActiveWorkflow,
    name: string,
    data?: { output?: string }
  ): void {
    const step = workflow.steps.find(s => s.name === name && s.status === 'running');
    if (step) {
      step.status = 'completed';
      step.endTime = Date.now();
      if (data?.output) {
        step.output = data.output;
      }
    }
  }

  /**
   * 按优先级插入队列
   */
  private insertByPriority(item: WorkflowQueueItem): void {
    const index = this.queue.findIndex(i => i.priority < item.priority);
    if (index === -1) {
      this.queue.push(item);
    } else {
      this.queue.splice(index, 0, item);
    }
  }

  /**
   * 生成工作流ID
   */
  private generateWorkflowId(): string {
    return `uwf-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 设置事件处理器
   */
  private setupEventHandlers(): void {
    this.on('workflow-queued', (event) => {
      console.log(`[UnifiedWorkflow] Queued: ${event.workflowId}`);
    });

    this.on('workflow-start', (event) => {
      console.log(`[UnifiedWorkflow] Started: ${event.workflowId}`);
    });

    this.on('workflow-complete', (event) => {
      console.log(`[UnifiedWorkflow] Completed: ${event.workflowId}`);
    });

    this.on('workflow-error', (event) => {
      console.error(`[UnifiedWorkflow] Error: ${event.workflowId}`, event.error);
    });
  }

  /**
   * 清空队列
   */
  clearQueue(): number {
    const count = this.queue.length;
    for (const item of this.queue) {
      item.reject(new Error('Queue cleared'));
    }
    this.queue = [];
    return count;
  }

  /**
   * 关闭引擎
   */
  shutdown(): void {
    // 取消所有活跃工作流
    for (const [id, workflow] of this.activeWorkflows) {
      workflow.abortController.abort();
      this.emit('workflow-cancelled', { workflowId: id });
    }
    this.activeWorkflows.clear();

    // 清空队列
    this.clearQueue();

    // 关闭适配器
    this.fourAI.shutdown();
    this.ohMyCodex.shutdown();
    this.freeCode.shutdown();

    this.removeAllListeners();
  }
}

/**
 * 信号量
 */
class Semaphore {
  private permits: number;
  private waiters: (() => void)[] = [];

  constructor(permits: number) {
    this.permits = permits;
  }

  async acquire(): Promise<void> {
    if (this.permits > 0) {
      this.permits--;
      return;
    }

    return new Promise(resolve => {
      this.waiters.push(resolve);
    });
  }

  release(): void {
    if (this.waiters.length > 0) {
      const waiter = this.waiters.shift()!;
      waiter();
    } else {
      this.permits++;
    }
  }
}

export default UnifiedWorkflowEngine;
