/**
 * OpenClaw智能路由系统 V2.0 - 适配器模块
 * @module adapter
 * @version 2.0.0
 * @description 统一工作流适配器，集成4AI/oh-my-codex/free-code
 */

// 4AI工作流适配器
export {
  FourAIWorkflowAdapter,
  FourAIRole,
  RoleOutput,
  ParallelExecutionResult,
  ArbiterDecision,
  WorkflowExecutionConfig
} from './4AIWorkflowAdapter';

// oh-my-codex适配器
export {
  OhMyCodexAdapter,
  OhMyCodexMode,
  OhMyCodexConfig,
  TeamModeResult,
  RiModeResult,
  RalphModeResult,
  PeerReview,
  RiIteration,
  ValidationReport,
  RiskAssessment,
  OhMyCodexRequest
} from './OhMyCodexAdapter';

// free-code适配器
export {
  FreeCodeAdapter,
  FreeCodeRequest,
  FreeCodeResult,
  FreeCodeProjectConfig,
  FreeCodeTaskType,
  FileOperation,
  TestResult,
  CodeReviewResult,
  CodeIssue,
  SecurityCheck,
  MCPTool
} from './FreeCodeAdapter';

// 统一工作流引擎
export {
  UnifiedWorkflowEngine,
  WorkflowType,
  WorkflowStatus,
  UnifiedWorkflowRequest,
  WorkflowConfig,
  UnifiedWorkflowResult,
  WorkflowMetadata,
  WorkflowStep,
  WorkflowStats
} from './UnifiedWorkflowEngine';

// 模块信息
export const ADAPTER_VERSION = '2.0.0';
export const ADAPTER_NAME = 'OpenClaw Router V2.0 - Adapter Module';

// 支持的适配器列表
export const SUPPORTED_ADAPTERS = [
  {
    name: '4AIWorkflowAdapter',
    description: '4AI原生工作流适配器',
    version: '2.0.0',
    roles: ['clarifier', 'builder', 'reviewer', 'arbiter']
  },
  {
    name: 'OhMyCodexAdapter',
    description: 'oh-my-codex工作流适配器',
    version: '2.0.0',
    modes: ['team', 'ri', 'ralph', 'auto']
  },
  {
    name: 'FreeCodeAdapter',
    description: 'free-code项目适配器',
    version: '2.0.0',
    tasks: ['generate', 'modify', 'review', 'test', 'debug', 'refactor', 'document']
  },
  {
    name: 'UnifiedWorkflowEngine',
    description: '统一工作流引擎',
    version: '2.0.0',
    features: ['queue', 'priority', 'batch', 'auto-selection']
  }
] as const;
