/**
 * oh-my-codex适配器测试
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { OhMyCodexAdapter, OhMyCodexMode } from '../../adapter/OhMyCodexAdapter';

describe('OhMyCodexAdapter', () => {
  let adapter: OhMyCodexAdapter;

  beforeEach(() => {
    adapter = new OhMyCodexAdapter({
      mode: 'auto',
      teamSize: 3,
      maxIterations: 5,
      confidenceThreshold: 0.85
    });
  });

  afterEach(() => {
    adapter.shutdown();
  });

  describe('初始化', () => {
    it('应该正确初始化', () => {
      expect(adapter).toBeDefined();
    });

    it('应该应用配置', () => {
      const history = adapter.getExecutionHistory();
      expect(Array.isArray(history)).toBe(true);
    });
  });

  describe('模式检测', () => {
    it('应该检测team模式', () => {
      const result = adapter.getExecutionHistory();
      expect(Array.isArray(result)).toBe(true);
    });

    it('应该支持所有模式', () => {
      const modes: OhMyCodexMode[] = ['team', 'ri', 'ralph', 'auto'];
      expect(modes).toHaveLength(4);
    });
  });

  describe('执行历史', () => {
    it('应该返回执行历史数组', () => {
      const history = adapter.getExecutionHistory();
      expect(Array.isArray(history)).toBe(true);
    });

    it('应该支持按ID查询', () => {
      const result = adapter.getExecutionHistory('non-existent');
      expect(result).toBeUndefined();
    });
  });

  describe('事件系统', () => {
    it('应该触发执行开始事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('execution-start', (event) => {
          expect(event).toHaveProperty('executionId');
          expect(event).toHaveProperty('mode');
          resolve();
        });

        adapter.emit('execution-start', { 
          executionId: 'test', 
          mode: 'team',
          prompt: 'test'
        });
      });
    });

    it('应该触发team模式开始事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('team-mode-start', (event) => {
          expect(event).toHaveProperty('executionId');
          expect(event).toHaveProperty('teamSize');
          resolve();
        });

        adapter.emit('team-mode-start', { 
          executionId: 'test', 
          teamSize: 3
        });
      });
    });

    it('应该触发ri模式开始事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('ri-mode-start', (event) => {
          expect(event).toHaveProperty('executionId');
          expect(event).toHaveProperty('maxIterations');
          resolve();
        });

        adapter.emit('ri-mode-start', { 
          executionId: 'test', 
          maxIterations: 5
        });
      });
    });

    it('应该触发ralph模式开始事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('ralph-mode-start', (event) => {
          expect(event).toHaveProperty('executionId');
          resolve();
        });

        adapter.emit('ralph-mode-start', { executionId: 'test' });
      });
    });
  });
});
