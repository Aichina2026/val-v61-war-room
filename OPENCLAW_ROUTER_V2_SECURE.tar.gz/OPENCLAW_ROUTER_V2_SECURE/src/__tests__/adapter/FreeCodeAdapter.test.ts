/**
 * free-code适配器测试
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { FreeCodeAdapter, FreeCodeTaskType } from '../../adapter/FreeCodeAdapter';

describe('FreeCodeAdapter', () => {
  let adapter: FreeCodeAdapter;

  beforeEach(() => {
    adapter = new FreeCodeAdapter();
  });

  afterEach(() => {
    adapter.shutdown();
  });

  describe('初始化', () => {
    it('应该正确初始化', () => {
      expect(adapter).toBeDefined();
    });

    it('应该注册MCP工具', () => {
      const tools = adapter.listMCPTools();
      expect(tools.length).toBeGreaterThan(0);
    });
  });

  describe('MCP工具', () => {
    it('应该包含read_file工具', () => {
      const tool = adapter.getMCPTool('read_file');
      expect(tool).toBeDefined();
      expect(tool?.name).toBe('read_file');
    });

    it('应该包含write_file工具', () => {
      const tool = adapter.getMCPTool('write_file');
      expect(tool).toBeDefined();
      expect(tool?.name).toBe('write_file');
    });

    it('应该包含list_directory工具', () => {
      const tool = adapter.getMCPTool('list_directory');
      expect(tool).toBeDefined();
    });

    it('应该包含execute_command工具', () => {
      const tool = adapter.getMCPTool('execute_command');
      expect(tool).toBeDefined();
    });

    it('应该包含search_code工具', () => {
      const tool = adapter.getMCPTool('search_code');
      expect(tool).toBeDefined();
    });
  });

  describe('任务类型', () => {
    it('应该支持所有任务类型', () => {
      const tasks: FreeCodeTaskType[] = [
        'generate', 'modify', 'review', 'test', 'debug', 'refactor', 'document'
      ];
      expect(tasks).toHaveLength(7);
    });
  });

  describe('事件系统', () => {
    it('应该触发任务开始事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('task-start', (event) => {
          expect(event).toHaveProperty('taskId');
          expect(event).toHaveProperty('task');
          resolve();
        });

        adapter.emit('task-start', { 
          taskId: 'test', 
          task: 'generate',
          project: 'test-project'
        });
      });
    });

    it('应该触发任务完成事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('task-complete', (event) => {
          expect(event).toHaveProperty('taskId');
          expect(event).toHaveProperty('duration');
          resolve();
        });

        adapter.emit('task-complete', { 
          taskId: 'test', 
          duration: 1000
        });
      });
    });
  });
});
