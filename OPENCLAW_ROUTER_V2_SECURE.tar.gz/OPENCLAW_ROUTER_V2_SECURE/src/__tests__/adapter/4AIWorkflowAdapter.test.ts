/**
 * 4AI工作流适配器测试
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { FourAIWorkflowAdapter, FourAIRole } from '../../adapter/4AIWorkflowAdapter';

describe('FourAIWorkflowAdapter', () => {
  let adapter: FourAIWorkflowAdapter;

  beforeEach(() => {
    adapter = new FourAIWorkflowAdapter({
      mode: 'parallel',
      timeout: 60000,
      enableArbiter: true
    });
  });

  afterEach(() => {
    adapter.shutdown();
  });

  describe('初始化', () => {
    it('应该正确初始化', () => {
      expect(adapter).toBeDefined();
      expect(adapter.getConfig()).toBeDefined();
    });

    it('应该应用配置', () => {
      const config = adapter.getConfig();
      expect(config.mode).toBe('parallel');
      expect(config.timeout).toBe(60000);
      expect(config.enableArbiter).toBe(true);
    });
  });

  describe('配置管理', () => {
    it('应该支持更新配置', () => {
      adapter.updateConfig({ mode: 'sequential' });
      expect(adapter.getConfig().mode).toBe('sequential');
    });

    it('应该保留未修改的配置', () => {
      adapter.updateConfig({ mode: 'hybrid' });
      expect(adapter.getConfig().timeout).toBe(60000);
      expect(adapter.getConfig().enableArbiter).toBe(true);
    });
  });

  describe('事件系统', () => {
    it('应该触发工作流开始事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('workflow-start', (event) => {
          expect(event).toHaveProperty('workflowId');
          expect(event).toHaveProperty('timestamp');
          resolve();
        });

        // 触发测试事件
        adapter.emit('workflow-start', { workflowId: 'test', timestamp: Date.now() });
      });
    });

    it('应该触发工作流完成事件', () => {
      return new Promise<void>((resolve) => {
        adapter.on('workflow-complete', (event) => {
          expect(event).toHaveProperty('workflowId');
          expect(event).toHaveProperty('result');
          resolve();
        });

        adapter.emit('workflow-complete', { 
          workflowId: 'test', 
          result: { finalOutput: 'test' },
          timestamp: Date.now() 
        });
      });
    });
  });

  describe('角色配置', () => {
    it('应该定义4个角色', () => {
      const roles: FourAIRole[] = ['clarifier', 'builder', 'reviewer', 'arbiter'];
      expect(roles).toHaveLength(4);
    });
  });

  describe('结果聚合策略', () => {
    it('应该支持best聚合策略', () => {
      adapter.updateConfig({ aggregationStrategy: 'best' });
      expect(adapter.getConfig().aggregationStrategy).toBe('best');
    });

    it('应该支持merge聚合策略', () => {
      adapter.updateConfig({ aggregationStrategy: 'merge' });
      expect(adapter.getConfig().aggregationStrategy).toBe('merge');
    });

    it('应该支持voting聚合策略', () => {
      adapter.updateConfig({ aggregationStrategy: 'voting' });
      expect(adapter.getConfig().aggregationStrategy).toBe('voting');
    });

    it('应该支持hierarchical聚合策略', () => {
      adapter.updateConfig({ aggregationStrategy: 'hierarchical' });
      expect(adapter.getConfig().aggregationStrategy).toBe('hierarchical');
    });
  });
});
