/**
 * 统一工作流引擎测试
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { UnifiedWorkflowEngine, WorkflowType } from '../../adapter/UnifiedWorkflowEngine';

describe('UnifiedWorkflowEngine', () => {
  let engine: UnifiedWorkflowEngine;

  beforeEach(() => {
    engine = new UnifiedWorkflowEngine({
      maxConcurrent: 3,
      defaultTimeout: 60000
    });
  });

  afterEach(() => {
    engine.shutdown();
  });

  describe('初始化', () => {
    it('应该正确初始化', () => {
      expect(engine).toBeDefined();
    });

    it('应该应用配置', () => {
      const stats = engine.getStats();
      expect(stats).toBeDefined();
    });
  });

  describe('工作流类型', () => {
    it('应该支持所有工作流类型', () => {
      const types: WorkflowType[] = ['4ai', 'oh-my-codex', 'free-code', 'auto'];
      expect(types).toHaveLength(4);
    });
  });

  describe('统计信息', () => {
    it('应该返回初始统计', () => {
      const stats = engine.getStats();
      expect(stats.total).toBe(0);
      expect(stats.pending).toBe(0);
      expect(stats.running).toBe(0);
      expect(stats.completed).toBe(0);
    });

    it('应该包含所有统计字段', () => {
      const stats = engine.getStats();
      expect(stats).toHaveProperty('total');
      expect(stats).toHaveProperty('pending');
      expect(stats).toHaveProperty('running');
      expect(stats).toHaveProperty('completed');
      expect(stats).toHaveProperty('failed');
      expect(stats).toHaveProperty('avgDuration');
      expect(stats).toHaveProperty('avgConfidence');
    });
  });

  describe('工作流状态', () => {
    it('应该返回null对于不存在的工作流', () => {
      const status = engine.getWorkflowStatus('non-existent');
      expect(status).toBeNull();
    });

    it('应该返回null对于不存在的结果', () => {
      const result = engine.getWorkflowResult('non-existent');
      expect(result).toBeNull();
    });
  });

  describe('队列管理', () => {
    it('应该清空队列', () => {
      const cleared = engine.clearQueue();
      expect(typeof cleared).toBe('number');
    });
  });

  describe('事件系统', () => {
    it('应该触发工作流入队事件', () => {
      return new Promise<void>((resolve) => {
        engine.on('workflow-queued', (event) => {
          expect(event).toHaveProperty('workflowId');
          expect(event).toHaveProperty('request');
          resolve();
        });

        engine.emit('workflow-queued', { 
          workflowId: 'test', 
          request: { prompt: 'test' }
        });
      });
    });

    it('应该触发工作流开始事件', () => {
      return new Promise<void>((resolve) => {
        engine.on('workflow-start', (event) => {
          expect(event).toHaveProperty('workflowId');
          resolve();
        });

        engine.emit('workflow-start', { workflowId: 'test' });
      });
    });

    it('应该触发工作流完成事件', () => {
      return new Promise<void>((resolve) => {
        engine.on('workflow-complete', (event) => {
          expect(event).toHaveProperty('workflowId');
          expect(event).toHaveProperty('result');
          resolve();
        });

        engine.emit('workflow-complete', { 
          workflowId: 'test', 
          result: { content: 'test' }
        });
      });
    });

    it('应该触发工作流取消事件', () => {
      return new Promise<void>((resolve) => {
        engine.on('workflow-cancelled', (event) => {
          expect(event).toHaveProperty('workflowId');
          resolve();
        });

        engine.emit('workflow-cancelled', { workflowId: 'test' });
      });
    });
  });

  describe('批量执行', () => {
    it('应该支持批量执行配置', () => {
      const requests = [
        { prompt: 'test1' },
        { prompt: 'test2' }
      ];
      
      // 验证配置结构
      expect(requests).toHaveLength(2);
    });
  });
});
