/**
 * TieredVectorCache 单元测试
 * @version 2.0.0
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { TieredVectorCache, VectorResult } from '../../infrastructure/VectorCache';

// Mock Redis
const mockRedis = {
  get: vi.fn(),
  setex: vi.fn().mockResolvedValue('OK'),
  del: vi.fn().mockResolvedValue(1),
  keys: vi.fn().mockResolvedValue([]),
  ping: vi.fn().mockResolvedValue('PONG')
};

// Mock Qdrant
const mockQdrant = {
  search: vi.fn()
};

describe('TieredVectorCache', () => {
  let cache: TieredVectorCache;

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('L1 Cache (Local)', () => {
    beforeEach(() => {
      cache = new TieredVectorCache({
        l1TTLMs: 5000,
        l1MaxSize: 100
      });
    });

    it('should return empty array for cache miss', async () => {
      const vector = [0.1, 0.2, 0.3];
      const results = await cache.search(vector);

      expect(results).toEqual([]);
    });

    it('should cache and return results from L1', async () => {
      const vector = [0.1, 0.2, 0.3];
      const expectedResults: VectorResult[] = [
        { id: '1', score: 0.95, metadata: { text: 'test' } }
      ];

      // Manually set cache
      await cache.set(vector, expectedResults);

      const results = await cache.search(vector);

      expect(results).toEqual(expectedResults);
    });

    it('should handle L1 cache expiration', async () => {
      const shortCache = new TieredVectorCache({
        l1TTLMs: 10, // 10ms TTL
        l1MaxSize: 100
      });

      const vector = [0.1, 0.2, 0.3];
      const expectedResults: VectorResult[] = [
        { id: '1', score: 0.95 }
      ];

      await shortCache.set(vector, expectedResults);

      // Wait for expiration
      await new Promise(resolve => setTimeout(resolve, 50));

      const results = await shortCache.search(vector);

      expect(results).toEqual([]); // Cache expired
    });
  });

  describe('L2 Cache (Redis)', () => {
    beforeEach(() => {
      cache = new TieredVectorCache({
        redis: mockRedis as any,
        l1TTLMs: 5000,
        l2TTLSeconds: 3600
      });
    });

    it('should fall back to L2 when L1 misses', async () => {
      const vector = [0.1, 0.2, 0.3];
      const l2Results: VectorResult[] = [
        { id: '2', score: 0.90, metadata: { source: 'l2' } }
      ];

      mockRedis.get.mockResolvedValue(JSON.stringify(l2Results));

      const results = await cache.search(vector);

      expect(mockRedis.get).toHaveBeenCalled();
      expect(results).toEqual(l2Results);
    });

    it('should backfill L1 from L2 on hit', async () => {
      const vector = [0.1, 0.2, 0.3];
      const l2Results: VectorResult[] = [
        { id: '2', score: 0.90 }
      ];

      mockRedis.get.mockResolvedValue(JSON.stringify(l2Results));

      // First call - L1 miss, L2 hit
      await cache.search(vector);
      // Second call - should hit L1
      const results = await cache.search(vector);

      expect(results).toEqual(l2Results);
      // L2 should only be called once
      expect(mockRedis.get).toHaveBeenCalledTimes(1);
    });

    it('should handle Redis errors gracefully', async () => {
      const vector = [0.1, 0.2, 0.3];

      mockRedis.get.mockRejectedValue(new Error('Redis connection failed'));

      // Should not throw, return empty array
      const results = await cache.search(vector);

      expect(results).toEqual([]);
    });
  });

  describe('L3 Cache (Qdrant)', () => {
    beforeEach(() => {
      cache = new TieredVectorCache({
        redis: mockRedis as any,
        qdrantClient: mockQdrant as any,
        l1TTLMs: 5000
      });
    });

    it('should query L3 when L1 and L2 miss', async () => {
      const vector = [0.1, 0.2, 0.3];
      const qdrantResults = [
        { id: '3', score: 0.85, payload: { text: 'l3 result' } }
      ];

      mockRedis.get.mockResolvedValue(null);
      mockQdrant.search.mockResolvedValue(qdrantResults);

      const results = await cache.search(vector, 5);

      expect(mockQdrant.search).toHaveBeenCalledWith('openclaw_collection', {
        vector: vector,
        limit: 5,
        with_vector: false,
        with_payload: true
      });

      expect(results.length).toBe(1);
      expect(results[0].id).toBe('3');
    });

    it('should handle Qdrant 404 gracefully', async () => {
      const vector = [0.1, 0.2, 0.3];

      mockRedis.get.mockResolvedValue(null);
      mockQdrant.search.mockRejectedValue({ status: 404, message: 'Not found' });

      const results = await cache.search(vector);

      expect(results).toEqual([]);
    });

    it('should throw on L3 errors other than 404', async () => {
      const vector = [0.1, 0.2, 0.3];

      mockRedis.get.mockResolvedValue(null);
      mockQdrant.search.mockRejectedValue(new Error('Connection timeout'));

      await expect(cache.search(vector)).rejects.toThrow('L3 Query Failed');
    });

    it('should backfill L1 and L2 from L3', async () => {
      const vector = [0.1, 0.2, 0.3];
      const qdrantResults = [
        { id: '3', score: 0.85, payload: {} }
      ];

      mockRedis.get.mockResolvedValue(null);
      mockQdrant.search.mockResolvedValue(qdrantResults);

      await cache.search(vector);

      // Verify L2 backfill
      expect(mockRedis.setex).toHaveBeenCalled();
    });
  });

  describe('Batch Operations', () => {
    beforeEach(() => {
      cache = new TieredVectorCache({
        l1TTLMs: 5000
      });
    });

    it('should handle batch search', async () => {
      const vectors = [
        [0.1, 0.2, 0.3],
        [0.4, 0.5, 0.6]
      ];

      const results = await cache.batchSearch(vectors);

      expect(results.length).toBe(2);
      expect(results[0]).toEqual([]);
      expect(results[1]).toEqual([]);
    });
  });

  describe('Cache Invalidation', () => {
    beforeEach(() => {
      cache = new TieredVectorCache({
        redis: mockRedis as any,
        l1TTLMs: 5000
      });
    });

    it('should invalidate specific vector', async () => {
      const vector = [0.1, 0.2, 0.3];
      const results: VectorResult[] = [{ id: '1', score: 0.9 }];

      await cache.set(vector, results);
      expect(await cache.search(vector)).toEqual(results);

      await cache.invalidate(vector);
      expect(await cache.search(vector)).toEqual([]);
    });

    it('should invalidate all cache', async () => {
      const vector1 = [0.1, 0.2, 0.3];
      const vector2 = [0.4, 0.5, 0.6];

      await cache.set(vector1, [{ id: '1', score: 0.9 }]);
      await cache.set(vector2, [{ id: '2', score: 0.8 }]);

      mockRedis.keys.mockResolvedValue(['vec:0.10|0.20|0.30', 'vec:0.40|0.50|0.60']);

      await cache.invalidate();

      expect(await cache.search(vector1)).toEqual([]);
      expect(await cache.search(vector2)).toEqual([]);
    });
  });

  describe('Statistics', () => {
    beforeEach(() => {
      cache = new TieredVectorCache({
        redis: mockRedis as any,
        qdrantClient: mockQdrant as any,
        l1TTLMs: 5000
      });
    });

    it('should track L1 hits', async () => {
      const vector = [0.1, 0.2, 0.3];
      await cache.set(vector, [{ id: '1', score: 0.9 }]);
      await cache.search(vector);

      const stats = cache.getStats();
      expect(stats.L1).toBe(1);
      expect(stats.total).toBe(1);
    });

    it('should track L2 hits', async () => {
      mockRedis.get.mockResolvedValue(JSON.stringify([{ id: '1', score: 0.9 }]));

      const vector = [0.1, 0.2, 0.3];
      await cache.search(vector);

      const stats = cache.getStats();
      expect(stats.L2).toBe(1);
    });

    it('should track L3 hits', async () => {
      mockRedis.get.mockResolvedValue(null);
      mockQdrant.search.mockResolvedValue([{ id: '1', score: 0.9, payload: {} }]);

      const vector = [0.1, 0.2, 0.3];
      await cache.search(vector);

      const stats = cache.getStats();
      expect(stats.L3).toBe(1);
    });

    it('should calculate hit rate', async () => {
      const vector = [0.1, 0.2, 0.3];
      await cache.set(vector, [{ id: '1', score: 0.9 }]);
      await cache.search(vector);
      await cache.search(vector);

      const stats = cache.getStats();
      expect(stats.hitRate).toBe(100);
    });

    it('should reset statistics', async () => {
      const vector = [0.1, 0.2, 0.3];
      await cache.set(vector, [{ id: '1', score: 0.9 }]);
      await cache.search(vector);

      cache.resetStats();
      const stats = cache.getStats();

      expect(stats.L1).toBe(0);
      expect(stats.L2).toBe(0);
      expect(stats.L3).toBe(0);
      expect(stats.total).toBe(0);
    });
  });

  describe('Health Check', () => {
    it('should return health status', async () => {
      mockRedis.ping.mockResolvedValue('PONG');
      mockQdrant.search.mockResolvedValue([]);

      cache = new TieredVectorCache({
        redis: mockRedis as any,
        qdrantClient: mockQdrant as any
      });

      const health = await cache.healthCheck();

      expect(health.L1).toBe(true);
      expect(health.L2).toBe(true);
      expect(health.L3).toBe(true);
    });

    it('should detect unhealthy Redis', async () => {
      mockRedis.ping.mockRejectedValue(new Error('Connection failed'));

      cache = new TieredVectorCache({
        redis: mockRedis as any
      });

      const health = await cache.healthCheck();

      expect(health.L2).toBe(false);
    });
  });
});
