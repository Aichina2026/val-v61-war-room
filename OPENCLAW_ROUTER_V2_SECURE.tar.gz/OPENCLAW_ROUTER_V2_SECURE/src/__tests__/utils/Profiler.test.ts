/**
 * Profiler 性能分析器单元测试
 * @version 2.0.0
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { LayerProfiler } from '../../utils/Profiler';

describe('LayerProfiler', () => {
  let profiler: LayerProfiler;

  beforeEach(() => {
    profiler = new LayerProfiler(1000, 100);
  });

  describe('Basic Recording', () => {
    it('should record latency data', () => {
      profiler.record('layer1', 10);
      profiler.record('layer1', 20);
      profiler.record('layer1', 30);
      
      const metrics = profiler.getMetrics('layer1');
      expect(metrics).not.toBeNull();
      expect(metrics!.sampleCount).toBe(3);
    });

    it('should return null for non-existent layer', () => {
      const metrics = profiler.getMetrics('non-existent');
      expect(metrics).toBeNull();
    });

    it('should calculate correct percentiles', () => {
      // Add 100 samples from 1 to 100
      for (let i = 1; i <= 100; i++) {
        profiler.record('layer1', i);
      }
      
      const metrics = profiler.getMetrics('layer1')!;
      expect(metrics.p50).toBe(50);
      expect(metrics.p90).toBe(90);
      expect(metrics.p99).toBe(99);
    });
  });

  describe('Timer Functionality', () => {
    it('should measure time correctly', async () => {
      const endTimer = profiler.startTimer();
      await new Promise(resolve => setTimeout(resolve, 50));
      const elapsed = endTimer();
      
      expect(elapsed).toBeGreaterThanOrEqual(45);
      expect(elapsed).toBeLessThan(100);
    });

    it('should record timer results', async () => {
      const endTimer = profiler.startTimer();
      await new Promise(resolve => setTimeout(resolve, 10));
      const elapsed = endTimer();
      
      profiler.record('timed-layer', elapsed);
      
      const metrics = profiler.getMetrics('timed-layer');
      expect(metrics).not.toBeNull();
      expect(metrics!.avg).toBeGreaterThan(0);
    });
  });

  describe('Flame Graph Data', () => {
    it('should generate flame graph data', () => {
      profiler.record('layer1', 100);
      profiler.record('layer1', 200);
      profiler.record('layer2', 50);
      
      const flameData = profiler.generateFlameGraphData();
      
      expect(flameData.name).toBe('root');
      expect(flameData.children.length).toBe(2);
      expect(flameData.value).toBe(350);
    });

    it('should include call counts in flame graph', () => {
      profiler.record('layer1', 100);
      profiler.record('layer1', 200);
      
      const flameData = profiler.generateFlameGraphData();
      const layer1Node = flameData.children.find(c => c.name === 'layer1');
      
      expect(layer1Node).toBeDefined();
      expect(layer1Node!.calls).toBe(2);
    });
  });

  describe('Histogram', () => {
    it('should generate latency histogram', () => {
      // Add samples: 10, 20, 30, ..., 100
      for (let i = 1; i <= 10; i++) {
        profiler.record('layer1', i * 10);
      }
      
      const histogram = profiler.getLatencyHistogram('layer1', 5);
      
      expect(histogram).not.toBeNull();
      expect(histogram!.ranges.length).toBe(5);
      expect(histogram!.counts.length).toBe(5);
      expect(histogram!.counts.reduce((a, b) => a + b, 0)).toBe(10);
    });

    it('should return null for empty layer', () => {
      const histogram = profiler.getLatencyHistogram('empty', 5);
      expect(histogram).toBeNull();
    });
  });

  describe('Report Generation', () => {
    it('should export performance report', () => {
      profiler.record('layer1', 50);
      profiler.record('layer1', 100);
      profiler.record('layer2', 75);
      
      const report = profiler.exportReport();
      
      expect(report).toContain('Performance Report');
      expect(report).toContain('layer1');
      expect(report).toContain('layer2');
      expect(report).toContain('P50');
      expect(report).toContain('P99');
    });
  });

  describe('Memory Management', () => {
    it('should limit samples to maxSamples', () => {
      const smallProfiler = new LayerProfiler(100, 10);
      
      // Add more samples than max
      for (let i = 0; i < 150; i++) {
        smallProfiler.record('layer1', i);
      }
      
      const metrics = smallProfiler.getMetrics('layer1')!;
      expect(metrics.sampleCount).toBeLessThanOrEqual(100);
    });
  });

  describe('Clear Operations', () => {
    it('should clear specific layer', () => {
      profiler.record('layer1', 50);
      profiler.record('layer2', 100);
      
      profiler.clear('layer1');
      
      expect(profiler.getMetrics('layer1')).toBeNull();
      expect(profiler.getMetrics('layer2')).not.toBeNull();
    });

    it('should clear all layers', () => {
      profiler.record('layer1', 50);
      profiler.record('layer2', 100);
      
      profiler.clear();
      
      expect(profiler.getMetrics('layer1')).toBeNull();
      expect(profiler.getMetrics('layer2')).toBeNull();
    });
  });

  describe('All Metrics', () => {
    it('should return metrics for all layers', () => {
      profiler.record('layer1', 50);
      profiler.record('layer2', 100);
      profiler.record('layer3', 75);
      
      const allMetrics = profiler.getAllMetrics();
      
      expect(allMetrics.length).toBe(3);
      expect(allMetrics.map(m => m.layer).sort()).toEqual(['layer1', 'layer2', 'layer3']);
    });
  });
});
