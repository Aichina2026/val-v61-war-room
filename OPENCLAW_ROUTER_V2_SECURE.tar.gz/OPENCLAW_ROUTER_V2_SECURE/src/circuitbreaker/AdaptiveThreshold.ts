/**
 * Adaptive Threshold - Dynamic threshold adjustment for Circuit Breaker V29
 * 
 * Implements multi-dimensional adaptive threshold algorithm:
 * - Time-based adjustments (peak hours)
 * - Load-based adjustments (system pressure)
 * - History-based adjustments (past performance)
 * - Cost-based adjustments (cost sensitivity)
 * 
 * @version 29.0.0
 * @since 2026-04-12
 */

import {
  ThresholdContext,
  CircuitBreakerConfig
} from './types';

/**
 * Adaptive threshold configuration
 */
export interface AdaptiveThresholdConfig {
  /** Base threshold value (0-1) */
  baseThreshold: number;
  
  /** Smoothing factor for threshold updates (0-1) */
  smoothingFactor: number;
  
  /** Peak hours (0-23) */
  peakHours: number[];
  
  /** Load factor weight */
  loadWeight: number;
  
  /** Time factor weight */
  timeWeight: number;
  
  /** History factor weight */
  historyWeight: number;
  
  /** Cost factor weight */
  costWeight: number;
  
  /** Maximum adjustment magnitude */
  maxAdjustment: number;
  
  /** Minimum allowed threshold */
  minThreshold: number;
  
  /** Maximum allowed threshold */
  maxThreshold: number;
}

/**
 * Default adaptive threshold configuration
 */
export const DEFAULT_ADAPTIVE_CONFIG: AdaptiveThresholdConfig = {
  baseThreshold: 0.92,
  smoothingFactor: 0.1,
  peakHours: [9, 10, 11, 14, 15, 16, 20, 21], // Business peak hours
  loadWeight: 0.3,
  timeWeight: 0.2,
  historyWeight: 0.3,
  costWeight: 0.2,
  maxAdjustment: 0.08,
  minThreshold: 0.85,
  maxThreshold: 0.98
};

/**
 * Threshold adjustment factors
 */
interface AdjustmentFactors {
  time: number;
  load: number;
  history: number;
  cost: number;
}

/**
 * Adaptive threshold calculator
 */
export class AdaptiveThreshold {
  private config: AdaptiveThresholdConfig;
  private currentThreshold: number;
  private adjustmentHistory: Array<{ timestamp: number; adjustment: number }> = [];
  
  constructor(config: Partial<AdaptiveThresholdConfig> = {}) {
    this.config = { ...DEFAULT_ADAPTIVE_CONFIG, ...config };
    this.currentThreshold = this.config.baseThreshold;
  }
  
  /**
   * Get current adaptive threshold
   * @returns Current threshold value (0-1)
   */
  get(): number {
    return this.currentThreshold;
  }
  
  /**
   * Get base threshold
   * @returns Base threshold value
   */
  getBaseThreshold(): number {
    return this.config.baseThreshold;
  }
  
  /**
   * Adjust threshold based on context
   * @param context - Threshold context with system metrics
   * @returns Adjusted threshold value
   */
  adjustThreshold(context: ThresholdContext): number {
    const factors = this.calculateFactors(context);
    const adjustment = this.calculateAdjustment(factors, context);
    
    // Apply smoothing to avoid threshold jitter
    const newThreshold = this.smoothUpdate(this.currentThreshold, this.config.baseThreshold + adjustment);
    
    // Clamp to valid range
    const clampedThreshold = Math.max(
      this.config.minThreshold,
      Math.min(this.config.maxThreshold, newThreshold)
    );
    
    // Record adjustment if significant
    if (Math.abs(clampedThreshold - this.currentThreshold) > 0.001) {
      this.adjustmentHistory.push({
        timestamp: Date.now(),
        adjustment: clampedThreshold - this.currentThreshold
      });
      
      // Trim history
      if (this.adjustmentHistory.length > 100) {
        this.adjustmentHistory = this.adjustmentHistory.slice(-50);
      }
    }
    
    this.currentThreshold = clampedThreshold;
    return this.currentThreshold;
  }
  
  /**
   * Calculate individual adjustment factors
   */
  private calculateFactors(context: ThresholdContext): AdjustmentFactors {
    return {
      time: this.calculateTimeFactor(context),
      load: this.calculateLoadFactor(context),
      history: this.calculateHistoryFactor(context),
      cost: this.calculateCostFactor(context)
    };
  }
  
  /**
   * Calculate time-based adjustment factor
   * Relaxes threshold during peak hours to reduce false positives
   */
  private calculateTimeFactor(context: ThresholdContext): number {
    const hour = context.currentHour ?? new Date().getHours();
    const isPeakHour = this.config.peakHours.includes(hour);
    
    if (isPeakHour) {
      // During peak hours: relax threshold by 3%
      // This prevents premature circuit opening during high traffic
      return -0.03;
    }
    
    // Off-peak: standard threshold
    return 0;
  }
  
  /**
   * Calculate load-based adjustment factor
   * Relaxes threshold when system is under high load
   */
  private calculateLoadFactor(context: ThresholdContext): number {
    const load = context.systemLoad;
    
    if (load <= 0.5) {
      // Low load: strict threshold
      return 0;
    } else if (load <= 0.8) {
      // Medium load: slight relaxation
      return -0.01 * ((load - 0.5) / 0.3);
    } else {
      // High load (>80%): progressive relaxation
      // Formula: -0.02 * (load - 0.8) / 0.2
      return -0.02 - 0.04 * ((load - 0.8) / 0.2);
    }
  }
  
  /**
   * Calculate history-based adjustment factor
   * Adjusts based on recent success rate patterns
   */
  private calculateHistoryFactor(context: ThresholdContext): number {
    const historicalRate = context.historicalSuccessRate;
    
    if (historicalRate >= 0.98) {
      // Excellent history: can be stricter
      return 0.01;
    } else if (historicalRate >= 0.95) {
      // Good history: standard
      return 0;
    } else if (historicalRate >= 0.90) {
      // Fair history: slight relaxation
      return -0.01;
    } else {
      // Poor history: more relaxation to prevent flapping
      return -0.02;
    }
  }
  
  /**
   * Calculate cost-based adjustment factor
   * Relaxes threshold in cost-sensitive mode to reduce expensive calls
   */
  private calculateCostFactor(context: ThresholdContext): number {
    if (!context.costSensitive) {
      return 0;
    }
    
    // In cost-sensitive mode: be more aggressive with circuit opening
    // This reduces the number of expensive API calls during uncertainty
    return -0.02;
  }
  
  /**
   * Calculate combined adjustment from factors
   */
  private calculateAdjustment(factors: AdjustmentFactors, context: ThresholdContext): number {
    let adjustment = 0;
    
    // Weighted sum of factors
    adjustment += factors.time * this.config.timeWeight;
    adjustment += factors.load * this.config.loadWeight;
    adjustment += factors.history * this.config.historyWeight;
    adjustment += factors.cost * this.config.costWeight;
    
    // Apply maximum adjustment limit
    return Math.max(-this.config.maxAdjustment, Math.min(this.config.maxAdjustment, adjustment));
  }
  
  /**
   * Smooth threshold update to prevent jitter
   */
  private smoothUpdate(current: number, target: number): number {
    const alpha = this.config.smoothingFactor;
    return current * (1 - alpha) + target * alpha;
  }
  
  /**
   * Check if current hour is a peak hour
   */
  isPeakHour(hour?: number): boolean {
    const h = hour ?? new Date().getHours();
    return this.config.peakHours.includes(h);
  }
  
  /**
   * Get adjustment history
   */
  getAdjustmentHistory(): Array<{ timestamp: number; adjustment: number }> {
    return [...this.adjustmentHistory];
  }
  
  /**
   * Get current adjustment factors for monitoring
   */
  getCurrentFactors(context: ThresholdContext): AdjustmentFactors {
    return this.calculateFactors(context);
  }
  
  /**
   * Reset threshold to base value
   */
  reset(): void {
    this.currentThreshold = this.config.baseThreshold;
    this.adjustmentHistory = [];
  }
  
  /**
   * Set base threshold
   */
  setBaseThreshold(threshold: number): void {
    this.config.baseThreshold = Math.max(
      this.config.minThreshold,
      Math.min(this.config.maxThreshold, threshold)
    );
  }
  
  /**
   * Add peak hour
   */
  addPeakHour(hour: number): void {
    if (!this.config.peakHours.includes(hour)) {
      this.config.peakHours.push(hour);
      this.config.peakHours.sort((a, b) => a - b);
    }
  }
  
  /**
   * Remove peak hour
   */
  removePeakHour(hour: number): void {
    this.config.peakHours = this.config.peakHours.filter(h => h !== hour);
  }
}

export default AdaptiveThreshold;
