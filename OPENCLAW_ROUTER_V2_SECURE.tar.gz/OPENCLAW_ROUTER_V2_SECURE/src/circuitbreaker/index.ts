/**
 * Circuit Breaker V29 - ML-Enhanced Circuit Breaker Module
 * 
 * @module circuitbreaker
 * @version 29.0.0
 */

// Main exports
export { CircuitBreakerV29 } from './CircuitBreakerV29';
export { MLPredictor } from './MLPredictor';
export { AdaptiveThreshold } from './AdaptiveThreshold';

// Type exports
export type {
  CircuitBreakerConfig,
  CircuitState,
  CircuitMetrics,
  StateTransition,
  ExecutionResult,
  PredictionResult,
  ThresholdContext,
  CircuitBreakerEvents,
  LSTMState,
  EMAState
} from './types';

export { DEFAULT_CONFIG } from './types';
export type { MLPredictorConfig } from './MLPredictor';
export type { AdaptiveThresholdConfig } from './AdaptiveThreshold';
