/**
 * Circuit Breaker V29 - ML-Enhanced Circuit Breaker
 * 
 * Features:
 * - EMA (Exponential Moving Average) fast trend detection
 * - LSTM-based ML prediction model
 * - Adaptive threshold algorithm with multi-dimensional adjustments
 * - Multi-state management (CLOSED, OPEN, HALF_OPEN)
 * 
 * Performance Targets:
 * - Prediction accuracy: >94%
 * - False trip rate: <2.5%
 * - Trip response time: <5s
 * - Recovery time: <25s
 * 
 * @version 29.0.0
 * @since 2026-04-12
 */

import { EventEmitter } from 'events';
import {
  CircuitBreakerConfig,
  CircuitState,
  CircuitMetrics,
  StateTransition,
  ExecutionResult,
  ThresholdContext,
  PredictionResult,
  CircuitBreakerEvents,
  DEFAULT_CONFIG
} from './types';
import { MLPredictor } from './MLPredictor';
import { AdaptiveThreshold } from './AdaptiveThreshold';

/**
 * Circuit Breaker V29 Implementation
 */
export class CircuitBreakerV29 extends EventEmitter {
  // Configuration
  private config: CircuitBreakerConfig;
  
  // State
  private state: CircuitState = 'CLOSED';
  private lastStateChangeTime: number = Date.now();
  private halfOpenCallCount: number = 0;
  
  // Components
  private mlPredictor: MLPredictor;
  private adaptiveThreshold: AdaptiveThreshold;
  
  // Metrics
  private metrics: CircuitMetrics;
  
  // Timers
  private resetTimer?: NodeJS.Timeout;
  private metricsSnapshotTimer?: NodeJS.Timeout;
  
  /**
   * Create a new CircuitBreakerV29 instance
   * @param config - Circuit breaker configuration
   */
  constructor(config: Partial<CircuitBreakerConfig> = {}) {
    super();
    
    this.config = { ...DEFAULT_CONFIG, ...config };
    
    // Initialize ML predictor
    this.mlPredictor = new MLPredictor({
      emaAlpha: 0.12,
      lstmWindow: this.config.mlPrediction.predictionWindow,
      minDataPoints: this.config.mlPrediction.minDataPoints
    });
    
    // Initialize adaptive threshold
    this.adaptiveThreshold = new AdaptiveThreshold({
      baseThreshold: this.config.successRateThreshold,
      smoothingFactor: 0.1,
      loadWeight: 0.3,
      timeWeight: 0.2,
      historyWeight: 0.3,
      costWeight: 0.2
    });
    
    // Initialize metrics
    this.metrics = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      consecutiveFailures: 0,
      stateTransitions: [],
      latencyHistory: [],
      successHistory: []
    };
    
    // Start metrics snapshot timer
    this.startMetricsSnapshot();
  }
  
  /**
   * Check if execution is allowed
   * @returns true if execution should proceed
   */
  canExecute(): boolean {
    // 1. Base state check
    if (this.state === 'OPEN') {
      return this.checkResetTimeout();
    }
    
    if (this.state === 'HALF_OPEN') {
      return this.checkHalfOpenQuota();
    }
    
    // 2. ML prediction check (V29 core feature)
    if (this.config.mlPrediction.enabled) {
      const prediction = this.mlPredictor.predictWithLSTM();
      
      if (prediction.confidence > this.config.mlPrediction.confidenceThreshold) {
        // Check if prediction indicates problems
        if (!this.shouldExecuteBasedOnPrediction(prediction)) {
          this.transitionTo('OPEN', 'ML prediction indicates failure');
          return false;
        }
      }
    }
    
    return true;
  }
  
  /**
   * Execute a function with circuit breaker protection
   * @param fn - Function to execute
   * @param context - Execution context for adaptive threshold
   * @returns Execution result
   */
  async execute<T>(
    fn: () => Promise<T>,
    context?: Partial<ThresholdContext>
  ): Promise<ExecutionResult<T>> {
    const startTime = Date.now();
    
    // Check if execution is allowed
    if (!this.canExecute()) {
      const result: ExecutionResult<T> = {
        success: false,
        error: new Error(`Circuit breaker is ${this.state}`),
        latency: Date.now() - startTime,
        circuitState: this.state
      };
      this.emit('execution', result);
      return result;
    }
    
    // Execute the function
    try {
      const data = await fn();
      const latency = Date.now() - startTime;
      
      // Record success
      this.recordSuccess(latency, context);
      
      const result: ExecutionResult<T> = {
        success: true,
        data,
        latency,
        circuitState: this.state
      };
      
      this.emit('execution', result);
      return result;
    } catch (error) {
      const latency = Date.now() - startTime;
      
      // Record failure
      this.recordFailure(latency, context);
      
      const result: ExecutionResult<T> = {
        success: false,
        error: error instanceof Error ? error : new Error(String(error)),
        latency,
        circuitState: this.state
      };
      
      this.emit('execution', result);
      return result;
    }
  }
  
  /**
   * Record a successful execution
   * @param latency - Request latency in ms
   * @param context - Optional threshold context
   */
  recordSuccess(latency: number, context?: Partial<ThresholdContext>): void {
    this.metrics.totalRequests++;
    this.metrics.successfulRequests++;
    this.metrics.consecutiveFailures = 0;
    
    // Record in ML predictor
    this.mlPredictor.recordObservation(latency, true);
    
    // Update history
    this.metrics.latencyHistory.push(latency);
    this.metrics.successHistory.push(true);
    this.trimHistory();
    
    // Handle HALF_OPEN success
    if (this.state === 'HALF_OPEN') {
      this.halfOpenCallCount++;
      
      // If enough successful calls in HALF_OPEN, close the circuit
      if (this.halfOpenCallCount >= this.config.halfOpenMaxCalls) {
        this.transitionTo('CLOSED', 'Recovery threshold reached');
      }
    }
    
    // Update adaptive threshold if context provided
    if (context && this.config.adaptive.enabled) {
      this.adaptiveThreshold.adjustThreshold(context as ThresholdContext);
    }
  }
  
  /**
   * Record a failed execution
   * @param latency - Request latency in ms
   * @param context - Optional threshold context
   */
  recordFailure(latency: number, context?: Partial<ThresholdContext>): void {
    this.metrics.totalRequests++;
    this.metrics.failedRequests++;
    this.metrics.consecutiveFailures++;
    
    // Record in ML predictor
    this.mlPredictor.recordObservation(latency, false);
    
    // Update history
    this.metrics.latencyHistory.push(latency);
    this.metrics.successHistory.push(false);
    this.trimHistory();
    
    // Check if should open circuit
    if (this.shouldOpenCircuit()) {
      this.transitionTo('OPEN', `Failure threshold exceeded: ${this.metrics.consecutiveFailures}`);
    }
    
    // Handle HALF_OPEN failure
    if (this.state === 'HALF_OPEN') {
      this.transitionTo('OPEN', 'Failure during recovery test');
    }
    
    // Update adaptive threshold if context provided
    if (context && this.config.adaptive.enabled) {
      this.adaptiveThreshold.adjustThreshold(context as ThresholdContext);
    }
  }
  
  /**
   * Get current circuit state
   */
  getState(): CircuitState {
    return this.state;
  }
  
  /**
   * Get current metrics
   */
  getMetrics(): CircuitMetrics {
    return {
      ...this.metrics,
      // 测试兼容字段
      requests: this.metrics.totalRequests,
      successes: this.metrics.successfulRequests,
      failures: this.metrics.failedRequests
    };
  }
  
  /**
   * Get current adaptive threshold
   */
  getCurrentThreshold(): number {
    return this.adaptiveThreshold.get();
  }
  
  /**
   * Get ML prediction (for monitoring)
   */
  getPrediction(): PredictionResult {
    return this.mlPredictor.predictWithLSTM();
  }
  
  /**
   * Force transition to a specific state
   * @param state - Target state
   * @param reason - Reason for transition
   */
  forceTransition(state: CircuitState, reason: string): void {
    this.transitionTo(state, reason);
  }
  
  /**
   * Reset circuit breaker to initial state
   */
  reset(): void {
    this.state = 'CLOSED';
    this.lastStateChangeTime = Date.now();
    this.halfOpenCallCount = 0;
    
    this.metrics = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      consecutiveFailures: 0,
      stateTransitions: [],
      latencyHistory: [],
      successHistory: []
    };
    
    this.mlPredictor.reset();
    this.adaptiveThreshold.reset();
    
    this.clearTimers();
  }
  
  /**
   * Destroy circuit breaker and cleanup resources
   */
  destroy(): void {
    this.clearTimers();
    this.removeAllListeners();
  }
  
  /**
   * Get success rate over a time window
   * @param seconds - Time window in seconds
   */
  getSuccessRate(seconds: number = 300): number {
    const historyPoints = Math.min(
      Math.ceil(seconds / 5), // Assume 5s snapshots
      this.metrics.successHistory.length
    );
    
    if (historyPoints === 0) return 1.0;
    
    const recent = this.metrics.successHistory.slice(-historyPoints);
    const successes = recent.filter(s => s).length;
    return successes / recent.length;
  }
  
  /**
   * Get average latency
   */
  getAverageLatency(): number {
    if (this.metrics.latencyHistory.length === 0) return 0;
    const sum = this.metrics.latencyHistory.reduce((a, b) => a + b, 0);
    return sum / this.metrics.latencyHistory.length;
  }
  
  /**
   * Check if circuit should open based on failures
   */
  private shouldOpenCircuit(): boolean {
    // Basic threshold check - must be satisfied first
    if (this.metrics.consecutiveFailures >= this.config.failureThreshold) {
      return true;
    }
    
    // Check recent success rate only if we have enough data points
    // Require at least failureThreshold * 2 data points before using adaptive threshold
    const minDataPoints = this.config.failureThreshold * 2;
    if (this.metrics.successHistory.length >= minDataPoints) {
      const recentSuccessRate = this.getSuccessRate(60); // Last 60 seconds
      if (recentSuccessRate < this.adaptiveThreshold.get()) {
        return true;
      }
    }
    
    return false;
  }
  
  /**
   * Check if execution should proceed based on ML prediction
   */
  private shouldExecuteBasedOnPrediction(prediction: PredictionResult): boolean {
    const threshold = this.adaptiveThreshold.get();
    
    // Predicted success rate too low
    if (prediction.successRate < threshold) {
      return false;
    }
    
    // Predicted latency surge (>2x normal)
    if (prediction.latencyTrend > 2.0) {
      return false;
    }
    
    return true;
  }
  
  /**
   * Check if reset timeout has elapsed (OPEN -> HALF_OPEN)
   */
  private checkResetTimeout(): boolean {
    const elapsed = Date.now() - this.lastStateChangeTime;
    
    if (elapsed >= this.config.resetTimeoutMs) {
      this.transitionTo('HALF_OPEN', 'Reset timeout elapsed');
      return this.checkHalfOpenQuota();
    }
    
    return false;
  }
  
  /**
   * Check if half-open quota allows execution
   */
  private checkHalfOpenQuota(): boolean {
    if (this.halfOpenCallCount < this.config.halfOpenMaxCalls) {
      this.halfOpenCallCount++;
      return true;
    }
    return false;
  }
  
  /**
   * Transition to a new state
   */
  private transitionTo(newState: CircuitState, reason: string): void {
    const oldState = this.state;
    
    if (oldState === newState) return;
    
    this.state = newState;
    this.lastStateChangeTime = Date.now();
    
    // Reset half-open counter when leaving HALF_OPEN
    if (oldState === 'HALF_OPEN') {
      this.halfOpenCallCount = 0;
    }
    
    // Record transition
    const transition: StateTransition = {
      from: oldState,
      to: newState,
      timestamp: Date.now(),
      reason
    };
    this.metrics.stateTransitions.push(transition);
    
    // Emit event
    this.emit('state-change', {
      from: oldState,
      to: newState,
      reason
    });
    
    // Handle OPEN state timer
    if (newState === 'OPEN') {
      this.scheduleResetTimer();
    } else {
      this.clearTimers();
    }
  }
  
  /**
   * Schedule reset timer for OPEN state
   */
  private scheduleResetTimer(): void {
    this.clearTimers();
    this.resetTimer = setTimeout(() => {
      if (this.state === 'OPEN') {
        this.transitionTo('HALF_OPEN', 'Reset timeout elapsed');
      }
    }, this.config.resetTimeoutMs);
  }
  
  /**
   * Start periodic metrics snapshot
   */
  private startMetricsSnapshot(): void {
    this.metricsSnapshotTimer = setInterval(() => {
      // Keep history bounded
      if (this.metrics.latencyHistory.length > 120) {
        this.metrics.latencyHistory = this.metrics.latencyHistory.slice(-60);
        this.metrics.successHistory = this.metrics.successHistory.slice(-60);
      }
    }, 5000);
  }
  
  /**
   * Clear all timers
   */
  private clearTimers(): void {
    if (this.resetTimer) {
      clearTimeout(this.resetTimer);
      this.resetTimer = undefined;
    }
    if (this.metricsSnapshotTimer) {
      clearInterval(this.metricsSnapshotTimer);
      this.metricsSnapshotTimer = undefined;
    }
  }
  
  /**
   * Trim history arrays to bounded size
   */
  private trimHistory(): void {
    const maxSize = this.config.mlPrediction.predictionWindow * 2;
    
    if (this.metrics.latencyHistory.length > maxSize) {
      this.metrics.latencyHistory = this.metrics.latencyHistory.slice(-maxSize);
    }
    if (this.metrics.successHistory.length > maxSize) {
      this.metrics.successHistory = this.metrics.successHistory.slice(-maxSize);
    }
    if (this.metrics.stateTransitions.length > 100) {
      this.metrics.stateTransitions = this.metrics.stateTransitions.slice(-50);
    }
  }
  
  // Typed event emitter methods
  on<K extends keyof CircuitBreakerEvents>(
    event: K,
    listener: (data: CircuitBreakerEvents[K]) => void
  ): this {
    return super.on(event, listener);
  }
  
  emit<K extends keyof CircuitBreakerEvents>(
    event: K,
    data: CircuitBreakerEvents[K]
  ): boolean {
    return super.emit(event, data);
  }
}

export default CircuitBreakerV29;
