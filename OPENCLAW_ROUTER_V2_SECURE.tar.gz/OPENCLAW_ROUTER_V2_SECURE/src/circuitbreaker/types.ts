/**
 * Circuit Breaker V29 - Type Definitions
 * ML-Enhanced Circuit Breaker with EMA-LSTM Prediction
 * 
 * @version 29.0.0
 * @since 2026-04-12
 */

/**
 * Circuit breaker states
 */
export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

/**
 * Circuit breaker configuration interface
 */
export interface CircuitBreakerConfig {
  /** Base failure threshold before opening circuit */
  failureThreshold: number;
  
  /** Reset timeout in milliseconds */
  resetTimeoutMs: number;
  
  /** Maximum calls allowed in half-open state */
  halfOpenMaxCalls: number;
  
  /** Success rate threshold (0-1) */
  successRateThreshold: number;
  
  /** ML prediction configuration */
  mlPrediction: {
    enabled: boolean;
    predictionWindow: number;
    minDataPoints: number;
    confidenceThreshold: number;
  };
  
  /** Adaptive threshold configuration */
  adaptive: {
    enabled: boolean;
    loadFactor: boolean;
    timeFactor: boolean;
    costFactor: boolean;
  };
}

/**
 * ML prediction result
 */
export interface PredictionResult {
  /** Predicted success rate (0-1) */
  successRate: number;
  
  /** Latency trend factor (>1 means increasing) */
  latencyTrend: number;
  
  /** Prediction confidence (0-1) */
  confidence: number;
  
  /** Raw feature vector used for prediction */
  features?: number[];
}

/**
 * Threshold context for adaptive adjustments
 */
export interface ThresholdContext {
  /** System load (0-1) */
  systemLoad: number;
  
  /** Historical success rate over 5min window */
  historicalSuccessRate: number;
  
  /** Cost sensitive mode flag */
  costSensitive: boolean;
  
  /** Current hour (0-23) for time-based adjustments */
  currentHour?: number;
  
  /** Request queue depth */
  queueDepth?: number;
}

/**
 * Circuit metrics for monitoring
 */
export interface CircuitMetrics {
  /** Total requests */
  totalRequests: number;
  
  /** Successful requests */
  successfulRequests: number;
  
  /** Failed requests */
  failedRequests: number;
  
  /** Current consecutive failures */
  consecutiveFailures: number;
  
  /** State transition history */
  stateTransitions: StateTransition[];
  
  /** Latency history (last 60 points) */
  latencyHistory: number[];
  
  /** Success history (last 60 points) */
  successHistory: boolean[];
  
  /** Test compatibility field - alias for totalRequests */
  requests?: number;
  
  /** Test compatibility field - alias for successfulRequests */
  successes?: number;
  
  /** Test compatibility field - alias for failedRequests */
  failures?: number;
}

/**
 * State transition record
 */
export interface StateTransition {
  /** Previous state */
  from: CircuitState;
  
  /** New state */
  to: CircuitState;
  
  /** Timestamp */
  timestamp: number;
  
  /** Reason for transition */
  reason: string;
}

/**
 * Execution result for circuit breaker
 */
export interface ExecutionResult<T> {
  /** Whether execution was successful */
  success: boolean;
  
  /** Result data (if success) */
  data?: T;
  
  /** Error (if failed) */
  error?: Error;
  
  /** Execution latency in ms */
  latency: number;
  
  /** Circuit state at time of execution */
  circuitState: CircuitState;
}

/**
 * LSTM cell state
 */
export interface LSTMState {
  /** Hidden state vector */
  hidden: number[];
  
  /** Cell state vector */
  cell: number[];
}

/**
 * EMA (Exponential Moving Average) calculator state
 */
export interface EMAState {
  /** Current EMA value */
  value: number;
  
  /** Alpha parameter */
  alpha: number;
  
  /** Sample count */
  count: number;
}

/**
 * Default circuit breaker configuration
 */
export const DEFAULT_CONFIG: CircuitBreakerConfig = {
  failureThreshold: 3,
  resetTimeoutMs: 20000,
  halfOpenMaxCalls: 5,
  successRateThreshold: 0.92,
  mlPrediction: {
    enabled: true,
    predictionWindow: 60,
    minDataPoints: 20,
    confidenceThreshold: 0.85
  },
  adaptive: {
    enabled: true,
    loadFactor: true,
    timeFactor: true,
    costFactor: false
  }
};

/**
 * Circuit breaker events
 */
export interface CircuitBreakerEvents {
  'state-change': { from: CircuitState; to: CircuitState; reason: string };
  'prediction': PredictionResult;
  'threshold-adjust': { old: number; new: number; context: ThresholdContext };
  'execution': ExecutionResult<unknown>;
}
