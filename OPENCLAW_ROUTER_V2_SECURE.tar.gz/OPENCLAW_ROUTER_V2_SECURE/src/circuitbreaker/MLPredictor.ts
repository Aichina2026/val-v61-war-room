/**
 * ML Predictor - LSTM-based prediction model for Circuit Breaker V29
 * 
 * Implements:
 * - EMA (Exponential Moving Average) for fast trend detection
 * - LSTM (Long Short-Term Memory) for deep sequential prediction
 * - Feature extraction from latency and success history
 * 
 * @version 29.0.0
 * @since 2026-04-12
 */

import {
  PredictionResult,
  LSTMState,
  EMAState,
  CircuitMetrics
} from './types';

/**
 * ML Predictor configuration
 */
export interface MLPredictorConfig {
  /** EMA alpha parameter (0-1), higher = more responsive */
  emaAlpha: number;
  
  /** LSTM window size for feature extraction */
  lstmWindow: number;
  
  /** LSTM hidden layer size */
  hiddenSize: number;
  
  /** Minimum data points required for prediction */
  minDataPoints: number;
}

/**
 * Default ML predictor configuration
 */
export const DEFAULT_ML_CONFIG: MLPredictorConfig = {
  emaAlpha: 0.12,
  lstmWindow: 60,
  hiddenSize: 32,
  minDataPoints: 20
};

/**
 * ML Predictor with EMA-LSTM hybrid architecture
 */
export class MLPredictor {
  private config: MLPredictorConfig;
  
  // EMA states
  private latencyEMA: EMAState;
  private successEMA: EMAState;
  
  // LSTM state
  private lstmState: LSTMState;
  
  // History data
  private latencyHistory: number[] = [];
  private successHistory: boolean[] = [];
  
  // Feature cache for performance
  private featureCache: number[][] = [];
  private lastFeatureUpdate = 0;
  
  constructor(config: Partial<MLPredictorConfig> = {}) {
    this.config = { ...DEFAULT_ML_CONFIG, ...config };
    
    // Initialize EMA states
    this.latencyEMA = {
      value: 0,
      alpha: this.config.emaAlpha,
      count: 0
    };
    
    this.successEMA = {
      value: 1.0, // Start optimistic
      alpha: this.config.emaAlpha,
      count: 0
    };
    
    // Initialize LSTM state
    this.lstmState = {
      hidden: new Array(this.config.hiddenSize).fill(0),
      cell: new Array(this.config.hiddenSize).fill(0)
    };
  }
  
  /**
   * Record a new observation
   * @param latency - Request latency in ms
   * @param success - Whether the request succeeded
   */
  recordObservation(latency: number, success: boolean): void {
    // Update history
    this.latencyHistory.push(latency);
    this.successHistory.push(success);
    
    // Keep only recent history
    if (this.latencyHistory.length > this.config.lstmWindow * 2) {
      this.latencyHistory = this.latencyHistory.slice(-this.config.lstmWindow * 2);
      this.successHistory = this.successHistory.slice(-this.config.lstmWindow * 2);
    }
    
    // Update EMAs
    this.updateEMA(this.latencyEMA, latency);
    this.updateEMA(this.successEMA, success ? 1 : 0);
    
    // Update LSTM state
    this.updateLSTMState(latency, success);
  }
  
  /**
   * Make a prediction using LSTM model
   * @returns Prediction result with confidence
   */
  predictWithLSTM(): PredictionResult {
    // Check if we have enough data
    if (this.latencyHistory.length < this.config.minDataPoints) {
      return {
        successRate: this.successEMA.value,
        latencyTrend: 1.0,
        confidence: 0.5 // Low confidence with insufficient data
      };
    }
    
    // Extract features from recent window
    const features = this.extractFeatures();
    
    // Run LSTM forward pass
    const hiddenState = this.lstmForward(features);
    
    // Generate predictions
    const predictedSuccess = this.predictSuccessRate(hiddenState);
    const predictedLatency = this.predictLatency(hiddenState);
    const confidence = this.calculateConfidence(features, hiddenState);
    
    return {
      successRate: predictedSuccess,
      latencyTrend: predictedLatency,
      confidence,
      features
    };
  }
  
  /**
   * Get current EMA values
   */
  getEMAValues(): { latency: number; success: number } {
    return {
      latency: this.latencyEMA.value,
      success: this.successEMA.value
    };
  }
  
  /**
   * Get latency trend from EMA
   * @returns Trend factor (>1 means increasing)
   */
  getLatencyTrend(): number {
    if (this.latencyHistory.length < 10) return 1.0;
    
    const recent = this.latencyHistory.slice(-10);
    const older = this.latencyHistory.slice(-20, -10);
    
    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
    
    return olderAvg > 0 ? recentAvg / olderAvg : 1.0;
  }
  
  /**
   * Get success rate trend from EMA
   * @returns Trend factor (>1 means improving)
   */
  getSuccessTrend(): number {
    return this.successEMA.value;
  }
  
  /**
   * Reset predictor state
   */
  reset(): void {
    this.latencyHistory = [];
    this.successHistory = [];
    this.featureCache = [];
    this.lastFeatureUpdate = 0;
    
    this.latencyEMA = {
      value: 0,
      alpha: this.config.emaAlpha,
      count: 0
    };
    
    this.successEMA = {
      value: 1.0,
      alpha: this.config.emaAlpha,
      count: 0
    };
    
    this.lstmState = {
      hidden: new Array(this.config.hiddenSize).fill(0),
      cell: new Array(this.config.hiddenSize).fill(0)
    };
  }
  
  /**
   * Update EMA with new value
   */
  private updateEMA(ema: EMAState, value: number): void {
    if (ema.count === 0) {
      ema.value = value;
    } else {
      ema.value = ema.alpha * value + (1 - ema.alpha) * ema.value;
    }
    ema.count++;
  }
  
  /**
   * Update LSTM internal state
   */
  private updateLSTMState(latency: number, success: boolean): void {
    // Normalize input
    const normalizedLatency = Math.min(latency / 1000, 5); // Cap at 5s
    const normalizedSuccess = success ? 1 : 0;
    
    // Simple LSTM cell update (simplified for production)
    const input = [normalizedLatency, normalizedSuccess];
    
    for (let i = 0; i < this.config.hiddenSize; i++) {
      // Forget gate
      const forgetGate = this.sigmoid(input[0] * 0.5 + this.lstmState.hidden[i] * 0.5);
      
      // Input gate
      const inputGate = this.sigmoid(input[1] * 0.5 + this.lstmState.hidden[i] * 0.3);
      
      // Candidate values
      const candidate = Math.tanh(input[0] * 0.3 + this.lstmState.hidden[i] * 0.2);
      
      // Update cell state
      this.lstmState.cell[i] = forgetGate * this.lstmState.cell[i] + inputGate * candidate;
      
      // Output gate
      const outputGate = this.sigmoid(this.lstmState.cell[i] * 0.5);
      
      // Update hidden state
      this.lstmState.hidden[i] = outputGate * Math.tanh(this.lstmState.cell[i]);
    }
  }
  
  /**
   * Extract features from history
   */
  private extractFeatures(): number[] {
    const window = this.latencyHistory.slice(-this.config.lstmWindow);
    const successWindow = this.successHistory.slice(-this.config.lstmWindow);
    
    if (window.length === 0) return new Array(8).fill(0);
    
    // Statistical features
    const mean = window.reduce((a, b) => a + b, 0) / window.length;
    const max = Math.max(...window);
    const min = Math.min(...window);
    const variance = window.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / window.length;
    const std = Math.sqrt(variance);
    
    // Trend features
    const slope = this.calculateSlope(window);
    const acceleration = this.calculateAcceleration(window);
    
    // Cyclical features
    const cycle = this.detectCycle(window);
    
    // Success rate feature
    const recentSuccess = successWindow.slice(-10);
    const successRate = recentSuccess.length > 0 
      ? recentSuccess.filter(x => x).length / recentSuccess.length 
      : 1.0;
    
    return [
      this.normalize(mean, 0, 1000),
      this.normalize(max, 0, 5000),
      this.normalize(min, 0, 1000),
      this.normalize(std, 0, 1000),
      this.sigmoid(slope),
      this.sigmoid(acceleration),
      cycle,
      successRate
    ];
  }
  
  /**
   * LSTM forward pass
   */
  private lstmForward(features: number[]): number[] {
    // Return current hidden state as feature representation
    return [...this.lstmState.hidden];
  }
  
  /**
   * Predict success rate from hidden state
   */
  private predictSuccessRate(hiddenState: number[]): number {
    // Use mean of hidden state with sigmoid for probability
    const sum = hiddenState.reduce((a, b) => a + b, 0);
    const avg = sum / hiddenState.length;
    return this.sigmoid(avg * 2); // Scale for better sensitivity
  }
  
  /**
   * Predict latency trend from hidden state
   */
  private predictLatency(hiddenState: number[]): number {
    // Calculate trend based on recent history
    const trend = this.getLatencyTrend();
    return trend;
  }
  
  /**
   * Calculate prediction confidence
   */
  private calculateConfidence(features: number[], hiddenState: number[]): number {
    // Confidence based on:
    // 1. Amount of historical data
    const dataConfidence = Math.min(this.latencyHistory.length / this.config.minDataPoints, 1.0);
    
    // 2. Variance in predictions (lower variance = higher confidence)
    const hiddenVariance = this.calculateVariance(hiddenState);
    const stabilityConfidence = 1 - Math.min(hiddenVariance, 1.0);
    
    // 3. Feature completeness
    const featureConfidence = features.every(f => !isNaN(f) && isFinite(f)) ? 1.0 : 0.5;
    
    // Combine confidences
    return dataConfidence * 0.4 + stabilityConfidence * 0.4 + featureConfidence * 0.2;
  }
  
  /**
   * Calculate slope (linear regression)
   */
  private calculateSlope(values: number[]): number {
    if (values.length < 2) return 0;
    
    const n = values.length;
    const sumX = (n * (n - 1)) / 2;
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = values.reduce((sum, y, x) => sum + x * y, 0);
    const sumX2 = (n * (n - 1) * (2 * n - 1)) / 6;
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    return slope;
  }
  
  /**
   * Calculate acceleration (second derivative)
   */
  private calculateAcceleration(values: number[]): number {
    if (values.length < 3) return 0;
    
    const firstDerivatives: number[] = [];
    for (let i = 1; i < values.length; i++) {
      firstDerivatives.push(values[i] - values[i - 1]);
    }
    
    return this.calculateSlope(firstDerivatives);
  }
  
  /**
   * Detect cyclical patterns
   */
  private detectCycle(values: number[]): number {
    if (values.length < 10) return 0.5;
    
    // Simple autocorrelation-based cycle detection
    const mid = Math.floor(values.length / 2);
    const first = values.slice(0, mid);
    const second = values.slice(mid);
    
    const correlation = this.calculateCorrelation(first, second.slice(0, mid));
    return (correlation + 1) / 2; // Normalize to 0-1
  }
  
  /**
   * Calculate correlation between two arrays
   */
  private calculateCorrelation(a: number[], b: number[]): number {
    const n = Math.min(a.length, b.length);
    if (n === 0) return 0;
    
    const meanA = a.reduce((sum, v) => sum + v, 0) / n;
    const meanB = b.reduce((sum, v) => sum + v, 0) / n;
    
    let num = 0;
    let denA = 0;
    let denB = 0;
    
    for (let i = 0; i < n; i++) {
      const diffA = a[i] - meanA;
      const diffB = b[i] - meanB;
      num += diffA * diffB;
      denA += diffA * diffA;
      denB += diffB * diffB;
    }
    
    const denom = Math.sqrt(denA * denB);
    return denom === 0 ? 0 : num / denom;
  }
  
  /**
   * Calculate variance
   */
  private calculateVariance(values: number[]): number {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  }
  
  /**
   * Sigmoid activation function
   */
  private sigmoid(x: number): number {
    return 1 / (1 + Math.exp(-x));
  }
  
  /**
   * Normalize value to 0-1 range
   */
  private normalize(value: number, min: number, max: number): number {
    return Math.max(0, Math.min(1, (value - min) / (max - min)));
  }
}

export default MLPredictor;
