/**
 * Circuit Breaker V29 - Unit Tests
 * 
 * Test Coverage:
 * - State transitions (CLOSED -> OPEN -> HALF_OPEN -> CLOSED)
 * - EMA calculation accuracy
 * - LSTM prediction functionality
 * - Adaptive threshold adjustments
 * - Edge cases and error handling
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { CircuitBreakerV29 } from '../CircuitBreakerV29';
import { CircuitBreakerConfig } from '../types';

describe('CircuitBreakerV29', () => {
  let cb: CircuitBreakerV29;
  
  const defaultConfig: CircuitBreakerConfig = {
    failureThreshold: 3,
    resetTimeoutMs: 1000, // 1s for testing
    halfOpenMaxCalls: 3,
    successRateThreshold: 0.92,
    mlPrediction: {
      enabled: true,
      predictionWindow: 60,
      minDataPoints: 10,
      confidenceThreshold: 0.85
    },
    adaptive: {
      enabled: true,
      loadFactor: true,
      timeFactor: true,
      costFactor: false
    }
  };
  
  beforeEach(() => {
    // 使用新的配置对象，避免测试间状态污染
    cb = new CircuitBreakerV29({ ...defaultConfig });
  });
  
  afterEach(() => {
    cb.destroy();
  });
  
  describe('State Management', () => {
    it('should start in CLOSED state', () => {
      expect(cb.getState()).toBe('CLOSED');
    });
    
    it('should transition to OPEN after failure threshold', () => {
      // Record 3 failures
      cb.recordFailure(100);
      cb.recordFailure(100);
      cb.recordFailure(100);
      
      expect(cb.getState()).toBe('OPEN');
    });
    
    it('should not transition to OPEN before threshold', () => {
      // 创建新的熔断器，确保阈值正确设置
      const testCb = new CircuitBreakerV29({ failureThreshold: 5 });
      testCb.recordFailure(100);
      testCb.recordFailure(100);
      
      expect(testCb.getState()).toBe('CLOSED');
      testCb.destroy();
    });
    
    it('should reset consecutive failures on success', () => {
      // 创建新的熔断器，确保阈值正确设置
      const testCb = new CircuitBreakerV29({ failureThreshold: 5 });
      testCb.recordFailure(100);
      testCb.recordFailure(100);
      testCb.recordSuccess(50);
      testCb.recordFailure(100);
      
      expect(testCb.getState()).toBe('CLOSED');
      testCb.destroy();
    });
    
    it('should transition OPEN -> HALF_OPEN after timeout', async () => {
      cb.recordFailure(100);
      cb.recordFailure(100);
      cb.recordFailure(100);
      
      expect(cb.getState()).toBe('OPEN');
      
      // Wait for reset timeout
      await new Promise(r => setTimeout(r, 1100));
      
      // Try to execute - should trigger HALF_OPEN check
      cb.canExecute();
      
      expect(cb.getState()).toBe('HALF_OPEN');
    });
    
    it('should transition HALF_OPEN -> CLOSED after success threshold', () => {
      cb.forceTransition('HALF_OPEN', 'Test');
      
      cb.recordSuccess(50);
      cb.recordSuccess(50);
      cb.recordSuccess(50);
      
      expect(cb.getState()).toBe('CLOSED');
    });
    
    it('should transition HALF_OPEN -> OPEN on failure', () => {
      cb.forceTransition('HALF_OPEN', 'Test');
      
      cb.recordFailure(100);
      
      expect(cb.getState()).toBe('OPEN');
    });
  });
  
  describe('Execute Method', () => {
    it('should execute successful function', async () => {
      const result = await cb.execute(async () => 'success');
      
      expect(result.success).toBe(true);
      expect(result.data).toBe('success');
    });
    
    it('should handle function failure', async () => {
      const result = await cb.execute(async () => {
        throw new Error('test error');
      });
      
      expect(result.success).toBe(false);
      expect(result.error?.message).toBe('test error');
    });
    
    it('should reject execution when OPEN', async () => {
      cb.forceTransition('OPEN', 'Test');
      
      const result = await cb.execute(async () => 'success');
      
      expect(result.success).toBe(false);
      expect(result.circuitState).toBe('OPEN');
    });
  });
  
  describe('Metrics', () => {
    it('should track total requests', () => {
      cb.recordSuccess(50);
      cb.recordSuccess(50);
      cb.recordFailure(100);
      
      const metrics = cb.getMetrics();
      expect(metrics.totalRequests).toBe(3);
      expect(metrics.successfulRequests).toBe(2);
      expect(metrics.failedRequests).toBe(1);
    });
    
    it('should track consecutive failures', () => {
      cb.recordFailure(100);
      cb.recordFailure(100);
      
      const metrics = cb.getMetrics();
      expect(metrics.consecutiveFailures).toBe(2);
    });
    
    it('should reset consecutive failures on success', () => {
      cb.recordFailure(100);
      cb.recordFailure(100);
      cb.recordSuccess(50);
      
      const metrics = cb.getMetrics();
      expect(metrics.consecutiveFailures).toBe(0);
    });
    
    it('should track state transitions', () => {
      cb.forceTransition('OPEN', 'Test transition');
      
      const metrics = cb.getMetrics();
      expect(metrics.stateTransitions.length).toBe(1);
      expect(metrics.stateTransitions[0].from).toBe('CLOSED');
      expect(metrics.stateTransitions[0].to).toBe('OPEN');
      expect(metrics.stateTransitions[0].reason).toBe('Test transition');
    });
    
    it('should calculate success rate', () => {
      cb.recordSuccess(50);
      cb.recordSuccess(50);
      cb.recordFailure(100);
      
      expect(cb.getSuccessRate(300)).toBeCloseTo(2/3, 2);
    });
    
    it('should calculate average latency', () => {
      cb.recordSuccess(100);
      cb.recordSuccess(200);
      cb.recordSuccess(300);
      
      expect(cb.getAverageLatency()).toBe(200);
    });
  });
  
  describe('ML Prediction', () => {
    it('should provide prediction', () => {
      // Add some data
      for (let i = 0; i < 15; i++) {
        cb.recordSuccess(50);
      }
      
      const prediction = cb.getPrediction();
      
      expect(prediction.successRate).toBeGreaterThanOrEqual(0);
      expect(prediction.successRate).toBeLessThanOrEqual(1);
      expect(prediction.confidence).toBeGreaterThanOrEqual(0);
      expect(prediction.confidence).toBeLessThanOrEqual(1);
    });
    
    it('should have low confidence with insufficient data', () => {
      cb.recordSuccess(50);
      
      const prediction = cb.getPrediction();
      expect(prediction.confidence).toBeLessThan(0.8);
    });
  });
  
  describe('Reset and Destroy', () => {
    it('should reset to initial state', () => {
      cb.recordFailure(100);
      cb.recordFailure(100);
      cb.recordFailure(100);
      
      expect(cb.getState()).toBe('OPEN');
      
      cb.reset();
      
      expect(cb.getState()).toBe('CLOSED');
      expect(cb.getMetrics().totalRequests).toBe(0);
    });
    
    it('should cleanup on destroy', () => {
      cb.destroy();
      expect(cb.listenerCount('execution')).toBe(0);
      expect(cb.listenerCount('state-change')).toBe(0);
    });
  });
});
