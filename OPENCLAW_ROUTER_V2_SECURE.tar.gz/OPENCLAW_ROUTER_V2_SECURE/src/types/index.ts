/**
 * OpenClaw Router V2.0 - 全局类型定义
 * 
 * @module types
 * @version 2.0.0
 * @description 智能路由系统的核心类型定义，支持4AI工作流编排
 */

import { EventEmitter } from 'eventemitter3';

// ============================================
// 基础枚举类型
// ============================================

/**
 * 路由策略类型
 */
export enum RoutingStrategy {
  ROUND_ROBIN = 'round-robin',
  WEIGHTED = 'weighted',
  ADAPTIVE = 'adaptive',
  ML_PREDICTIVE = 'ml-predictive',
  RANDOM = 'random'
}

/**
 * 熔断器状态
 */
export enum CircuitBreakerState {
  CLOSED = 'CLOSED',
  OPEN = 'OPEN',
  HALF_OPEN = 'HALF_OPEN',
  FORCED_OPEN = 'FORCED_OPEN'
}

/**
 * 节点健康状态
 */
export enum NodeHealthStatus {
  HEALTHY = 'healthy',
  DEGRADED = 'degraded',
  UNHEALTHY = 'unhealthy',
  OFFLINE = 'offline'
}

/**
 * 日志级别
 */
export enum LogLevel {
  TRACE = 'trace',
  DEBUG = 'debug',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error',
  FATAL = 'fatal'
}

// ============================================
// 核心配置类型
// ============================================

/**
 * 路由器配置
 */
export interface RouterConfig {
  /** 默认路由策略 */
  defaultStrategy: RoutingStrategy;
  /** 最大并发请求数 */
  maxConcurrent: number;
  /** 请求超时时间 (毫秒) */
  requestTimeout: number;
  /** 启用ML预测 */
  mlPredictEnabled: boolean;
  /** ML模型路径 */
  mlModelPath?: string;
  /** 健康检查间隔 (毫秒) */
  healthCheckInterval: number;
  /** 节点池配置 */
  nodePool: NodePoolConfig;
}

/**
 * 节点池配置
 */
export interface NodePoolConfig {
  /** 节点列表 */
  nodes: NodeConfig[];
  /** 节点选择策略 */
  selectionStrategy: RoutingStrategy;
  /** 节点健康检查启用 */
  healthCheckEnabled: boolean;
}

/**
 * 节点配置
 */
export interface NodeConfig {
  /** 节点唯一标识 */
  id: string;
  /** 节点名称 */
  name: string;
  /** 节点URL */
  url: string;
  /** 节点权重 (用于加权轮询) */
  weight: number;
  /** 节点优先级 */
  priority: number;
  /** 节点标签 */
  tags: string[];
  /** 节点能力 */
  capabilities: NodeCapability[];
  /** 最大并发 */
  maxConcurrency: number;
  /** 超时配置 */
  timeout: TimeoutConfig;
}

/**
 * 节点能力
 */
export interface NodeCapability {
  /** 能力类型 */
  type: string;
  /** 能力版本 */
  version: string;
  /** 是否启用 */
  enabled: boolean;
}

/**
 * 超时配置
 */
export interface TimeoutConfig {
  /** 连接超时 */
  connect: number;
  /** 读取超时 */
  read: number;
  /** 写入超时 */
  write: number;
}

// ============================================
// 熔断器类型 (V29)
// ============================================

/**
 * 熔断器配置
 */
export interface CircuitBreakerConfig {
  /** 健康阈值 (0-1) */
  healthThreshold: number;
  /** 半开状态最大调用数 */
  halfOpenMaxCalls: number;
  /** 失败率阈值 */
  failureThreshold: number;
  /** 慢调用阈值 (毫秒) */
  slowCallThreshold: number;
  /** 慢调用率阈值 */
  slowCallRateThreshold: number;
  /** 熔断后等待时间 (毫秒) */
  waitDuration: number;
  /** 滑动窗口大小 */
  slidingWindowSize: number;
  /** 最小调用数 (用于计算失败率) */
  minimumNumberOfCalls: number;
}

/**
 * 熔断器指标
 */
export interface CircuitBreakerMetrics {
  /** 状态 */
  state: CircuitBreakerState;
  /** 健康度 (0-1) */
  healthScore: number;
  /** 总调用数 */
  totalCalls: number;
  /** 成功调用数 */
  successfulCalls: number;
  /** 失败调用数 */
  failedCalls: number;
  /** 慢调用数 */
  slowCalls: number;
  /** 当前失败率 */
  failureRate: number;
  /** 当前慢调用率 */
  slowCallRate: number;
  /** 平均响应时间 */
  avgResponseTime: number;
  /** 最后状态变更时间 */
  lastStateChange: Date;
  /** EMA延迟预测值 */
  emaLatency: number;
  /** 测试兼容字段 - 总请求数 */
  requests?: number;
  /** 测试兼容字段 - 成功数 */
  successes?: number;
  /** 测试兼容字段 - 失败数 */
  failures?: number;
}

/**
 * 熔断器事件
 */
export interface CircuitBreakerEvent {
  /** 事件类型 */
  type: 'state-change' | 'threshold-exceeded' | 'recovery';
  /** 熔断器名称 */
  name: string;
  /** 事件数据 */
  data: {
    fromState?: CircuitBreakerState;
    toState?: CircuitBreakerState;
    metrics?: CircuitBreakerMetrics;
    timestamp: Date;
  };
}

// ============================================
// Key池类型
// ============================================

/**
 * Key池配置
 */
export interface KeyPoolConfig {
  /** Key列表 */
  keys: string[];
  /** 池大小 */
  poolSize: number;
  /** 轮询策略 */
  strategy: KeyPoolStrategy;
  /** 健康检查间隔 (毫秒) */
  healthCheckInterval: number;
  /** 最大失败次数 */
  maxFailures: number;
  /** 冷却时间 (毫秒) */
  cooldownDuration: number;
}

/**
 * Key池策略
 */
export type KeyPoolStrategy = 'round-robin' | 'random' | 'weighted-response-time';

/**
 * Key状态
 */
export interface KeyState {
  /** Key值 (脱敏) */
  id: string;
  /** 当前索引 */
  index: number;
  /** 健康状态 */
  health: NodeHealthStatus;
  /** 连续失败次数 */
  consecutiveFailures: number;
  /** 总请求数 */
  totalRequests: number;
  /** 成功请求数 */
  successfulRequests: number;
  /** 平均响应时间 */
  avgResponseTime: number;
  /** 最后使用时间 */
  lastUsedAt: Date;
  /** 冷却到期时间 */
  cooldownUntil?: Date;
  /** 权重 */
  weight: number;
}

/**
 * Key池统计
 */
export interface KeyPoolStats {
  /** 总Key数 */
  totalKeys: number;
  /** 健康Key数 */
  healthyKeys: number;
  /** 降级Key数 */
  degradedKeys: number;
  /** 不健康Key数 */
  unhealthyKeys: number;
  /** 总请求数 */
  totalRequests: number;
  /** 当前QPS */
  currentQps: number;
  /** 平均响应时间 */
  avgResponseTime: number;
}

// ============================================
// 请求/响应类型
// ============================================

/**
 * AI请求
 */
export interface AIRequest {
  /** 请求ID */
  id: string;
  /** 消息内容 */
  messages: Message[];
  /** 模型标识 */
  model?: string;
  /** 温度参数 */
  temperature?: number;
  /** 最大令牌数 */
  maxTokens?: number;
  /** 流式响应 */
  stream?: boolean;
  /** 工具调用 */
  tools?: ToolDefinition[];
  /** 响应格式 */
  responseFormat?: ResponseFormat;
  /** 元数据 */
  metadata: RequestMetadata;
}

/**
 * 消息
 */
export interface Message {
  /** 角色 */
  role: 'system' | 'user' | 'assistant' | 'tool';
  /** 内容 */
  content: string;
  /** 工具调用 */
  toolCalls?: ToolCall[];
  /** 工具调用ID */
  toolCallId?: string;
}

/**
 * 工具定义
 */
export interface ToolDefinition {
  /** 工具类型 */
  type: 'function';
  /** 函数定义 */
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
}

/**
 * 工具调用
 */
export interface ToolCall {
  /** 调用ID */
  id: string;
  /** 工具类型 */
  type: 'function';
  /** 函数 */
  function: {
    name: string;
    arguments: string;
  };
}

/**
 * 响应格式
 */
export interface ResponseFormat {
  type: 'text' | 'json_object' | 'json_schema';
  schema?: Record<string, unknown>;
}

/**
 * 请求元数据
 */
export interface RequestMetadata {
  /** 来源 */
  source: string;
  /** 用户ID */
  userId?: string;
  /** 会话ID */
  sessionId?: string;
  /** 优先级 */
  priority: number;
  /** 创建时间 */
  createdAt: Date;
  /** 过期时间 */
  expiresAt?: Date;
  /** 标签 */
  tags: string[];
}

/**
 * AI响应
 */
export interface AIResponse {
  /** 响应ID */
  id: string;
  /** 请求ID */
  requestId: string;
  /** 选择结果 */
  choices: ResponseChoice[];
  /** 使用量统计 */
  usage: TokenUsage;
  /** 模型 */
  model: string;
  /** 创建时间 */
  createdAt: Date;
  /** 路由信息 */
  routing: RoutingInfo;
}

/**
 * 响应选择
 */
export interface ResponseChoice {
  /** 索引 */
  index: number;
  /** 消息 */
  message: Message;
  /** 结束原因 */
  finishReason: string;
  /** 日志概率 */
  logprobs?: unknown;
}

/**
 * Token使用量
 */
export interface TokenUsage {
  /** 提示令牌数 */
  promptTokens: number;
  /** 完成令牌数 */
  completionTokens: number;
  /** 总令牌数 */
  totalTokens: number;
}

/**
 * 路由信息
 */
export interface RoutingInfo {
  /** 路由节点ID */
  nodeId: string;
  /** 路由策略 */
  strategy: RoutingStrategy;
  /** 路由耗时 */
  routingDuration: number;
  /** 实际调用耗时 */
  callDuration: number;
  /** 重试次数 */
  retryCount: number;
  /** 使用的Key索引 */
  keyIndex: number;
}

// ============================================
// 事件类型
// ============================================

/**
 * 路由事件
 */
export interface RoutingEvent {
  /** 事件类型 */
  type: 'request-start' | 'request-success' | 'request-failure' | 'route-selected';
  /** 请求ID */
  requestId: string;
  /** 时间戳 */
  timestamp: Date;
  /** 数据 */
  data: {
    nodeId?: string;
    strategy?: RoutingStrategy;
    duration?: number;
    error?: Error;
  };
}

/**
 * 系统事件
 */
export interface SystemEvent {
  /** 事件类型 */
  type: 'startup' | 'shutdown' | 'config-change' | 'error';
  /** 时间戳 */
  timestamp: Date;
  /** 数据 */
  data: Record<string, unknown>;
}

// ============================================
// 服务接口
// ============================================

/**
 * 路由器接口
 */
export interface IRouter extends EventEmitter {
  /** 初始化 */
  initialize(): Promise<void>;
  /** 路由请求 */
  route(request: AIRequest): Promise<AIResponse>;
  /** 获取节点状态 */
  getNodeStatus(nodeId: string): NodeHealthStatus;
  /** 获取所有节点状态 */
  getAllNodeStatus(): Map<string, NodeHealthStatus>;
  /** 关闭 */
  shutdown(): Promise<void>;
}

/**
 * 熔断器接口
 */
export interface ICircuitBreaker extends EventEmitter {
  /** 执行受保护的调用 */
  execute<T>(fn: () => Promise<T>): Promise<T>;
  /** 获取当前状态 */
  getState(): CircuitBreakerState;
  /** 获取指标 */
  getMetrics(): CircuitBreakerMetrics;
  /** 强制打开 */
  forceOpen(): void;
  /** 强制关闭 */
  forceClose(): void;
}

/**
 * Key池接口
 */
export interface IKeyPool extends EventEmitter {
  /** 获取下一个Key */
  acquireKey(): Promise<KeyState>;
  /** 释放Key */
  releaseKey(keyId: string, success: boolean, responseTime: number): void;
  /** 获取Key统计 */
  getStats(): KeyPoolStats;
  /** 健康检查 */
  healthCheck(): Promise<void>;
}

// ============================================
// 日志与监控类型
// ============================================

/**
 * 日志配置
 */
export interface LogConfig {
  /** 日志级别 */
  level: LogLevel;
  /** 日志格式 */
  format: 'json' | 'pretty';
  /** 日志文件路径 */
  filePath?: string;
  /** 启用请求日志 */
  logRequests: boolean;
  /** 启用响应日志 */
  logResponses: boolean;
}

/**
 * 指标数据点
 */
export interface MetricPoint {
  /** 指标名称 */
  name: string;
  /** 指标值 */
  value: number;
  /** 标签 */
  labels: Record<string, string>;
  /** 时间戳 */
  timestamp: Date;
}

/**
 * 健康检查响应
 */
export interface HealthCheckResponse {
  /** 状态 */
  status: 'healthy' | 'unhealthy' | 'degraded';
  /** 版本 */
  version: string;
  /** 检查项 */
  checks: HealthCheckItem[];
  /** 时间戳 */
  timestamp: Date;
}

/**
 * 健康检查项
 */
export interface HealthCheckItem {
  /** 名称 */
  name: string;
  /** 状态 */
  status: 'pass' | 'fail' | 'warn';
  /** 响应时间 */
  responseTime: number;
  /** 消息 */
  message?: string;
}

// ============================================
// 基础设施类型 (V2.0)
// ============================================

/**
 * 去重结果
 */
export interface DeduplicationResult {
  /** 是否重复 */
  isDuplicate: boolean;
  /** 缓存的响应 */
  cachedResponse: RoutingDecision | null;
  /** 置信度 0-1 */
  confidence: number;
  /** 匹配类型 */
  matchType?: 'exact' | 'semantic' | 'none';
}

/**
 * 向量查询
 */
export interface VectorQuery {
  /** 查询文本 */
  text: string;
  /** 上下文信息 */
  context?: Record<string, any>;
  /** 查询ID */
  queryId?: string;
}

/**
 * 向量结果
 */
export interface VectorResult {
  /** 结果ID */
  id: string;
  /** 相似度分数 */
  score: number;
  /** 向量数据 */
  vector?: number[];
  /** 元数据 */
  metadata?: Record<string, any>;
}

/**
 * 路由决策
 */
export interface RoutingDecision {
  /** 提供商 */
  provider: string;
  /** 模型名称 */
  model: string;
  /** API密钥 */
  apiKey: string;
  /** 超时时间(毫秒) */
  timeout: number;
  /** 故障转移链 */
  fallbackChain: string[];
  /** 成本估算(美元/1M tokens) */
  costEstimate: number;
  /** 识别意图 */
  intent: string;
  /** 决策时间戳 */
  timestamp: number;
  /** 请求ID */
  requestId: string;
}

/**
 * 请求意图类型
 */
export type RequestIntent = 
  | 'code_generation'
  | 'code_review'
  | 'math_calculation'
  | 'search_query'
  | 'text_analysis'
  | 'architecture_design'
  | 'debugging'
  | 'documentation';

/**
 * 缓存统计
 */
export interface CacheStats {
  L1: number;
  L2: number;
  L3: number;
  total: number;
  hitRate: number;
}

// ============================================
// SmartRouter类型
// ============================================

/**
 * 路由请求
 */
export interface RouteRequest {
  /** 提示文本 */
  prompt: string;
  /** 首选角色 */
  preferredRole?: string;
  /** 模式 */
  mode?: 'fast' | 'think' | 'act' | 'search';
  /** 优先级 */
  priority?: 'cost' | 'quality' | 'speed' | 'balanced';
}

/**
 * 请求特征
 */
export interface RequestFeatures {
  /** 是否包含代码模式 */
  hasCodePattern: boolean;
  /** 是否包含数学模式 */
  hasMathPattern: boolean;
  /** 是否包含搜索模式 */
  hasSearchPattern: boolean;
  /** 文本长度 */
  length: number;
  /** 复杂度评分 */
  complexity: number;
}

/**
 * 模型配置
 */
export interface ModelConfig {
  /** 模型ID */
  id: string;
  /** 模型名称 */
  name: string;
  /** 提供商 */
  provider: string;
  /** 角色 */
  role: string;
  /** 每百万token成本 */
  costPerMillion: number;
  /** 平均延迟(ms) */
  avgLatency: number;
  /** 能力配置 */
  capabilities: {
    codeGeneration: number;
    mathReasoning: number;
    searchAugmented: number;
    longContext: number;
    contextWindow: number;
  };
  /** 是否可用 */
  available: boolean;
}

/**
 * 性能指标
 */
export interface PerformanceMetrics {
  /** 总请求数 */
  totalRequests: number;
  /** 缓存命中数 */
  cacheHits: number;
  /** 平均路由延迟 */
  avgRoutingLatency: number;
  /** 熔断器打开次数 */
  circuitOpenCount: number;
  /** 活跃请求数 */
  activeRequests: number;
}

/**
 * 路由事件
 */
export type RouterEvent = RoutingEvent;

/**
 * 去重缓存条目
 */
export interface DedupCacheEntry {
  /** 哈希值 */
  hash: string;
  /** 路由决策 */
  decision: RoutingDecision;
  /** 创建时间 */
  createdAt: number;
  /** 过期时间 */
  expiresAt: number;
}

// ============================================
// 扩展的路由器配置
// ============================================

/**
 * 扩展的路由器配置
 */
export interface ExtendedRouterConfig {
  /** API密钥列表 */
  keys: string[];
  /** 模型配置列表 */
  models: ModelConfig[];
  /** 熔断器配置 */
  circuitBreaker: CircuitBreakerConfig & {
    resetTimeoutMs?: number;
    successRateThreshold?: number;
    mlPrediction?: {
      enabled: boolean;
      predictionWindow: number;
      minDataPoints: number;
      confidenceThreshold: number;
    };
    adaptive?: {
      enabled: boolean;
      loadFactor: boolean;
      timeFactor: boolean;
      costFactor: boolean;
    };
  };
  /** 去重配置 */
  deduplication: {
    enabled: boolean;
    ttl: number;
    maxSize: number;
  };
  /** 默认超时时间 */
  defaultTimeout: number;
}

// ============================================
// 4AI工作流类型
// ============================================

/**
 * 4AI工作流配置
 */
export interface FourAIWorkflowConfig {
  /** Clarifier配置 */
  clarifier: AIModelConfig;
  /** Builder配置 */
  builder: AIModelConfig;
  /** Reviewer配置 */
  reviewer: AIModelConfig;
  /** Arbiter配置 */
  arbiter: AIModelConfig;
  /** 执行模式 */
  executionMode: 'parallel' | 'sequential' | 'hybrid';
  /** 超时配置 */
  timeout: TimeoutConfig;
}

/**
 * AI模型配置
 */
export interface AIModelConfig {
  /** 模型标识 */
  model: string;
  /** 温度 */
  temperature: number;
  /** 最大令牌数 */
  maxTokens: number;
  /** 优先级 */
  priority: number;
  /** 回退模型列表 */
  fallbacks: string[];
}

/**
 * 4AI工作流结果
 */
export interface FourAIWorkflowResult {
  /** Clarifier输出 */
  clarifierOutput: string;
  /** Builder输出 */
  builderOutput: string;
  /** Reviewer输出 */
  reviewerOutput: string;
  /** Arbiter输出 */
  arbiterOutput: string;
  /** 最终输出 */
  finalOutput: string;
  /** 元数据 */
  metadata: {
    totalDuration: number;
    totalTokens: number;
    confidenceScore: number;
  };
}
