# 🔐 安全提示 - API密钥已移除

**本包已移除所有API密钥，使用前必须手动配置！**

---

## ⚠️ 已清理的敏感信息

### 1. .env.example
- `FOURSAPI_KEYS` - 4个4SAPI密钥已替换为占位符

### 2. src/keypool/LockFreeKeyPool.ts
- 代码注释中的示例密钥已替换
- 默认key数组中的硬编码密钥已替换

---

## 📝 需要配置的文件

### 1. .env (从.env.example复制)
```bash
cp .env.example .env
nano .env
```

关键配置项：
```env
FOURSAPI_KEYS=sk-your-key-1,sk-your-key-2,sk-your-key-3,sk-your-key-4
API_KEY=your-internal-api-key
JWT_SECRET=your-jwt-secret
```

### 2. 代码中初始化 (可选)
如果使用代码初始化而非环境变量：
```typescript
const router = new SmartRouter({
  keys: [
    'sk-your-key-1',
    'sk-your-key-2',
    'sk-your-key-3',
    'sk-your-key-4'
  ]
});
```

---

## 🚀 快速开始

```bash
# 1. 安装依赖
npm install

# 2. 复制并编辑环境配置
cp .env.example .env
nano .env  # 填入你的API密钥

# 3. 编译
npm run build

# 4. 测试
npm test

# 5. 运行
npm start
```

---

**安全版本导出时间**: 2026-04-14  
**清理内容**: 4个4SAPI硬编码密钥
