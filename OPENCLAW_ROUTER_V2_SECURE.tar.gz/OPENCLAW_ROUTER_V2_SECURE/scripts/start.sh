#!/bin/bash
# ============================================
# OpenClaw Router V2.0 - 启动脚本
# ============================================

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 脚本路径
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 默认配置
ENV_FILE=".env"
MODE="standard"
WITH_MONITORING=false
BUILD=false

# 帮助信息
show_help() {
    echo -e "${BLUE}OpenClaw Router V2.0 - 启动脚本${NC}"
    echo ""
    echo "用法: ./start.sh [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help          显示帮助信息"
    echo "  -e, --env FILE      指定环境变量文件 (默认: .env)"
    echo "  -m, --mode MODE     启动模式: dev|standard|monitoring (默认: standard)"
    echo "  -b, --build         强制重新构建镜像"
    echo "  -d, --daemon        后台模式运行"
    echo ""
    echo "模式说明:"
    echo "  dev         - 开发模式 (包含热重载、调试端口)"
    echo "  standard    - 标准生产模式 (仅核心服务)"
    echo "  monitoring  - 包含监控栈 (Prometheus + Grafana)"
    echo ""
    echo "示例:"
    echo "  ./start.sh                          # 标准模式启动"
    echo "  ./start.sh -m monitoring            # 带监控启动"
    echo "  ./start.sh -e .env.prod -d          # 使用生产配置后台启动"
    echo "  ./start.sh -b                       # 强制重建镜像"
}

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -e|--env)
            ENV_FILE="$2"
            shift 2
            ;;
        -m|--mode)
            MODE="$2"
            shift 2
            ;;
        -b|--build)
            BUILD=true
            shift
            ;;
        -d|--daemon)
            DAEMON="-d"
            shift
            ;;
        *)
            echo -e "${RED}未知选项: $1${NC}"
            show_help
            exit 1
            ;;
    esac
done

# 进入项目目录
cd "$PROJECT_DIR"

echo -e "${BLUE}🚀 OpenClaw Router V2.0 - 启动服务${NC}"
echo "========================================"

# 检查环境文件
if [ ! -f "$ENV_FILE" ]; then
    if [ -f ".env.example" ]; then
        echo -e "${YELLOW}⚠️  环境文件 $ENV_FILE 不存在，从模板创建...${NC}"
        cp .env.example "$ENV_FILE"
        echo -e "${YELLOW}⚠️  请编辑 $ENV_FILE 设置必要的配置 (如API密钥)${NC}"
    else
        echo -e "${RED}❌ 错误: 环境文件 $ENV_FILE 不存在且找不到模板${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}✓ 使用环境文件: $ENV_FILE${NC}"

# 检查Docker和Docker Compose
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ 错误: Docker 未安装${NC}"
    exit 1
fi

if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo -e "${RED}❌ 错误: Docker Compose 未安装${NC}"
    exit 1
fi

# 确定docker compose命令
if docker compose version &> /dev/null; then
    COMPOSE_CMD="docker compose"
else
    COMPOSE_CMD="docker-compose"
fi

# 构建镜像
if [ "$BUILD" = true ]; then
    echo -e "${BLUE}🔨 强制重新构建镜像...${NC}"
    $COMPOSE_CMD -f docker-compose.yml --env-file "$ENV_FILE" build --no-cache
fi

# 根据模式启动
case $MODE in
    dev)
        echo -e "${BLUE}🛠️  启动开发模式...${NC}"
        export COMPOSE_PROFILES=dev
        $COMPOSE_CMD -f docker-compose.yml --env-file "$ENV_FILE" up ${DAEMON} --build
        ;;
    standard)
        echo -e "${BLUE}📦 启动标准模式...${NC}"
        $COMPOSE_CMD -f docker-compose.yml --env-file "$ENV_FILE" up ${DAEMON}
        ;;
    monitoring)
        echo -e "${BLUE}📊 启动监控模式 (包含Prometheus + Grafana)...${NC}"
        export COMPOSE_PROFILES=monitoring
        $COMPOSE_CMD -f docker-compose.yml --env-file "$ENV_FILE" up ${DAEMON}
        ;;
    *)
        echo -e "${RED}❌ 错误: 未知模式 '$MODE'${NC}"
        show_help
        exit 1
        ;;
esac

# 检查启动结果
if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ 服务启动成功!${NC}"
    echo "========================================"
    echo -e "${BLUE}服务地址:${NC}"
    echo "  API服务:       http://localhost:8080"
    echo "  WebSocket:     ws://localhost:8081"
    echo "  健康检查:      http://localhost:8080/health"
    echo "  指标端点:      http://localhost:9090/metrics"
    
    if [ "$MODE" = "monitoring" ]; then
        echo ""
        echo -e "${BLUE}监控面板:${NC}"
        echo "  Prometheus:    http://localhost:9091"
        echo "  Grafana:       http://localhost:3000 (admin/admin)"
    fi
    
    echo ""
    echo -e "${YELLOW}常用命令:${NC}"
    echo "  查看日志:      $COMPOSE_CMD logs -f"
    echo "  停止服务:      $COMPOSE_CMD down"
    echo "  重启服务:      $COMPOSE_CMD restart"
    echo ""
    echo -e "${GREEN}日志输出中... (按 Ctrl+C 退出日志查看, 服务会继续在后台运行)${NC}"
    
    if [ -z "$DAEMON" ]; then
        echo ""
    fi
else
    echo -e "${RED}❌ 服务启动失败${NC}"
    exit 1
fi
