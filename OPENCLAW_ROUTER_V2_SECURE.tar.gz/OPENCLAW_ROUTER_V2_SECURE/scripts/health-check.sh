#!/bin/bash
# ============================================
# OpenClaw Router V2.0 - 健康检查脚本
# ============================================

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 默认配置
API_URL="http://localhost:8080"
TIMEOUT=10
VERBOSE=false

# 帮助信息
show_help() {
    echo -e "${BLUE}OpenClaw Router V2.0 - 健康检查脚本${NC}"
    echo ""
    echo "用法: ./health-check.sh [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help       显示帮助信息"
    echo "  -u, --url URL    指定API地址 (默认: http://localhost:8080)"
    echo "  -t, --timeout N  超时时间(秒) (默认: 10)"
    echo "  -v, --verbose    详细输出"
    echo ""
    echo "示例:"
    echo "  ./health-check.sh              # 基础健康检查"
    echo "  ./health-check.sh -v           # 详细检查"
    echo "  ./health-check.sh -u http://192.168.1.100:8080"
}

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -u|--url)
            API_URL="$2"
            shift 2
            ;;
        -t|--timeout)
            TIMEOUT="$2"
            shift 2
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        *)
            echo -e "${RED}未知选项: $1${NC}"
            show_help
            exit 1
            ;;
    esac
done

# 检查依赖
if ! command -v curl &> /dev/null; then
    echo -e "${RED}❌ 错误: curl 未安装${NC}"
    exit 1
fi

echo -e "${BLUE}🏥 OpenClaw Router V2.0 - 健康检查${NC}"
echo "========================================"
echo -e "API地址: ${API_URL}"
echo ""

# 检查函数
check_endpoint() {
    local endpoint=$1
    local name=$2
    local expected_code=${3:-200}
    
    local url="${API_URL}${endpoint}"
    local response
    local http_code
    
    response=$(curl -s -o /dev/null -w "%{http_code}|%{time_total}" --max-time "$TIMEOUT" "$url" 2>&1)
    http_code=$(echo "$response" | cut -d'|' -f1)
    response_time=$(echo "$response" | cut -d'|' -f2)
    
    if [ "$http_code" = "$expected_code" ]; then
        echo -e "${GREEN}✓${NC} $name - HTTP $http_code (${response_time}s)"
        return 0
    else
        echo -e "${RED}✗${NC} $name - HTTP $http_code (期望: $expected_code)"
        return 1
    fi
}

# 执行检查
check_status() {
    local total=0
    local passed=0
    
    # 基础健康检查
    total=$((total + 1))
    if check_endpoint "/health" "健康检查"; then
        passed=$((passed + 1))
    fi
    
    # 就绪检查
    total=$((total + 1))
    if check_endpoint "/ready" "就绪检查"; then
        passed=$((passed + 1))
    fi
    
    # 指标端点
    total=$((total + 1))
    if check_endpoint "/metrics" "指标端点"; then
        passed=$((passed + 1))
    fi
    
    # API状态 (详细模式)
    if [ "$VERBOSE" = true ]; then
        total=$((total + 1))
        echo ""
        echo -e "${BLUE}详细信息:${NC}"
        
        local status_response
        status_response=$(curl -s --max-time "$TIMEOUT" "${API_URL}/health" 2>&1)
        
        if [ -n "$status_response" ]; then
            echo "$status_response" | python3 -m json.tool 2>&1 || echo "$status_response"
            passed=$((passed + 1))
        else
            echo -e "${RED}无法获取详细状态${NC}"
        fi
        
        # 检查Docker容器状态
        echo ""
        echo -e "${BLUE}容器状态:${NC}"
        
        if command -v docker-compose &> /dev/null || docker compose version &> /dev/null; then
            if docker compose version &> /dev/null; then
                docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Health}}" 2>&1 | grep -E "openclaw|NAME" || echo "未找到相关容器"
            else
                docker-compose ps 2>&1 | grep -E "openclaw|Name" || echo "未找到相关容器"
            fi
        fi
    fi
    
    echo ""
    echo "========================================"
    
    if [ $passed -eq $total ]; then
        echo -e "${GREEN}✅ 所有检查通过 ($passed/$total)${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠️  部分检查未通过 ($passed/$total)${NC}"
        return 1
    fi
}

# 运行检查
if check_status; then
    exit 0
else
    exit 1
fi
