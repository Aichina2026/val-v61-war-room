#!/bin/bash
# ============================================
# OpenClaw Router V2.0 - 停止脚本
# ============================================

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 脚本路径
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 默认配置
REMOVE_VOLUMES=false
REMOVE_IMAGES=false

# 帮助信息
show_help() {
    echo -e "${BLUE}OpenClaw Router V2.0 - 停止脚本${NC}"
    echo ""
    echo "用法: ./stop.sh [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help       显示帮助信息"
    echo "  -v, --volumes    同时删除数据卷 (⚠️ 数据将丢失)"
    echo "  -i, --images     同时删除镜像"
    echo "  -a, --all        删除卷和镜像 (等同于 -v -i)"
    echo ""
    echo "示例:"
    echo "  ./stop.sh              # 正常停止服务"
    echo "  ./stop.sh -v           # 停止并删除数据卷"
    echo "  ./stop.sh -a           # 完全清理"
}

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -v|--volumes)
            REMOVE_VOLUMES=true
            shift
            ;;
        -i|--images)
            REMOVE_IMAGES=true
            shift
            ;;
        -a|--all)
            REMOVE_VOLUMES=true
            REMOVE_IMAGES=true
            shift
            ;;
        *)
            echo -e "${RED}未知选项: $1${NC}"
            show_help
            exit 1
            ;;
    esac
done

# 进入项目目录
cd "$PROJECT_DIR"

echo -e "${BLUE}🛑 OpenClaw Router V2.0 - 停止服务${NC}"
echo "========================================"

# 确定docker compose命令
if docker compose version &> /dev/null; then
    COMPOSE_CMD="docker compose"
else
    COMPOSE_CMD="docker-compose"
fi

# 检查是否有运行的容器
RUNNING_CONTAINERS=$($COMPOSE_CMD ps -q 2>/dev/null || true)

if [ -z "$RUNNING_CONTAINERS" ]; then
    echo -e "${YELLOW}⚠️  没有正在运行的服务${NC}"
else
    echo -e "${BLUE}正在停止服务...${NC}"
    
    # 构建停止选项
    STOP_OPTS=""
    if [ "$REMOVE_VOLUMES" = true ]; then
        STOP_OPTS="$STOP_OPTS -v"
        echo -e "${YELLOW}⚠️  将删除数据卷${NC}"
    fi
    
    $COMPOSE_CMD down $STOP_OPTS
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ 服务已停止${NC}"
    else
        echo -e "${RED}✗ 停止服务时出错${NC}"
        exit 1
    fi
fi

# 删除镜像
if [ "$REMOVE_IMAGES" = true ]; then
    echo -e "${BLUE}正在删除镜像...${NC}"
    
    # 删除项目相关镜像
    docker images --filter "reference=openclaw-router-v2*" --format "{{.ID}}" | while read -r image_id; do
        if [ -n "$image_id" ]; then
            docker rmi "$image_id" 2>/dev/null || true
        fi
    done
    
    echo -e "${GREEN}✓ 镜像已删除${NC}"
fi

# 清理悬空资源
echo -e "${BLUE}清理悬空资源...${NC}"
docker system prune -f >/dev/null 2>&1 || true

echo ""
echo -e "${GREEN}✅ 清理完成${NC}"

# 显示状态
if [ "$REMOVE_VOLUMES" = true ]; then
    echo ""
    echo -e "${YELLOW}注意: 数据卷已删除，下次启动时将重新创建${NC}"
fi
