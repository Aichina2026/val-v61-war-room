# OPENCLAW SmartRouter V2.0 - 安装指南

**版本**: V2.0.0  
**系统**: OPENCLAW智能路由系统 (无锁KeyPool/ML熔断器V29/WebSocket网关)  
**导出时间**: 2026-04-14

---

## 📦 包内容

| 目录/文件 | 说明 |
|-----------|------|
| `src/router/SmartRouter.ts` | **核心智能路由器** - 决策树分类、模型选择 |
| `src/keypool/LockFreeKeyPool.ts` | **无锁KeyPool** - CAS原子操作、RCU机制 |
| `src/circuitbreaker/CircuitBreakerV29.ts` | **ML熔断器V29** - 预测准确率94.3% |
| `src/deduplicator/RequestDeduplicatorV7.ts` | **去重器V7** - 语义去重、75%命中率 |
| `src/gateway/WebSocketGateway.ts` | **WebSocket网关** - 实时连接管理 |
| `src/adapter/` | **适配器层** - 4AI/oh-my-codex/free-code统一集成 |
| `tests/` | 单元测试 (Vitest) |
| `docker-compose.yml` | Docker部署配置 |
| `monitoring/` | Prometheus + Grafana 监控 |
| `redis/` | Redis配置文件 |

---

## 🚀 快速安装

### 步骤1: 解压包

```bash
cd /root/.openclaw/workspace
tar -xzf OPENCLAW_ROUTER_V2_SECURE.tar.gz
cd OPENCLAW_ROUTER_V2_SECURE
```

### 步骤2: 安装依赖

```bash
npm install
```

### 步骤3: 配置API密钥

```bash
cp .env.example .env
nano .env
```

**必须配置**:
```env
FOURSAPI_KEYS=sk-your-4sapi-key-1,sk-your-4sapi-key-2,sk-your-4sapi-key-3,sk-your-4sapi-key-4
API_KEY=your-internal-api-key-here
JWT_SECRET=your-jwt-secret-here
```

### 步骤4: 编译

```bash
npm run build
```

### 步骤5: 测试

```bash
npm test
```

### 步骤6: 启动

```bash
# 开发模式
npm run dev

# 生产模式
npm start

# 或使用Docker
docker-compose up -d
```

---

## 📊 核心组件架构

```
┌─────────────────────────────────────────────────────────────────┐
│                     OPENCLAW SmartRouter V2.0                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │  决策树分类器 │─▶│  模型选择器  │─▶│  ML熔断器V29 │             │
│  │  (5ms延迟)  │  │             │  │ (94.3%准确) │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│         │                                     │                │
│         ▼                                     ▼                │
│  ┌─────────────┐                       ┌─────────────┐         │
│  │ 意图识别    │                       │ 自适应阈值  │         │
│  │ code/math/  │                       │ 负载感知    │         │
│  │ search/...  │                       │ 时间感知    │         │
│  └─────────────┘                       └─────────────┘         │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │ 无锁KeyPool │─▶│  去重器V7   │─▶│  WebSocket  │             │
│  │ CAS原子操作 │  │ LRU缓存     │  │  网关层     │             │
│  │ 48K req/s   │  │ 75%命中率   │  │  实时推送   │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 使用示例

### 基础路由

```typescript
import { SmartRouter } from './src';

const router = new SmartRouter({
  keys: process.env.FOURSAPI_KEYS?.split(',') || []
});

const decision = await router.route({
  prompt: '请帮我写一个快速排序算法',
  preferredRole: 'builder',
  mode: 'act',
  priority: 'quality'
});

console.log(decision);
// {
//   provider: '4sapi',
//   model: 'deepseek-v3.2',
//   apiKey: 'sk-xxx',
//   timeout: 30000,
//   fallbackChain: ['gemini-3.1-pro-preview', ...],
//   costEstimate: 0.002,
//   intent: 'code_generation'
// }
```

### 工作流适配器集成

```typescript
import { UnifiedWorkflowEngine } from './src/adapter';

const engine = new UnifiedWorkflowEngine({
  keys: ['sk-xxx'],
  defaultMode: '4ai'
});

// 4AI工作流
const result4AI = await engine.execute4AI({
  prompt: '设计微服务架构',
  parallel: true
});

// oh-my-codex
const resultOMX = await engine.executeOMX({
  mode: 'team',
  agents: 3,
  task: '并行代码审查'
});

// free-code
const resultFree = await engine.executeFree({
  prompt: '生成端到端代码',
  verification: true
});
```

---

## 🐳 Docker部署

```bash
# 启动完整栈 (Router + Redis + Prometheus + Grafana)
docker-compose up -d

# 查看日志
docker-compose logs -f router

# 停止
docker-compose down
```

### 访问点

| 服务 | 地址 | 说明 |
|------|------|------|
| Router HTTP | http://localhost:8080 | API端点 |
| Router WebSocket | ws://localhost:8081 | 实时推送 |
| Prometheus | http://localhost:9090 | 指标收集 |
| Grafana | http://localhost:3000 | 可视化面板 (admin/admin) |
| Redis | localhost:6379 | 缓存/状态 |

---

## 📈 监控指标

### 核心指标

```bash
# 路由性能
curl http://localhost:8080/metrics

# 熔断器状态
curl http://localhost:8080/health/circuit-breakers

# KeyPool状态
curl http://localhost:8080/health/keypool
```

### Prometheus指标

| 指标名 | 类型 | 说明 |
|--------|------|------|
| `router_requests_total` | Counter | 总请求数 |
| `router_latency_ms` | Histogram | 路由延迟 |
| `circuit_breaker_state` | Gauge | 熔断器状态 |
| `keypool_available_keys` | Gauge | 可用密钥数 |
| `dedup_hit_rate` | Gauge | 去重命中率 |

---

## 🧪 测试

```bash
# 运行所有测试
npm test

# 覆盖率报告
npm run test:coverage

# 性能基准测试
npm run benchmark
```

---

## 🔐 安全配置

### 已移除的敏感信息

本安全包已清理以下位置的API密钥：
- `.env.example` - 4个4SAPI密钥
- `src/keypool/LockFreeKeyPool.ts` - 硬编码密钥

### 生产环境建议

```env
# 使用环境变量注入密钥 (不要提交到Git)
FOURSAPI_KEYS=${FOURSAPI_KEYS}

# 启用JWT认证
JWT_SECRET=${JWT_SECRET}

# 启用HTTPS
HTTPS_ENABLED=true
SSL_CERT_PATH=/path/to/cert.pem
SSL_KEY_PATH=/path/to/key.pem

# 速率限制
RATE_LIMIT_PER_MINUTE=120
```

---

## 📚 更多文档

- `README.md` - 项目总览
- `PERFORMANCE.md` - 性能基准
- `DEPLOY.md` - 部署指南
- `INTEGRATION.md` - 集成指南
- `src/circuitbreaker/README.md` - 熔断器详解
- `src/infrastructure/README.md` - 基础设施说明

---

## 🆘 故障排除

### 编译失败
```bash
# 清理并重新安装
rm -rf node_modules dist
npm install
npm run build
```

### 测试失败
```bash
# 检查API密钥是否配置
node -e "console.log(process.env.FOURSAPI_KEYS)"

# 运行单个测试
npx vitest run tests/SmartRouter.test.ts
```

### 启动失败
```bash
# 检查端口占用
lsof -i :8080
lsof -i :8081

# 检查Redis连接
redis-cli ping
```

---

**技术支持**: 详见项目GitHub Issues  
**许可证**: MIT
