# OpenClaw智能路由系统V2.0 - 适配器集成文档

**版本**: V2.0.0  
**日期**: 2026-04-13  
**状态**: 生产就绪  

---

## 目录

1. [概述](#概述)
2. [架构设计](#架构设计)
3. [适配器模块](#适配器模块)
4. [集成指南](#集成指南)
5. [配置说明](#配置说明)
6. [使用示例](#使用示例)
7. [API参考](#api参考)
8. [故障排除](#故障排除)

---

## 概述

OpenClaw智能路由系统V2.0适配器层提供了统一的接口，将4AI工作流、oh-my-codex和free-code三大工作流整合到智能路由系统中。

### 核心特性

- **4AI工作流适配**: Clarifier/Builder/Reviewer/Arbiter角色完整映射
- **oh-my-codex适配**: $team/$ri/$ralph模式到4AI的完整转换
- **free-code适配**: MCP协议桥接，端到端代码工作流
- **统一工作流引擎**: 智能工作流选择、队列管理、状态追踪
- **生产级特性**: 熔断器保护、去重缓存、并发控制

---

## 架构设计

### 整体架构

```
┌─────────────────────────────────────────────────────────────────┐
│                    UnifiedWorkflowEngine                         │
│                    统一工作流引擎                                 │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   4AI工作流   │  │ oh-my-codex │  │  free-code   │          │
│  │   适配器      │  │   适配器     │  │   适配器      │          │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘          │
└─────────┼────────────────┼────────────────┼──────────────────┘
          │                │                │
          ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      SmartRouter V2.0                            │
│                   智能路由核心引擎                                │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐        │
│  │LockFree  │  │Circuit   │  │Request   │  │Decision  │        │
│  │KeyPool   │  │BreakerV29│  │DedupV7   │  │Tree      │        │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘        │
└─────────────────────────────────────────────────────────────────┘
```

### 适配器映射关系

#### 4AI工作流映射

| 角色 | 模型 | 能力 | 主要职责 |
|------|------|------|----------|
| Clarifier | Gemini 3.1 Pro Preview | 需求分析、数学推理 | 需求澄清、问题分解 |
| Builder | DeepSeek V3.2 | 代码生成、高频构建 | 方案设计、代码实现 |
| Reviewer | Claude Opus 4.6 | 深度审查、安全验证 | 质量检查、风险评估 |
| Arbiter | GPT-5.4 | 编排决策、系统整合 | 最终裁决、结果聚合 |

#### oh-my-codex模式映射

| oh-my-codex | 4AI映射 | 执行模式 | 适用场景 |
|-------------|---------|----------|----------|
| $team | 4AI并行审查 | team模式 | 代码审查、同行评审 |
| $ri | 4AI持久执行循环 | ri模式 | 迭代优化、质量提升 |
| $ralph | 4AI架构师验证 | ralph模式 | 架构设计、系统评估 |

#### free-code集成

| free-code任务 | 工作流选择 | 输出类型 |
|---------------|------------|----------|
| generate | 4AI Builder主导 | 代码文件 |
| modify | 4AI并行 | 修改补丁 |
| review | oh-my-codex $team | 审查报告 |
| test | MCP工具链 | 测试结果 |
| debug | oh-my-codex $ri | 修复方案 |
| refactor | oh-my-codex $ralph | 重构架构 |
| document | 4AI Clarifier | 文档内容 |

---

## 适配器模块

### 1. 4AIWorkflowAdapter

**文件**: `src/adapter/4AIWorkflowAdapter.ts`

4AI原生工作流适配器，支持完整的4角色工作流。

#### 核心功能

- **并行执行**: 4角色同时执行，最大化效率
- **顺序执行**: Clarifier → Builder → Reviewer → Arbiter
- **混合执行**: Clarifier+Builder并行 → Reviewer → Arbiter
- **结果聚合**: best/merge/voting/hierarchical策略
- **熔断器保护**: 每个角色独立熔断器
- **去重缓存**: 自动去重相同请求

#### 配置选项

```typescript
interface WorkflowExecutionConfig {
  mode: 'parallel' | 'sequential' | 'hybrid';
  timeout: number;
  enableArbiter: boolean;
  retryFailed: boolean;
  maxRetries: number;
  aggregationStrategy: 'best' | 'merge' | 'voting' | 'hierarchical';
}
```

### 2. OhMyCodexAdapter

**文件**: `src/adapter/OhMyCodexAdapter.ts`

oh-my-codex工作流适配器，将$team/$ri/$ralph模式映射到4AI角色。

#### $team模式 → 4AI并行审查

```typescript
// 执行流程
Clarifier分析需求
    ↓
Builder并行开发
    ↓
Reviewer[1..n]并行审查（可配置审查员数量）
    ↓
Arbiter最终裁决
```

#### $ri模式 → 4AI持久执行循环

```typescript
// 迭代流程
for iteration in 1..maxIterations:
    Clarifier初始分析（仅第1轮）
        ↓
    Builder生成/改进
        ↓
    Reviewer质量评估
        ↓
    Arbiter收敛判断
        ↓
    if 已收敛: break
```

#### $ralph模式 → 4AI架构师验证

```typescript
// 验证流程
Clarifier架构需求分析
    ↓
Builder架构设计
    ↓
Reviewer多维审查（安全/性能/可扩展/可维护）
    ↓
Arbiter架构决策
```

### 3. FreeCodeAdapter

**文件**: `src/adapter/FreeCodeAdapter.ts`

free-code项目适配器，提供MCP协议桥接和端到端代码工作流。

#### MCP工具集

| 工具名 | 功能 | 参数 |
|--------|------|------|
| read_file | 读取文件 | path: string |
| write_file | 写入文件 | path: string, content: string |
| list_directory | 列出目录 | path: string |
| execute_command | 执行命令 | command: string, cwd?: string |
| search_code | 代码搜索 | pattern: string, path: string |

#### 任务类型

- **generate**: 代码生成（使用4AI）
- **modify**: 代码修改（使用4AI并行）
- **review**: 代码审查（使用oh-my-codex $team）
- **test**: 测试执行（使用MCP工具）
- **debug**: 调试修复（使用oh-my-codex $ri）
- **refactor**: 架构重构（使用oh-my-codex $ralph）
- **document**: 文档生成（使用4AI Clarifier）

### 4. UnifiedWorkflowEngine

**文件**: `src/adapter/UnifiedWorkflowEngine.ts`

统一工作流引擎，提供智能工作流选择和队列管理。

#### 核心特性

- **智能选择**: 基于提示词内容自动选择最优工作流
- **优先级队列**: 支持高优先级任务插队
- **并发控制**: 可配置的最大并发数
- **批量执行**: 支持批量任务执行
- **状态管理**: 完整的生命周期管理
- **超时控制**: 支持任务超时

#### 工作流选择策略

```typescript
// 自动选择逻辑
if (prompt包含free-code关键词):
    return 'free-code'
if (prompt包含oh-my-codex关键词):
    return 'oh-my-codex'
if (config指定了freeCode):
    return 'free-code'
if (config指定了ohMyCodex):
    return 'oh-my-codex'
return '4ai'  // 默认
```

---

## 集成指南

### 基础集成

```typescript
import { 
  UnifiedWorkflowEngine,
  FourAIWorkflowAdapter,
  OhMyCodexAdapter,
  FreeCodeAdapter 
} from './src/adapter';

// 1. 使用统一引擎（推荐）
const engine = new UnifiedWorkflowEngine({
  maxConcurrent: 5,
  defaultTimeout: 120000
});

// 2. 执行工作流
const result = await engine.execute({
  prompt: '设计一个高性能的API网关',
  type: 'auto',  // 自动选择工作流
  priority: 1
});

console.log(result.content);
console.log(result.metadata);
```

### 高级集成

```typescript
// 1. 直接创建适配器实例
const fourAI = new FourAIWorkflowAdapter({
  mode: 'parallel',
  enableArbiter: true,
  aggregationStrategy: 'hierarchical'
});

// 2. 执行4AI工作流
const result = await fourAI.executeWorkflow(
  '分析以下系统架构并给出优化建议',
  { systemContext: '微服务架构' }
);

// 3. 创建oh-my-codex适配器
const ohMyCodex = new OhMyCodexAdapter({
  mode: 'team',
  teamSize: 3,
  confidenceThreshold: 0.9
});

// 4. 执行team模式
const teamResult = await ohMyCodex.execute({
  prompt: '审查这段代码的质量',
  mode: 'team'
});

// 5. 创建free-code适配器
const freeCode = new FreeCodeAdapter();

// 6. 执行代码生成任务
const codeResult = await freeCode.execute({
  task: 'generate',
  project: {
    name: 'my-api',
    path: './my-api',
    language: 'typescript'
  },
  requirements: '创建一个RESTful API服务，支持用户CRUD操作'
});
```

### 事件监听

```typescript
// 监听工作流事件
engine.on('workflow-start', (event) => {
  console.log(`工作流开始: ${event.workflowId}`);
});

engine.on('workflow-complete', (event) => {
  console.log(`工作流完成: ${event.workflowId}`);
  console.log(`耗时: ${event.result.metadata.duration}ms`);
  console.log(`置信度: ${event.result.metadata.confidence}`);
});

engine.on('workflow-error', (event) => {
  console.error(`工作流错误: ${event.workflowId}`, event.error);
});

// 取消工作流
const cancelled = engine.cancel(workflowId);
```

---

## 配置说明

### 4SAPI配置

```typescript
// 角色模型配置
const roleModels = {
  clarifier: 'gemini-3.1-pro-preview-04-05',
  builder: 'deepseek-v3.2-0324',
  reviewer: 'claude-opus-4.6-04-05',
  arbiter: 'gpt-5.4-04-08'
};

// API密钥池（轮询使用）
const fourSapiKeys = [
  'sk-bbufOP32qhZ2gXNvuZyUdvhWPtheQBhthvMIQxTeuQmjCTQl',
  'sk-KNDw0lmVt1a7Q98MUlD1aH4TUZgdqx0tTjfrfhZODS6hL9Se',
  'sk-ZR8zAmgxyIIM8qFB76J23HPI1LixgRnkx6iYphBcKYsgLozP',
  'sk-wO2l0uybCG6DTUZ9iLMo0lOAmIEtMUPuPwSpDsculMcCr4vX'
];
```

### 熔断器配置

```typescript
const circuitBreakerConfig = {
  failureThreshold: 3,
  resetTimeoutMs: 20000,
  halfOpenMaxCalls: 5,
  successRateThreshold: 0.92,
  mlPrediction: {
    enabled: true,
    predictionWindow: 60,
    minDataPoints: 20,
    confidenceThreshold: 0.85
  }
};
```

### 去重配置

```typescript
const dedupConfig = {
  enabled: true,
  ttl: 300000,      // 5分钟
  maxSize: 1000,    // 最大缓存数
  similarityThreshold: 0.85  // 语义相似度阈值
};
```

---

## 使用示例

### 示例1: 代码生成

```typescript
const result = await engine.execute({
  prompt: '$free-code 生成一个Express.js的REST API，包含用户认证',
  config: {
    freeCode: {
      task: 'generate',
      project: {
        name: 'auth-api',
        path: './auth-api',
        language: 'javascript',
        framework: 'express'
      }
    }
  }
});

// 结果包含生成的文件
result.rawResult.files.forEach(file => {
  console.log(`File: ${file.path}`);
  console.log(file.content);
});
```

### 示例2: 代码审查

```typescript
const result = await engine.execute({
  prompt: '$team 审查src/auth/index.js中的代码质量问题',
  config: {
    ohMyCodex: {
      mode: 'team',
      teamSize: 3
    },
    freeCode: {
      task: 'review',
      project: {
        name: 'auth-api',
        path: './auth-api',
        language: 'javascript'
      }
    }
  }
});

// 结果包含审查报告
console.log('总体评分:', result.rawResult.consensusScore);
result.rawResult.peerReviews.forEach(review => {
  console.log(`Reviewer: ${review.reviewer}`);
  console.log(`Score: ${review.score}`);
  console.log(`Feedback: ${review.feedback}`);
});
```

### 示例3: 架构设计

```typescript
const result = await engine.execute({
  prompt: '$ralph 设计一个可扩展的微服务架构，支持100万用户',
  config: {
    ohMyCodex: {
      mode: 'ralph'
    }
  }
});

// 结果包含架构设计和验证报告
console.log(result.rawResult.architecture);
console.log('验证通过:', result.rawResult.validationReport.passed);
console.log('风险等级:', result.rawResult.riskAssessment.level);
```

### 示例4: 迭代优化

```typescript
const result = await engine.execute({
  prompt: '$ri 优化这段代码的性能，目标提升50%',
  config: {
    ohMyCodex: {
      mode: 'ri',
      maxIterations: 5
    }
  }
});

// 结果包含迭代历史
result.rawResult.iterations.forEach(iter => {
  console.log(`Iteration ${iter.iteration}:`);
  console.log(`Quality Score: ${iter.qualityScore}`);
  console.log(`Improvements: ${iter.improvements.join(', ')}`);
});
```

---

## API参考

### UnifiedWorkflowEngine

#### 构造函数

```typescript
constructor(options?: {
  maxConcurrent?: number;    // 默认: 5
  defaultTimeout?: number;   // 默认: 300000 (5分钟)
})
```

#### 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| execute | UnifiedWorkflowRequest | Promise<UnifiedWorkflowResult> | 执行工作流 |
| executeBatch | UnifiedWorkflowRequest[], options? | Promise<UnifiedWorkflowResult[]> | 批量执行 |
| cancel | workflowId: string | boolean | 取消工作流 |
| pause | workflowId: string | boolean | 暂停工作流 |
| resume | workflowId: string | boolean | 恢复工作流 |
| getWorkflowStatus | workflowId: string | WorkflowStatus \| null | 获取状态 |
| getWorkflowResult | workflowId: string | UnifiedWorkflowResult \| null | 获取结果 |
| getStats | - | WorkflowStats | 获取统计 |
| clearQueue | - | number | 清空队列 |
| shutdown | - | void | 关闭引擎 |

### FourAIWorkflowAdapter

#### 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| executeWorkflow | prompt: string, context? | Promise<FourAIWorkflowResult> | 执行工作流 |
| getConfig | - | WorkflowExecutionConfig | 获取配置 |
| updateConfig | config: Partial<WorkflowExecutionConfig> | void | 更新配置 |
| shutdown | - | void | 关闭适配器 |

### OhMyCodexAdapter

#### 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| execute | OhMyCodexRequest | Promise<TeamModeResult \| RiModeResult \| RalphModeResult> | 执行工作流 |
| getExecutionHistory | executionId? | any | 获取历史 |
| shutdown | - | void | 关闭适配器 |

### FreeCodeAdapter

#### 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| execute | FreeCodeRequest | Promise<FreeCodeResult> | 执行任务 |
| getMCPTool | name: string | MCPTool \| undefined | 获取工具 |
| listMCPTools | - | string[] | 列出工具 |
| shutdown | - | void | 关闭适配器 |

---

## 故障排除

### 常见问题

#### 1. API密钥耗尽

**症状**: 所有请求失败，提示"No available API keys"

**解决**:
```typescript
// 检查KeyPool状态
const stats = router.getDedupStats();
console.log(stats);

// 重置熔断器
router.resetAllCircuitBreakers();
```

#### 2. 工作流超时

**症状**: 工作流长时间无响应

**解决**:
```typescript
// 增加超时时间
const engine = new UnifiedWorkflowEngine({
  defaultTimeout: 600000  // 10分钟
});

// 或者为单个请求设置超时
const result = await engine.execute({
  prompt: '...',
  timeout: 600000
});
```

#### 3. 去重命中率低

**症状**: 相同请求重复执行

**解决**:
```typescript
// 调整去重阈值
const fourAI = new FourAIWorkflowAdapter({
  // ...其他配置
});

// 确保请求规范化
const result = await fourAI.executeWorkflow(
  prompt.trim().toLowerCase(),  // 规范化输入
  context
);
```

#### 4. 工作流选择错误

**症状**: 自动选择的工作流不符合预期

**解决**:
```typescript
// 显式指定工作流类型
const result = await engine.execute({
  prompt: '...',
  type: 'oh-my-codex',  // 显式指定
  config: {
    ohMyCodex: {
      mode: 'team'  // 显式指定模式
    }
  }
});
```

### 调试技巧

```typescript
// 1. 启用详细日志
engine.on('workflow-start', (e) => console.log('[START]', e));
engine.on('workflow-complete', (e) => console.log('[COMPLETE]', e));
engine.on('workflow-error', (e) => console.log('[ERROR]', e));

// 2. 检查中间结果
const active = engine.activeWorkflows.get(workflowId);
console.log(active?.steps);

// 3. 性能分析
const stats = engine.getStats();
console.log(`平均耗时: ${stats.avgDuration}ms`);
console.log(`平均置信度: ${stats.avgConfidence}`);
```

### 性能优化

```typescript
// 1. 批量执行
const results = await engine.executeBatch(requests, {
  concurrency: 10,
  stopOnError: false
});

// 2. 合理设置并发
const engine = new UnifiedWorkflowEngine({
  maxConcurrent: 10  // 根据API限制调整
});

// 3. 使用缓存
const fourAI = new FourAIWorkflowAdapter({
  // 启用去重缓存
});
```

---

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 2.0.0 | 2026-04-13 | 初始版本，完整适配器实现 |

---

## 许可证

MIT License - OpenClaw Project
