from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import JSONResponse, Response
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Literal
from contextlib import asynccontextmanager
import os
import time
import json
import uuid
import random
import asyncio
import logging
import hashlib

import httpx
import redis.asyncio as redis
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST


APP_NAME = os.getenv("APP_NAME", "AI Gateway API")
APP_VERSION = os.getenv("APP_VERSION", "1.2.0")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
JSON_LOGS = os.getenv("JSON_LOGS", "true").lower() == "true"

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip() or None
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_TEXT_MODEL = os.getenv("OPENAI_TEXT_MODEL", "gpt-5")
OPENAI_IMAGE_MODEL = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1")

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip() or None
ANTHROPIC_BASE_URL = os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com/v1")
ANTHROPIC_TEXT_MODEL = os.getenv("ANTHROPIC_TEXT_MODEL", "claude-sonnet-4-5")

INTERNAL_API_KEY = os.getenv("AI_GATEWAY_API_KEY", "").strip() or None
REQUIRE_API_KEY = os.getenv("REQUIRE_API_KEY", "true").lower() == "true"
API_KEY_HEADER_NAME = os.getenv("API_KEY_HEADER_NAME", "X-API-Key")

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
REDIS_REQUIRED = os.getenv("REDIS_REQUIRED", "false").lower() == "true"
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "300"))
RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", "120"))

HTTP_TIMEOUT_SECONDS = float(os.getenv("HTTP_TIMEOUT_SECONDS", "30"))
UPSTREAM_MAX_RETRIES = int(os.getenv("UPSTREAM_MAX_RETRIES", "3"))
UPSTREAM_BACKOFF_BASE_SECONDS = float(os.getenv("UPSTREAM_BACKOFF_BASE_SECONDS", "0.5"))
UPSTREAM_BACKOFF_MAX_SECONDS = float(os.getenv("UPSTREAM_BACKOFF_MAX_SECONDS", "4.0"))
CIRCUIT_BREAKER_FAILURE_THRESHOLD = int(os.getenv("CIRCUIT_BREAKER_FAILURE_THRESHOLD", "5"))
CIRCUIT_BREAKER_RECOVERY_SECONDS = int(os.getenv("CIRCUIT_BREAKER_RECOVERY_SECONDS", "60"))


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": self.formatTime(record, datefmt="%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key in ("request_id", "method", "path", "status_code", "duration_ms", "provider", "fallback_used"):
            value = getattr(record, key, None)
            if value is not None:
                payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload)


def configure_logging() -> logging.Logger:
    logger = logging.getLogger("ai-gateway-api")
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
    logger.handlers.clear()
    handler = logging.StreamHandler()
    if JSON_LOGS:
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    logger.addHandler(handler)
    logger.propagate = False
    return logger


logger = configure_logging()

REQUEST_COUNTER = Counter("ai_gateway_requests_total", "Total HTTP requests", ["method", "path", "status_code"])
REQUEST_LATENCY = Histogram("ai_gateway_request_duration_seconds", "HTTP request latency", ["method", "path"])
PROVIDER_REQUESTS = Counter("ai_gateway_provider_requests_total", "Upstream provider attempts", ["provider", "outcome"])
CACHE_EVENTS = Counter("ai_gateway_cache_events_total", "Cache events", ["event"])
CIRCUIT_STATE = Gauge("ai_gateway_circuit_open", "Circuit breaker state", ["provider"])
FALLBACK_EVENTS = Counter("ai_gateway_fallback_total", "Fallback events", ["from_provider", "to_provider", "capability"])


class NullStore:
    async def get_cache(self, key: str):
        return None

    async def set_cache(self, key: str, value: Any) -> None:
        return None

    async def allow_request(self, identity: str) -> bool:
        return True

    async def ping(self) -> bool:
        return False

    async def is_circuit_open(self, provider: str) -> bool:
        return False

    async def record_provider_success(self, provider: str) -> None:
        return None

    async def record_provider_failure(self, provider: str, threshold: int, recovery_seconds: int) -> None:
        return None


class RedisStore:
    def __init__(self, client: redis.Redis, ttl_seconds: int, rate_limit_per_minute: int):
        self.client = client
        self.ttl_seconds = ttl_seconds
        self.rate_limit_per_minute = rate_limit_per_minute

    async def get_cache(self, key: str) -> Optional[Any]:
        value = await self.client.get(key)
        if value is None:
            return None
        return json.loads(value)

    async def set_cache(self, key: str, value: Any) -> None:
        await self.client.set(key, json.dumps(value), ex=self.ttl_seconds)

    async def allow_request(self, identity: str) -> bool:
        current_minute = int(time.time() // 60)
        key = f"rate_limit:{identity}:{current_minute}"
        current = await self.client.incr(key)
        if current == 1:
            await self.client.expire(key, 61)
        return current <= self.rate_limit_per_minute

    async def ping(self) -> bool:
        try:
            return bool(await self.client.ping())
        except Exception:
            return False

    async def is_circuit_open(self, provider: str) -> bool:
        opened_until = await self.client.get(f"circuit:{provider}:open_until")
        if opened_until is None:
            CIRCUIT_STATE.labels(provider=provider).set(0)
            return False
        try:
            is_open = float(opened_until) > time.time()
            CIRCUIT_STATE.labels(provider=provider).set(1 if is_open else 0)
            return is_open
        except ValueError:
            return False

    async def record_provider_success(self, provider: str) -> None:
        pipe = self.client.pipeline()
        pipe.delete(f"circuit:{provider}:failures")
        pipe.delete(f"circuit:{provider}:open_until")
        await pipe.execute()
        CIRCUIT_STATE.labels(provider=provider).set(0)

    async def record_provider_failure(self, provider: str, threshold: int, recovery_seconds: int) -> None:
        failure_key = f"circuit:{provider}:failures"
        open_key = f"circuit:{provider}:open_until"
        failures = await self.client.incr(failure_key)
        if failures == 1:
            await self.client.expire(failure_key, recovery_seconds * 2)
        if failures >= threshold:
            await self.client.set(open_key, str(time.time() + recovery_seconds), ex=recovery_seconds)
            CIRCUIT_STATE.labels(provider=provider).set(1)


@asynccontextmanager
async def lifespan(app: FastAPI):
    timeout = httpx.Timeout(timeout=HTTP_TIMEOUT_SECONDS)
    transport = httpx.AsyncHTTPTransport(retries=0)
    http_client = httpx.AsyncClient(timeout=timeout, transport=transport)

    app.state.http_client = http_client
    app.state.store = NullStore()
    app.state.redis_client = None

    try:
        redis_client = redis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
        await redis_client.ping()
        app.state.redis_client = redis_client
        app.state.store = RedisStore(redis_client, CACHE_TTL_SECONDS, RATE_LIMIT_PER_MINUTE)
        logger.info("Redis connected")
    except Exception as exc:
        logger.exception("Redis connection failed: %s", exc)
        if REDIS_REQUIRED:
            await http_client.aclose()
            raise RuntimeError("Redis is required but unavailable") from exc

    try:
        yield
    finally:
        await http_client.aclose()
        if getattr(app.state, "redis_client", None) is not None:
            await app.state.redis_client.aclose()


app = FastAPI(title=APP_NAME, version=APP_VERSION, lifespan=lifespan, docs_url="/docs", redoc_url="/redoc")
api_key_header = APIKeyHeader(name=API_KEY_HEADER_NAME, auto_error=False)


class TextGenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=50000)
    system: Optional[str] = Field(default=None, max_length=10000)
    model: Optional[str] = None
    max_output_tokens: int = Field(default=512, ge=1, le=8192)
    temperature: float = Field(default=0.7, ge=0, le=2)
    preferred_provider: Literal["auto", "openai", "anthropic"] = "auto"
    cache: bool = True


class TextGenerateResponse(BaseModel):
    text: str
    provider: str
    model: str
    cached: bool
    request_id: str


class ImageGenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=10000)
    model: Optional[str] = None
    size: str = "1024x1024"
    n: int = Field(default=1, ge=1, le=4)
    quality: str = "standard"
    background: Optional[str] = None
    cache: bool = False


class ImageItem(BaseModel):
    b64_json: Optional[str] = None
    url: Optional[str] = None


class ImageGenerateResponse(BaseModel):
    provider: str
    model: str
    images: List[ImageItem]
    cached: bool
    request_id: str


class HealthResponse(BaseModel):
    status: str
    environment: str
    version: str
    providers: Dict[str, bool]


class ReadyResponse(BaseModel):
    ready: bool
    checks: Dict[str, bool]


def build_cache_key(prefix: str, payload: dict) -> str:
    serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return f"{prefix}:{hashlib.sha256(serialized.encode('utf-8')).hexdigest()}"


def _backoff_delay_seconds(attempt: int) -> float:
    exponential = UPSTREAM_BACKOFF_BASE_SECONDS * (2 ** (attempt - 1))
    jitter = random.uniform(0, min(0.25, exponential / 4))
    return min(UPSTREAM_BACKOFF_MAX_SECONDS, exponential + jitter)


def _is_retryable_status(code: int) -> bool:
    return code in {408, 425, 429, 500, 502, 503, 504}


async def get_http_client(request: Request) -> httpx.AsyncClient:
    return request.app.state.http_client


async def get_store(request: Request):
    return request.app.state.store


async def verify_api_key(api_key: Optional[str] = Depends(api_key_header)) -> Optional[str]:
    if not REQUIRE_API_KEY:
        return None
    if not INTERNAL_API_KEY:
        raise HTTPException(status_code=500, detail="Server API key configuration is invalid")
    if api_key != INTERNAL_API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
    return api_key


async def enforce_rate_limit(request: Request, store=Depends(get_store)) -> None:
    host = request.client.host if request.client else "unknown"
    forwarded_for = request.headers.get("x-forwarded-for")
    identity = forwarded_for.split(",")[0].strip() if forwarded_for else host
    if not await store.allow_request(identity):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")


async def _perform_json_request(
    client: httpx.AsyncClient,
    provider_name: str,
    method: str,
    url: str,
    headers: dict,
    json_body: Optional[dict] = None,
) -> dict:
    last_error: Optional[Exception] = None
    for attempt in range(1, UPSTREAM_MAX_RETRIES + 1):
        try:
            response = await client.request(method, url, headers=headers, json=json_body)
            if response.status_code >= 400:
                if _is_retryable_status(response.status_code) and attempt < UPSTREAM_MAX_RETRIES:
                    PROVIDER_REQUESTS.labels(provider=provider_name, outcome="retry").inc()
                    await asyncio.sleep(_backoff_delay_seconds(attempt))
                    continue
                PROVIDER_REQUESTS.labels(provider=provider_name, outcome="error_status").inc()
                raise HTTPException(status_code=response.status_code, detail=f"Upstream provider error from {provider_name}: {response.text[:300]}")
            PROVIDER_REQUESTS.labels(provider=provider_name, outcome="success").inc()
            return response.json()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError) as exc:
            last_error = exc
            if attempt >= UPSTREAM_MAX_RETRIES:
                PROVIDER_REQUESTS.labels(provider=provider_name, outcome="timeout_or_network_failure").inc()
                raise HTTPException(status_code=504, detail=f"Upstream timeout or network failure from {provider_name}") from exc
            PROVIDER_REQUESTS.labels(provider=provider_name, outcome="retry_exception").inc()
            await asyncio.sleep(_backoff_delay_seconds(attempt))
    raise HTTPException(status_code=502, detail=f"Failed to reach {provider_name}") from last_error


async def _run_with_circuit_breaker(store, provider_name: str, operation):
    if await store.is_circuit_open(provider_name):
        raise HTTPException(status_code=503, detail=f"Circuit open for provider {provider_name}")
    try:
        result = await operation()
        await store.record_provider_success(provider_name)
        return result
    except HTTPException as exc:
        if _is_retryable_status(exc.status_code):
            await store.record_provider_failure(provider_name, CIRCUIT_BREAKER_FAILURE_THRESHOLD, CIRCUIT_BREAKER_RECOVERY_SECONDS)
        raise
    except Exception:
        await store.record_provider_failure(provider_name, CIRCUIT_BREAKER_FAILURE_THRESHOLD, CIRCUIT_BREAKER_RECOVERY_SECONDS)
        raise


async def _openai_text(client: httpx.AsyncClient, payload: TextGenerateRequest) -> TextGenerateResponse:
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is not configured")
    req = {
        "model": payload.model or OPENAI_TEXT_MODEL,
        "input": payload.prompt,
        "max_output_tokens": payload.max_output_tokens,
        "temperature": payload.temperature,
    }
    if payload.system:
        req["instructions"] = payload.system
    data = await _perform_json_request(
        client,
        "openai",
        "POST",
        f"{OPENAI_BASE_URL}/responses",
        {"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
        req,
    )
    text = data.get("output_text", "")
    if not text:
        for item in data.get("output", []):
            if item.get("type") == "message":
                for content in item.get("content", []):
                    if content.get("type") == "output_text":
                        text += content.get("text", "")
    return TextGenerateResponse(text=text, provider="openai", model=req["model"], cached=False, request_id=str(uuid.uuid4()))


async def _anthropic_text(client: httpx.AsyncClient, payload: TextGenerateRequest) -> TextGenerateResponse:
    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY is not configured")
    req = {
        "model": payload.model or ANTHROPIC_TEXT_MODEL,
        "max_tokens": payload.max_output_tokens,
        "temperature": payload.temperature,
        "messages": [{"role": "user", "content": payload.prompt}],
    }
    if payload.system:
        req["system"] = payload.system
    data = await _perform_json_request(
        client,
        "anthropic",
        "POST",
        f"{ANTHROPIC_BASE_URL}/messages",
        {
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        },
        req,
    )
    text = "".join(part.get("text", "") for part in data.get("content", []) if part.get("type") == "text")
    return TextGenerateResponse(text=text, provider="anthropic", model=req["model"], cached=False, request_id=str(uuid.uuid4()))


async def _openai_image(client: httpx.AsyncClient, payload: ImageGenerateRequest) -> ImageGenerateResponse:
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is not configured")
    req = {
        "model": payload.model or OPENAI_IMAGE_MODEL,
        "prompt": payload.prompt,
        "size": payload.size,
        "n": payload.n,
        "quality": payload.quality,
    }
    if payload.background:
        req["background"] = payload.background
    data = await _perform_json_request(
        client,
        "openai-image",
        "POST",
        f"{OPENAI_BASE_URL}/images/generations",
        {"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
        req,
    )
    images = [ImageItem(b64_json=item.get("b64_json"), url=item.get("url")) for item in data.get("data", [])]
    return ImageGenerateResponse(provider="openai", model=req["model"], images=images, cached=False, request_id=str(uuid.uuid4()))


async def _generate_text_with_fallback(client: httpx.AsyncClient, store, payload: TextGenerateRequest) -> TextGenerateResponse:
    if payload.preferred_provider == "anthropic":
        providers = [("anthropic", lambda: _anthropic_text(client, payload)), ("openai", lambda: _openai_text(client, payload))]
    else:
        providers = [("openai", lambda: _openai_text(client, payload)), ("anthropic", lambda: _anthropic_text(client, payload))]

    first_error: Optional[HTTPException] = None
    for i, (name, op) in enumerate(providers):
        try:
            result = await _run_with_circuit_breaker(store, name, op)
            if i > 0:
                FALLBACK_EVENTS.labels(from_provider=providers[0][0], to_provider=name, capability="text").inc()
            return result
        except HTTPException as exc:
            if first_error is None:
                first_error = exc
            logger.warning("Text provider failed provider=%s detail=%s", name, exc.detail)
    raise first_error or HTTPException(status_code=502, detail="No text provider available")


async def _generate_image_with_fallback(client: httpx.AsyncClient, store, payload: ImageGenerateRequest) -> ImageGenerateResponse:
    return await _run_with_circuit_breaker(store, "openai-image", lambda: _openai_image(client, payload))


@app.middleware("http")
async def add_request_context_and_metrics(request: Request, call_next):
    request_id = request.headers.get("x-request-id", str(uuid.uuid4()))
    request.state.request_id = request_id
    started = time.perf_counter()
    response = None
    try:
        response = await call_next(request)
        return response
    finally:
        duration = time.perf_counter() - started
        status_code = str(getattr(response, "status_code", 500))
        REQUEST_COUNTER.labels(method=request.method, path=request.url.path, status_code=status_code).inc()
        REQUEST_LATENCY.labels(method=request.method, path=request.url.path).observe(duration)
        extra = {
            "request_id": request_id,
            "method": request.method,
            "path": request.url.path,
            "status_code": status_code,
            "duration_ms": int(duration * 1000),
        }
        provider_log = getattr(request.state, "provider_log", None)
        if provider_log:
            extra["provider"] = provider_log.get("provider")
            extra["fallback_used"] = provider_log.get("fallback_used")
        logger.info("request_complete", extra=extra)
        if response is not None:
            response.headers["X-Request-ID"] = request_id


@app.exception_handler(Exception)
async def unhandled_exception_handler(_: Request, exc: Exception):
    if isinstance(exc, HTTPException):
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
    logger.exception("Unhandled server error: %s", exc)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.get("/health", response_model=HealthResponse, tags=["system"])
async def health() -> HealthResponse:
    return HealthResponse(
        status="ok",
        environment=ENVIRONMENT,
        version=APP_VERSION,
        providers={"openai": bool(OPENAI_API_KEY), "anthropic": bool(ANTHROPIC_API_KEY)},
    )


@app.get("/ready", response_model=ReadyResponse, tags=["system"])
async def ready(request: Request) -> ReadyResponse:
    store = request.app.state.store
    redis_ok = await store.ping()
    checks = {
        "redis_connected_or_optional": redis_ok or (not REDIS_REQUIRED),
        "openai_configured": bool(OPENAI_API_KEY),
        "at_least_one_text_provider_configured": bool(OPENAI_API_KEY or ANTHROPIC_API_KEY),
        "image_provider_configured": bool(OPENAI_API_KEY),
    }
    return ReadyResponse(ready=all(checks.values()), checks=checks)


@app.get("/metrics", include_in_schema=False, tags=["system"])
async def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/v1/text/generate", response_model=TextGenerateResponse, tags=["text"])
async def text_generate(
    payload: TextGenerateRequest,
    request: Request,
    _: Optional[str] = Depends(verify_api_key),
    __: None = Depends(enforce_rate_limit),
    client: httpx.AsyncClient = Depends(get_http_client),
    store=Depends(get_store),
) -> TextGenerateResponse:
    cache_key = build_cache_key("text", payload.model_dump())
    if payload.cache:
        cached = await store.get_cache(cache_key)
        if cached is not None:
            CACHE_EVENTS.labels(event="hit").inc()
            request.state.provider_log = {"provider": cached["provider"], "fallback_used": False}
            return TextGenerateResponse(**cached, cached=True, request_id=request.state.request_id)

    CACHE_EVENTS.labels(event="miss").inc()
    result = await _generate_text_with_fallback(client, store, payload)
    request.state.provider_log = {"provider": result.provider, "fallback_used": result.provider != "openai"}
    if payload.cache:
        await store.set_cache(cache_key, result.model_dump())
        CACHE_EVENTS.labels(event="set").inc()
    return result.model_copy(update={"request_id": request.state.request_id})


@app.post("/v1/image/generate", response_model=ImageGenerateResponse, tags=["images"])
async def image_generate(
    payload: ImageGenerateRequest,
    request: Request,
    _: Optional[str] = Depends(verify_api_key),
    __: None = Depends(enforce_rate_limit),
    client: httpx.AsyncClient = Depends(get_http_client),
    store=Depends(get_store),
) -> ImageGenerateResponse:
    cache_key = build_cache_key("image", payload.model_dump())
    if payload.cache:
        cached = await store.get_cache(cache_key)
        if cached is not None:
            CACHE_EVENTS.labels(event="hit").inc()
            request.state.provider_log = {"provider": cached["provider"], "fallback_used": False}
            return ImageGenerateResponse(**cached, cached=True, request_id=request.state.request_id)

    CACHE_EVENTS.labels(event="miss").inc()
    result = await _generate_image_with_fallback(client, store, payload)
    request.state.provider_log = {"provider": result.provider, "fallback_used": False}
    if payload.cache:
        await store.set_cache(cache_key, result.model_dump())
        CACHE_EVENTS.labels(event="set").inc()
    return result.model_copy(update={"request_id": request.state.request_id})
