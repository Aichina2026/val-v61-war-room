# AI Gateway API (Railway-safe)

This package includes a full FastAPI AI gateway with:
- OpenAI text generation
- Anthropic fallback for text
- OpenAI image generation
- optional Redis on startup
- health, ready, metrics, docs
- Dockerfile ready for Railway

## Railway
Set:
- `REDIS_REQUIRED=false` for first deploy
- your provider API keys in Railway Variables

## Endpoints
- `GET /health`
- `GET /ready`
- `GET /docs`
- `GET /openapi.json`
- `POST /v1/text/generate`
- `POST /v1/image/generate`
