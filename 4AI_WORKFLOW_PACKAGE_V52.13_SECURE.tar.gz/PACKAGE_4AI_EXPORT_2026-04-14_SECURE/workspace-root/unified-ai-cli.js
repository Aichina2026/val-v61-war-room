#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════
 * KIMICLAW Unified AI CLI v1.1
 * 统一调用入口: auto + 4AI + 零错误 + oh-my-codex + free-code
 * 
 * 使用方法:
 *   ./unified-ai-cli.js <workflow> "你的需求" [options]
 * 
 * 工作流:
 *   auto   - 自主决策 (系统自己判断用什么工作流) ← 推荐
 *   4ai    - 4AI并行推演 (默认, 成本~$19/1M)
 *   zero   - 零错误系统 (严格模式, 成本~$35/1M)
 *   codex  - oh-my-codex ($team/$ri模式)
 *   free   - free-code (Claude Code风格)
 * 
 * 模式:
 *   fast     - 快速模式 (30s超时)
 *   standard - 标准模式 (60s超时, 默认)
 *   strict   - 严格模式 (120s, 多轮审查)
 * 
 * 示例:
 *   ./unified-ai-cli.js auto "设计一个API网关" --mode=standard
 *   ./unified-ai-cli.js auto "生成安全认证代码" --mode=strict
 *   ./unified-ai-cli.js auto "并行审查这个架构" --team
 * ═══════════════════════════════════════════════════════════════════
 */

import { readFileSync, existsSync } from 'fs';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ═══════════════════════════════════════════════════════════════════
// 配置加载
// ═══════════════════════════════════════════════════════════════════
const CONFIG_PATH = join(__dirname, 'unified-ai-config.json');
let CONFIG = null;

try {
  CONFIG = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'));
} catch (e) {
  console.error('❌ 配置文件加载失败:', CONFIG_PATH);
  console.error(e.message);
  process.exit(1);
}

// ═══════════════════════════════════════════════════════════════════
// 参数解析
// ═══════════════════════════════════════════════════════════════════
function parseArgs() {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    showHelp();
    process.exit(0);
  }

  const workflow = args[0];
  const prompt = args[1];
  const options = {
    mode: 'standard',
    output: null,
    verbose: false,
    team: false,
    ri: false
  };

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    if (arg.startsWith('--mode=')) {
      options.mode = arg.split('=')[1];
    } else if (arg.startsWith('--output=')) {
      options.output = arg.split('=')[1];
    } else if (arg === '--verbose' || arg === '-v') {
      options.verbose = true;
    } else if (arg === '--team') {
      options.team = true;
    } else if (arg === '--ri') {
      options.ri = true;
    } else if (arg === '--help' || arg === '-h') {
      showHelp();
      process.exit(0);
    }
  }

  return { workflow, prompt, options };
}

function showHelp() {
  console.log(`
╔══════════════════════════════════════════════════════════════════╗
║          KIMICLAW Unified AI CLI v1.1                            ║
║          新增: auto 自主决策模式                                 ║
╚══════════════════════════════════════════════════════════════════╝

用法: unified-ai-cli.js <workflow> "你的需求" [options]

工作流 (workflow):
  auto        自主决策 (系统自己判断用什么工作流) ← 推荐
  4ai         4AI并行推演 (Clarifier→Builder→Reviewer→Arbiter)
  zero        零错误系统 (2-3轮对抗审查)
  codex       oh-my-codex ($team/$ri模式)
  free        free-code (Claude Code纯洁版)

模式 (mode):
  fast        快速模式 (30s超时, 1次重试)
  standard    标准模式 (60s超时, 2次重试, 默认)
  strict      严格模式 (120s超时, 3次重试)

选项:
  --mode=MODE      执行模式 (fast|standard|strict)
  --output=FILE    输出到文件
  --verbose, -v    详细输出
  --team           $team模式 (codex工作流)
  --ri             $ri持久模式 (codex工作流)
  --help, -h       显示帮助

示例:
  ./unified-ai-cli.js auto "设计一个微服务架构"
  ./unified-ai-cli.js auto "生成用户认证代码" --mode=strict
  ./unified-ai-cli.js auto "并行审查架构设计" --team
  ./unified-ai-cli.js 4ai "写Python爬虫" --mode=fast --output=spider.py

角色配置:
  Clarifier:  ${CONFIG.role_models.clarifier.model}
  Builder:    ${CONFIG.role_models.builder.model}
  Reviewer:   ${CONFIG.role_models.reviewer.model}
  Arbiter:    ${CONFIG.role_models.arbiter.model}
`);
}

// ═══════════════════════════════════════════════════════════════════
// 工作流执行
// ═══════════════════════════════════════════════════════════════════
async function executeWorkflow(workflow, prompt, options) {
  const modeConfig = CONFIG.execution_modes[options.mode] || CONFIG.execution_modes.standard;

  console.log(`\n╔══════════════════════════════════════════════════════════════════╗`);
  console.log(`║  工作流: ${workflow.padEnd(10)} │ 模式: ${options.mode.padEnd(10)} ║`);
  console.log(`╚══════════════════════════════════════════════════════════════════╝\n`);
  console.log(`📝 需求: ${prompt.slice(0, 80)}${prompt.length > 80 ? '...' : ''}`);
  console.log(`⏱️  超时: ${modeConfig.timeout / 1000}s | 重试: ${modeConfig.retries}次\n`);

  const startTime = Date.now();

  try {
    let result;

    switch (workflow) {
      case 'auto':
        result = await executeAutonomous(prompt, modeConfig, options);
        break;
      case '4ai':
        result = await execute4AI(prompt, modeConfig, options);
        break;
      case 'zero':
        result = await executeZeroError(prompt, modeConfig, options);
        break;
      case 'codex':
        result = await executeCodex(prompt, modeConfig, options);
        break;
      case 'free':
        result = await executeFreeCode(prompt, modeConfig, options);
        break;
      default:
        throw new Error(`未实现的工作流: ${workflow}`);
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(`\n✅ 完成 (${duration}s)`);

    if (options.output) {
      const fs = await import('fs');
      fs.writeFileSync(options.output, result);
      console.log(`💾 输出已保存: ${options.output}`);
    }

    return result;

  } catch (error) {
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.error(`\n❌ 执行失败 (${duration}s): ${error.message}`);
    process.exit(1);
  }
}

// 自主决策模式
async function executeAutonomous(prompt, modeConfig, options) {
  const plannerPath = join(__dirname, 'AutonomousPlanner.js');
  
  if (!existsSync(plannerPath)) {
    throw new Error(`AutonomousPlanner不存在: ${plannerPath}`);
  }

  console.log(`🧠 启动自主决策模式...`);
  
  return new Promise((resolve, reject) => {
    const child = spawn('node', [plannerPath, prompt, options.verbose ? '--verbose' : ''], {
      stdio: options.verbose ? 'inherit' : 'pipe',
      env: {
        ...process.env,
        UNIFIED_MODE: options.mode,
        UNIFIED_TIMEOUT: modeConfig.timeout.toString()
      }
    });

    let output = '';
    if (!options.verbose) {
      child.stdout?.on('data', (data) => output += data.toString());
      child.stderr?.on('data', (data) => console.error(data.toString()));
    }

    child.on('close', (code) => {
      if (code === 0) {
        resolve(output);
      } else {
        reject(new Error(`自主决策进程退出码: ${code}`));
      }
    });

    setTimeout(() => {
      child.kill();
      reject(new Error(`自主决策执行超时 (${modeConfig.timeout}ms)`));
    }, modeConfig.timeout);
  });
}

// 4AI并行工作流
async function execute4AI(prompt, modeConfig, options) {
  const scriptPath = join(__dirname, CONFIG.workflows['4ai'].script);
  
  if (!existsSync(scriptPath)) {
    throw new Error(`脚本不存在: ${scriptPath}`);
  }

  return new Promise((resolve, reject) => {
    const child = spawn('node', [scriptPath, prompt], {
      stdio: options.verbose ? 'inherit' : 'pipe',
      env: {
        ...process.env,
        UNIFIED_MODE: options.mode,
        UNIFIED_TIMEOUT: modeConfig.timeout.toString(),
        UNIFIED_RETRIES: modeConfig.retries.toString()
      }
    });

    let output = '';
    if (!options.verbose) {
      child.stdout?.on('data', (data) => output += data.toString());
      child.stderr?.on('data', (data) => console.error(data.toString()));
    }

    child.on('close', (code) => {
      if (code === 0) {
        resolve(output);
      } else {
        reject(new Error(`进程退出码: ${code}`));
      }
    });

    // 超时处理
    setTimeout(() => {
      child.kill();
      reject(new Error(`执行超时 (${modeConfig.timeout}ms)`));
    }, modeConfig.timeout);
  });
}

// 零错误系统
async function executeZeroError(prompt, modeConfig, options) {
  const scriptPath = join(__dirname, CONFIG.workflows['zero'].script);
  
  if (!existsSync(scriptPath)) {
    throw new Error(`脚本不存在: ${scriptPath}`);
  }

  return new Promise((resolve, reject) => {
    const child = spawn('node', [scriptPath, prompt], {
      stdio: options.verbose ? 'inherit' : 'pipe',
      env: {
        ...process.env,
        ZERO_ERROR_ROUNDS: options.mode === 'strict' ? '3' : '2',
        UNIFIED_TIMEOUT: modeConfig.timeout.toString()
      }
    });

    let output = '';
    if (!options.verbose) {
      child.stdout?.on('data', (data) => output += data.toString());
      child.stderr?.on('data', (data) => console.error(data.toString()));
    }

    child.on('close', (code) => {
      if (code === 0) {
        resolve(output);
      } else {
        reject(new Error(`进程退出码: ${code}`));
      }
    });

    setTimeout(() => {
      child.kill();
      reject(new Error(`执行超时 (${modeConfig.timeout}ms)`));
    }, modeConfig.timeout);
  });
}

// oh-my-codex
async function executeCodex(prompt, modeConfig, options) {
  console.log(`🔧 oh-my-codex 模式: ${options.team ? '$team' : options.ri ? '$ri' : 'standard'}`);
  
  const adapterPath = join(__dirname, 'openclaw-41-integration/plugins/omx-adapter/src/index.ts');
  
  if (!existsSync(adapterPath)) {
    throw new Error(`OMX适配器不存在: ${adapterPath}`);
  }

  return new Promise((resolve, reject) => {
    const child = spawn('npx', ['tsx', adapterPath, prompt, options.team ? '--team' : options.ri ? '--ri' : ''], {
      stdio: options.verbose ? 'inherit' : 'pipe',
      cwd: join(__dirname, 'openclaw-41-integration')
    });

    let output = '';
    if (!options.verbose) {
      child.stdout?.on('data', (data) => output += data.toString());
    }

    child.on('close', (code) => {
      if (code === 0) {
        resolve(output || 'oh-my-codex 执行完成');
      } else {
        reject(new Error(`进程退出码: ${code}`));
      }
    });

    setTimeout(() => {
      child.kill();
      reject(new Error(`执行超时 (${modeConfig.timeout}ms)`));
    }, modeConfig.timeout);
  });
}

// free-code
async function executeFreeCode(prompt, modeConfig, options) {
  console.log(`🔧 free-code (Claude Code纯洁版)`);
  
  const adapterPath = join(__dirname, 'openclaw-41-integration/plugins/free-code-adapter/src/index.ts');
  
  if (!existsSync(adapterPath)) {
    throw new Error(`FreeCode适配器不存在: ${adapterPath}`);
  }

  return new Promise((resolve, reject) => {
    const child = spawn('npx', ['tsx', adapterPath, prompt], {
      stdio: options.verbose ? 'inherit' : 'pipe',
      cwd: join(__dirname, 'openclaw-41-integration')
    });

    let output = '';
    if (!options.verbose) {
      child.stdout?.on('data', (data) => output += data.toString());
    }

    child.on('close', (code) => {
      if (code === 0) {
        resolve(output || 'free-code 执行完成');
      } else {
        reject(new Error(`进程退出码: ${code}`));
      }
    });

    setTimeout(() => {
      child.kill();
      reject(new Error(`执行超时 (${modeConfig.timeout}ms)`));
    }, modeConfig.timeout);
  });
}

// ═══════════════════════════════════════════════════════════════════
// 主入口
// ═══════════════════════════════════════════════════════════════════
async function main() {
  const { workflow, prompt, options } = parseArgs();

  if (options.verbose) {
    console.log('📋 配置加载成功');
    console.log(`   API池: ${Object.keys(CONFIG.api_pools).join(', ')}`);
    console.log(`   角色: Clarifier=${CONFIG.role_models.clarifier.model}, Builder=${CONFIG.role_models.builder.model}`);
    console.log();
  }

  await executeWorkflow(workflow, prompt, options);
}

main().catch(console.error);
