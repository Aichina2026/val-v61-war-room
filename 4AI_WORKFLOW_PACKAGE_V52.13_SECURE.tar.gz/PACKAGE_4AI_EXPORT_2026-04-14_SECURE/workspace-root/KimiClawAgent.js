#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════
 * KIMICLAW Unified Agent v1.0
 * 综合AGENT: 阶段1+2+3+4 完整实现
 * 
 * 架构:
 *   [用户输入]
 *       ↓
 *   [AutonomousPlanner] 阶段1: 自主规划
 *       ↓
 *   [ReActAgent] 阶段2: 工具使用
 *       ↓
 *   [AgentEventLoop] 阶段3: 事件驱动
 *       ↓
 *   [ExperienceLearner] 阶段4: 经验学习
 *       ↓
 *   [输出结果]
 * 
 * 使用:
 *   node KimiClawAgent.js "你的任务"
 *   node KimiClawAgent.js start --daemon  # 7×24模式
 * ═══════════════════════════════════════════════════════════════════
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import { EventEmitter } from 'events';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ═══════════════════════════════════════════════════════════════════
// Unified Agent 核心
// ═══════════════════════════════════════════════════════════════════
export class KimiClawAgent extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      mode: config.mode || 'auto',  // 'auto' | 'single' | '4ai' | 'zero'
      verbose: config.verbose || false,
      learning: config.learning !== false,
      eventLoop: config.eventLoop !== false,
      maxSteps: config.maxSteps || 8,
      ...config
    };

    this.components = {};
    this.initialized = false;
    this.stats = {
      tasksProcessed: 0,
      startTime: Date.now()
    };
  }

  /**
   * 初始化所有组件
   */
  async initialize() {
    if (this.initialized) return;

    console.log('[KimiClawAgent] 初始化组件...');

    // 阶段1: 自主规划
    const { default: AutonomousPlanner } = await import('./AutonomousPlanner.js');
    this.components.planner = new AutonomousPlanner({ verbose: this.config.verbose });

    // 阶段2: ReAct工具使用
    const { ReActAgent } = await import('./ReActAgent.js');
    this.components.react = ReActAgent;

    // 阶段3: 事件驱动循环 (可选)
    if (this.config.eventLoop) {
      const { AgentEventLoop } = await import('./AgentEventLoop.js');
      this.components.eventLoop = new AgentEventLoop({
        verbose: this.config.verbose,
        enableWebhook: false  // 手动模式不启动webhook
      });
    }

    // 阶段4: 经验学习 (可选)
    if (this.config.learning) {
      const { ExperienceLearner } = await import('./ExperienceLearner.js');
      this.components.learner = new ExperienceLearner({ verbose: this.config.verbose });
    }

    this.initialized = true;
    console.log('[KimiClawAgent] ✅ 初始化完成');
  }

  /**
   * 处理单个任务
   */
  async processTask(input, options = {}) {
    await this.initialize();

    const startTime = Date.now();
    this.emit('task:start', { input, timestamp: startTime });

    console.log('\n╔══════════════════════════════════════════════════════════════════╗');
    console.log('║     🤖 KimiClaw Unified Agent v1.0                               ║');
    console.log('╚══════════════════════════════════════════════════════════════════╝\n');
    console.log(`📝 输入: ${input}\n`);

    try {
      // ========== 阶段1: 自主规划 ==========
      console.log('━'.repeat(67));
      console.log('📊 阶段1: 自主规划 (AutonomousPlanner)');
      console.log('━'.repeat(67));

      const plan = await this.components.planner.plan(input);
      console.log(`   复杂度: ${plan.analysis.complexity.score.toFixed(2)} (${plan.analysis.complexity.level})`);
      console.log(`   推荐工作流: ${plan.strategy.workflow}`);
      console.log(`   建议工具: ${plan.strategy.useTools.join(', ') || '无'}`);

      // ========== 阶段2: ReAct执行 ==========
      console.log('\n' + '━'.repeat(67));
      console.log('🔧 阶段2: ReAct工具使用 (ReActAgent)');
      console.log('━'.repeat(67));

      const agent = new this.components.react({
        verbose: this.config.verbose,
        maxSteps: this.config.maxSteps
      });

      const reactResult = await agent.run(input);

      // ========== 阶段4: 经验学习 ==========
      if (this.components.learner) {
        console.log('\n' + '━'.repeat(67));
        console.log('🧠 阶段4: 经验学习 (ExperienceLearner)');
        console.log('━'.repeat(67));

        reactResult.duration = Date.now() - startTime;
        const experience = this.components.learner.learnFromReAct(reactResult);
        this.components.learner.saveExperiences(); // 立即保存
        console.log(`   记录经验: ${experience.id}`);
        console.log(`   任务类型: ${experience.taskType}`);
        console.log(`   结果评估: ${experience.outcome}`);

        // 显示学习建议
        const optimal = this.components.learner.getOptimalStrategy(experience.taskType);
        if (optimal) {
          console.log(`   💡 历史最优策略: ${(optimal.successRate * 100).toFixed(0)}% 成功率 (基于${optimal.sampleCount}个样本)`);
        }
      }

      // ========== 汇总输出 ==========
      const duration = Date.now() - startTime;
      this.stats.tasksProcessed++;

      console.log('\n' + '═'.repeat(67));
      console.log(`✅ 任务完成 | 耗时: ${(duration / 1000).toFixed(2)}s | 步数: ${reactResult.stepCount}`);
      console.log('═'.repeat(67) + '\n');

      const result = {
        success: true,
        input,
        plan,
        execution: reactResult,
        duration,
        stats: { ...this.stats }
      };

      this.emit('task:complete', result);
      return result;

    } catch (error) {
      console.error('\n❌ 任务失败:', error.message);
      this.emit('task:error', { input, error: error.message });
      throw error;
    }
  }

  /**
   * 启动7×24事件驱动模式
   */
  async startDaemon() {
    await this.initialize();

    if (!this.components.eventLoop) {
      throw new Error('EventLoop未启用，无法启动Daemon模式');
    }

    console.log('\n═══════════════════════════════════════════════════════════════');
    console.log('🚀 KimiClaw Agent - 7×24 Daemon模式启动');
    console.log('═══════════════════════════════════════════════════════════════\n');

    // 自定义处理器，集成学习闭环
    this.components.eventLoop.registerHandler('user_request', async (event) => {
      const goal = event.payload.goal || event.payload.text;
      console.log(`[Daemon] 收到任务: ${goal}`);

      try {
        const result = await this.processTask(goal);
        return {
          status: 'completed',
          eventId: event.id,
          stepCount: result.execution.stepCount,
          duration: result.duration
        };
      } catch (e) {
        return {
          status: 'failed',
          eventId: event.id,
          error: e.message
        };
      }
    });

    // 启动事件循环
    await this.components.eventLoop.start();
  }

  /**
   * 停止Daemon
   */
  stopDaemon() {
    if (this.components.eventLoop) {
      this.components.eventLoop.stop();
    }
    console.log('[KimiClawAgent] Daemon已停止');
  }

  /**
   * 获取学习报告
   */
  getLearningReport() {
    if (!this.components.learner) return { status: 'learning_disabled' };
    return this.components.learner.generateReport();
  }

  /**
   * 获取状态
   */
  getStatus() {
    return {
      initialized: this.initialized,
      mode: this.config.mode,
      stats: this.stats,
      components: Object.keys(this.components),
      learning: this.components.learner?.getStats() || null,
      eventLoop: this.components.eventLoop?.getStatus() || null
    };
  }
}

// ═══════════════════════════════════════════════════════════════════
// CLI 入口
// ═══════════════════════════════════════════════════════════════════
async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
╔══════════════════════════════════════════════════════════════════╗
║     🤖 KimiClaw Unified Agent v1.0                               ║
║     综合AGENT: 阶段1+2+3+4 完整实现                              ║
╚══════════════════════════════════════════════════════════════════╝

用法:
  node KimiClawAgent.js "你的任务" [选项]         # 单次任务模式
  node KimiClawAgent.js start --daemon [选项]     # 7×24 Daemon模式

命令:
  直接输入任务描述    执行单次任务
  start --daemon      启动常驻Daemon模式
  status              查看Agent状态
  report              生成学习报告

选项:
  --mode=MODE         工作流模式 (auto|single|4ai|zero, 默认auto)
  --verbose, -v       详细输出
  --no-learning       禁用经验学习
  --no-eventloop      禁用事件循环
  --max-steps=N       ReAct最大步数 (默认8)
  --help, -h          显示帮助

示例:
  node KimiClawAgent.js "设计一个微服务架构"
  node KimiClawAgent.js "搜索2026年AI最新进展" --verbose
  node KimiClawAgent.js start --daemon
  node KimiClawAgent.js report

架构:
  阶段1: AutonomousPlanner  - 自主规划层
  阶段2: ReActAgent         - 工具使用模式
  阶段3: AgentEventLoop     - 7×24事件驱动
  阶段4: ExperienceLearner  - 经验学习闭环
`);
    return;
  }

  const command = args[0];
  const verbose = args.includes('--verbose') || args.includes('-v');
  const noLearning = args.includes('--no-learning');
  const noEventLoop = args.includes('--no-eventloop');
  const daemon = args.includes('--daemon');

  const modeArg = args.find(a => a.startsWith('--mode='));
  const mode = modeArg ? modeArg.split('=')[1] : 'auto';

  const maxStepsArg = args.find(a => a.startsWith('--max-steps='));
  const maxSteps = maxStepsArg ? parseInt(maxStepsArg.split('=')[1]) : 8;

  const agent = new KimiClawAgent({
    mode,
    verbose,
    learning: !noLearning,
    eventLoop: !noEventLoop,
    maxSteps
  });

  // 处理状态查询
  if (command === 'status') {
    console.log(JSON.stringify(agent.getStatus(), null, 2));
    return;
  }

  // 处理学习报告
  if (command === 'report') {
    await agent.initialize();
    console.log(JSON.stringify(agent.getLearningReport(), null, 2));
    return;
  }

  // 启动Daemon模式
  if (command === 'start' && daemon) {
    await agent.startDaemon();

    // 处理退出信号
    process.on('SIGINT', () => {
      console.log('\n收到SIGINT，正在关闭...');
      agent.stopDaemon();
      process.exit(0);
    });
    return;
  }

  // 单次任务模式
  const task = args.join(' ').replace(/--\w+(=\w+)?/g, '').trim();
  if (!task) {
    console.log('❌ 请提供任务描述');
    return;
  }

  try {
    const result = await agent.processTask(task);

    // 输出最终结果
    if (result.execution?.finalAnswer) {
      console.log(result.execution.finalAnswer);
    }

  } catch (error) {
    console.error('❌ 执行失败:', error.message);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}

export default KimiClawAgent;
