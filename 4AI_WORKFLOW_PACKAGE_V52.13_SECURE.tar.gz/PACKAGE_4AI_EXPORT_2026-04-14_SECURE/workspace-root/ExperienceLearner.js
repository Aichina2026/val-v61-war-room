#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════
 * KIMICLAW Experience Learner v1.0
 * 阶段4: 经验学习闭环 (从执行历史自我优化)
 *
 * 核心能力:
 * - 执行历史记录 (4维状态关联)
 * - 成功/失败模式分析
 * - 策略参数自动调整
 * - 工具选择优化
 * - 反馈驱动的持续改进
 * ═══════════════════════════════════════════════════════════════════
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ═══════════════════════════════════════════════════════════════════
// 经验数据模型
// ═══════════════════════════════════════════════════════════════════
class Experience {
  constructor(data) {
    this.id = `exp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    this.timestamp = Date.now();
    this.task = data.task;              // 任务描述
    this.taskType = data.taskType;      // 任务类型分类
    this.strategy = data.strategy;      // 使用的策略
    this.tools = data.tools || [];      // 使用的工具
    this.result = data.result;          // 执行结果
    this.outcome = data.outcome;        // 'success' | 'partial' | 'failure'
    this.metrics = data.metrics || {};  // 性能指标
    this.feedback = data.feedback;      // 外部反馈
    this.context = data.context || {};  // 上下文信息
  }
}

// ═══════════════════════════════════════════════════════════════════
// 策略优化器
// ═══════════════════════════════════════════════════════════════════
class StrategyOptimizer {
  constructor(learner) {
    this.learner = learner;
    this.strategies = new Map();
    this.minSamples = 3;  // 最少样本数才进行优化
  }

  /**
   * 注册可优化的策略
   */
  registerStrategy(name, config) {
    this.strategies.set(name, {
      name,
      parameters: config.parameters || {},  // { paramName: { min, max, current, step } }
      performance: [],  // 历史表现记录
      lastOptimized: null
    });
  }

  /**
   * 分析策略表现
   */
  analyzePerformance(strategyName, experiences) {
    const strategy = this.strategies.get(strategyName);
    if (!strategy) return null;

    const relevantExps = experiences.filter(e => e.strategy?.name === strategyName);
    if (relevantExps.length < this.minSamples) {
      return { status: 'insufficient_data', samples: relevantExps.length };
    }

    // 计算成功率和平均指标
    const successRate = relevantExps.filter(e => e.outcome === 'success').length / relevantExps.length;
    const avgDuration = relevantExps.reduce((sum, e) => sum + (e.metrics.duration || 0), 0) / relevantExps.length;
    const avgCost = relevantExps.reduce((sum, e) => sum + (e.metrics.cost || 0), 0) / relevantExps.length;

    // 按参数值分组分析
    const paramPerformance = {};
    for (const paramName of Object.keys(strategy.parameters)) {
      const groups = {};
      for (const exp of relevantExps) {
        const value = exp.strategy?.parameters?.[paramName];
        if (value !== undefined) {
          if (!groups[value]) groups[value] = [];
          groups[value].push(exp);
        }
      }

      paramPerformance[paramName] = {};
      for (const [value, exps] of Object.entries(groups)) {
        const successRate = exps.filter(e => e.outcome === 'success').length / exps.length;
        paramPerformance[paramName][value] = { successRate, sampleCount: exps.length };
      }
    }

    return {
      status: 'analyzed',
      strategy: strategyName,
      totalSamples: relevantExps.length,
      successRate,
      avgDuration,
      avgCost,
      paramPerformance,
      recommendations: this.generateRecommendations(strategyName, paramPerformance, successRate)
    };
  }

  /**
   * 生成优化建议
   */
  generateRecommendations(strategyName, paramPerformance, currentSuccessRate) {
    const recommendations = [];
    const strategy = this.strategies.get(strategyName);

    for (const [paramName, values] of Object.entries(paramPerformance)) {
      const sortedValues = Object.entries(values)
        .sort((a, b) => b[1].successRate - a[1].successRate)
        .filter(v => v[1].sampleCount >= 2);  // 至少2个样本

      if (sortedValues.length > 0) {
        const bestValue = sortedValues[0];
        const currentValue = strategy.parameters[paramName]?.current;

        if (bestValue[0] !== String(currentValue) && bestValue[1].successRate > currentSuccessRate) {
          recommendations.push({
            type: 'parameter_adjustment',
            parameter: paramName,
            currentValue,
            suggestedValue: bestValue[0],
            expectedImprovement: ((bestValue[1].successRate - currentSuccessRate) * 100).toFixed(1) + '%',
            confidence: Math.min(bestValue[1].sampleCount / 10, 1)  // 最多1.0
          });
        }
      }
    }

    return recommendations;
  }

  /**
   * 应用优化建议
   */
  applyOptimization(strategyName, recommendations) {
    const strategy = this.strategies.get(strategyName);
    if (!strategy) return false;

    let applied = 0;
    for (const rec of recommendations) {
      if (rec.confidence >= 0.6 && rec.type === 'parameter_adjustment') {
        strategy.parameters[rec.parameter].current = rec.suggestedValue;
        applied++;
      }
    }

    strategy.lastOptimized = Date.now();
    return { applied, strategy: strategyName };
  }
}

// ═══════════════════════════════════════════════════════════════════
// 工具选择优化器
// ═══════════════════════════════════════════════════════════════════
class ToolSelectionOptimizer {
  constructor() {
    this.toolStats = new Map();  // toolName -> { successCount, failureCount, avgTime }
  }

  recordToolUsage(toolName, success, duration) {
    if (!this.toolStats.has(toolName)) {
      this.toolStats.set(toolName, { successCount: 0, failureCount: 0, totalTime: 0, count: 0 });
    }

    const stats = this.toolStats.get(toolName);
    if (success) {
      stats.successCount++;
    } else {
      stats.failureCount++;
    }
    stats.totalTime += duration;
    stats.count++;
  }

  getToolScore(toolName) {
    const stats = this.toolStats.get(toolName);
    if (!stats || stats.count < 2) return 0.5;  // 默认中等分数

    const successRate = stats.successCount / stats.count;
    const avgTime = stats.totalTime / stats.count;
    const timeScore = Math.max(0, 1 - avgTime / 10000);  // 10秒内完成得满分

    return (successRate * 0.7 + timeScore * 0.3);  // 70%成功率 + 30%速度
  }

  suggestTools(taskDescription, availableTools) {
    // 基于历史表现排序
    const scored = availableTools.map(tool => ({
      name: tool,
      score: this.getToolScore(tool),
      stats: this.toolStats.get(tool) || { count: 0 }
    }));

    return scored.sort((a, b) => b.score - a.score);
  }
}

// ═══════════════════════════════════════════════════════════════════
// 经验学习者核心
// ═══════════════════════════════════════════════════════════════════
export class ExperienceLearner {
  constructor(config = {}) {
    this.config = {
      storagePath: config.storagePath || join(__dirname, 'memory', 'experiences.json'),
      maxExperiences: config.maxExperiences || 1000,
      autoOptimize: config.autoOptimize !== false,
      verbose: config.verbose || false,
      ...config
    };

    this.experiences = [];
    this.strategyOptimizer = new StrategyOptimizer(this);
    this.toolOptimizer = new ToolSelectionOptimizer();

    this.loadExperiences();
    this.registerDefaultStrategies();
  }

  registerDefaultStrategies() {
    // 注册复杂度阈值策略
    this.strategyOptimizer.registerStrategy('complexity_threshold', {
      parameters: {
        simpleThreshold: { min: 0.1, max: 0.5, current: 0.3, step: 0.05 },
        standardThreshold: { min: 0.5, max: 0.9, current: 0.65, step: 0.05 }
      }
    });

    // 注册工具置信度策略
    this.strategyOptimizer.registerStrategy('tool_confidence', {
      parameters: {
        minConfidence: { min: 0.5, max: 0.9, current: 0.7, step: 0.05 },
        multiToolThreshold: { min: 0.6, max: 1.0, current: 0.8, step: 0.05 }
      }
    });
  }

  /**
   * 加载历史经验
   */
  loadExperiences() {
    try {
      if (existsSync(this.config.storagePath)) {
        const data = readFileSync(this.config.storagePath, 'utf8');
        this.experiences = JSON.parse(data);
        console.log(`[Learner] 已加载 ${this.experiences.length} 条经验`);
      } else {
        console.log('[Learner] 未找到历史经验,从头开始');
      }
    } catch (e) {
      console.warn('[Learner] 加载经验失败:', e.message);
      this.experiences = [];
    }
  }

  /**
   * 保存经验
   */
  saveExperiences() {
    try {
      const dir = dirname(this.config.storagePath);
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

      // 保留最近的N条
      const toSave = this.experiences.slice(-this.config.maxExperiences);
      writeFileSync(this.config.storagePath, JSON.stringify(toSave, null, 2), 'utf8');

      if (this.config.verbose) {
        console.log(`[Learner] 已保存 ${toSave.length} 条经验`);
      }
    } catch (e) {
      console.error('[Learner] 保存经验失败:', e.message);
    }
  }

  /**
   * 记录新经验
   */
  record(data) {
    const experience = new Experience(data);
    this.experiences.push(experience);

    // 更新工具统计
    if (data.tools) {
      for (const tool of data.tools) {
        this.toolOptimizer.recordToolUsage(
          tool.name,
          data.outcome === 'success',
          data.metrics?.duration || 0
        );
      }
    }

    // 自动保存
    if (this.experiences.length % 10 === 0) {
      this.saveExperiences();
    }

    if (this.config.verbose) {
      console.log(`[Learner] +经验: ${experience.id} (${experience.outcome})`);
    }

    return experience;
  }

  /**
   * 从ReAct执行结果学习
   */
  learnFromReAct(reactResult, feedback = null) {
    const taskType = this.classifyTask(reactResult.goal);

    // 判断结果质量
    let outcome = 'partial';
    const lastStep = reactResult.steps[reactResult.steps.length - 1];
    const hasValidAnswer = lastStep?.action?.type === 'finish' && 
      (lastStep?.action?.answer || lastStep?.observation?.answer);
    
    if (reactResult.steps.length <= 1 && !hasValidAnswer) {
      outcome = 'failure';  // 几乎没执行且无有效答案
    } else if (hasValidAnswer || reactResult.steps.every(s =>
      s.observation?.success !== false || s.action?.type === 'finish'
    )) {
      outcome = 'success';
    }

    const experience = this.record({
      task: reactResult.goal,
      taskType,
      strategy: {
        name: 'react_default',
        parameters: {
          maxSteps: reactResult.stepCount,
          toolsUsed: reactResult.toolsUsed
        }
      },
      tools: reactResult.toolsUsed.map(t => ({ name: t })),
      result: {
        stepCount: reactResult.stepCount,
        finalAnswer: reactResult.finalAnswer?.slice(0, 500)
      },
      outcome,
      metrics: {
        duration: reactResult.duration || 0,
        stepCount: reactResult.stepCount,
        toolCount: reactResult.toolsUsed.length
      },
      feedback,
      context: {
        timestamp: reactResult.timestamp,
        source: 'react_agent'
      }
    });

    // 触发自动优化
    if (this.config.autoOptimize && this.experiences.length % 20 === 0) {
      this.runOptimization();
    }

    return experience;
  }

  /**
   * 任务分类
   */
  classifyTask(goal) {
    const lowerGoal = goal.toLowerCase();

    if (/搜索|查找|最新|2026|news|search/.test(lowerGoal)) return 'research';
    if (/文件|读取|保存|file|read|write/.test(lowerGoal)) return 'file_operation';
    if (/计算|数学|统计|calculate|math/.test(lowerGoal)) return 'computation';
    if (/设计|架构|系统|design|architecture/.test(lowerGoal)) return 'design';
    if (/代码|编程|函数|code|programming/.test(lowerGoal)) return 'coding';
    if (/你好|hello|hi|help/.test(lowerGoal)) return 'greeting';
    return 'general';
  }

  /**
   * 运行优化
   */
  runOptimization() {
    console.log('[Learner] 运行策略优化...');

    const results = [];
    for (const [name] of this.strategyOptimizer.strategies) {
      const analysis = this.strategyOptimizer.analyzePerformance(name, this.experiences);
      if (analysis?.status === 'analyzed') {
        console.log(`[Learner] 策略 "${name}" 分析完成:`, {
          successRate: (analysis.successRate * 100).toFixed(1) + '%',
          recommendations: analysis.recommendations.length
        });

        if (analysis.recommendations.length > 0) {
          const result = this.strategyOptimizer.applyOptimization(name, analysis.recommendations);
          results.push(result);
        }
      }
    }

    return results;
  }

  /**
   * 获取任务类型的最优策略
   */
  getOptimalStrategy(taskType) {
    const relevantExps = this.experiences.filter(e => e.taskType === taskType);
    if (relevantExps.length < 3) return null;

    const strategyPerformance = {};
    for (const exp of relevantExps) {
      const stratKey = JSON.stringify(exp.strategy?.parameters || {});
      if (!strategyPerformance[stratKey]) {
        strategyPerformance[stratKey] = { success: 0, failure: 0, exps: [] };
      }
      if (exp.outcome === 'success') strategyPerformance[stratKey].success++;
      else strategyPerformance[stratKey].failure++;
      strategyPerformance[stratKey].exps.push(exp);
    }

    // 找到最佳策略
    let bestStrategy = null;
    let bestRate = 0;
    for (const [key, perf] of Object.entries(strategyPerformance)) {
      const rate = perf.success / (perf.success + perf.failure);
      if (rate > bestRate && (perf.success + perf.failure) >= 3) {
        bestRate = rate;
        bestStrategy = { key, ...perf };
      }
    }

    return bestStrategy ? {
      strategy: JSON.parse(bestStrategy.key),
      successRate: bestRate,
      sampleCount: bestStrategy.success + bestStrategy.failure
    } : null;
  }

  /**
   * 生成学习报告
   */
  generateReport() {
    const total = this.experiences.length;
    if (total === 0) return { status: 'no_data' };

    const outcomes = { success: 0, partial: 0, failure: 0 };
    const taskTypes = {};
    const toolUsage = {};

    for (const exp of this.experiences) {
      outcomes[exp.outcome]++;
      taskTypes[exp.taskType] = (taskTypes[exp.taskType] || 0) + 1;

      for (const tool of exp.tools || []) {
        toolUsage[tool.name] = (toolUsage[tool.name] || 0) + 1;
      }
    }

    return {
      status: 'ok',
      totalExperiences: total,
      outcomes: {
        ...outcomes,
        successRate: ((outcomes.success / total) * 100).toFixed(1) + '%'
      },
      taskTypeDistribution: taskTypes,
      toolUsage: Object.entries(toolUsage)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10),
      optimalStrategies: Object.keys(taskTypes).map(type => ({
        type,
        optimal: this.getOptimalStrategy(type)
      })).filter(x => x.optimal),
      lastOptimized: this.strategyOptimizer.strategies.get('complexity_threshold')?.lastOptimized
    };
  }

  /**
   * 获取统计信息
   */
  getStats() {
    return {
      totalExperiences: this.experiences.length,
      toolStats: Object.fromEntries(this.toolOptimizer.toolStats),
      strategies: Object.fromEntries(
        Array.from(this.strategyOptimizer.strategies.entries()).map(([k, v]) => [
          k,
          { parameters: v.parameters, lastOptimized: v.lastOptimized }
        ])
      )
    };
  }
}

// ═══════════════════════════════════════════════════════════════════
// 集成到ReActAgent和AgentEventLoop的包装器
// ═══════════════════════════════════════════════════════════════════
export class LearningAgent {
  constructor(config = {}) {
    this.learner = new ExperienceLearner(config);
    this.verbose = config.verbose || false;
  }

  /**
   * 包装ReActAgent执行
   */
  async runWithLearning(ReActAgentClass, goal) {
    const agent = new ReActAgentClass({ verbose: this.verbose });

    const startTime = Date.now();
    const result = await agent.run(goal);
    const duration = Date.now() - startTime;

    // 记录经验
    result.duration = duration;
    const experience = this.learner.learnFromReAct(result);

    // 附加学习信息到结果
    result.learning = {
      experienceId: experience.id,
      taskType: experience.taskType,
      outcome: experience.outcome,
      suggestions: this.getSuggestions(experience.taskType)
    };

    return result;
  }

  getSuggestions(taskType) {
    const optimal = this.learner.getOptimalStrategy(taskType);
    if (!optimal) return null;

    return {
      taskType,
      recommendedParameters: optimal.strategy,
      expectedSuccessRate: (optimal.successRate * 100).toFixed(1) + '%',
      basedOnSamples: optimal.sampleCount
    };
  }

  getReport() {
    return this.learner.generateReport();
  }
}

// ═══════════════════════════════════════════════════════════════════
// CLI 入口
// ═══════════════════════════════════════════════════════════════════
async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
╔══════════════════════════════════════════════════════════════════╗
║     KIMICLAW Experience Learner v1.0                             ║
║     阶段4: 经验学习闭环                                           ║
╚══════════════════════════════════════════════════════════════════╝

用法:
  node ExperienceLearner.js [命令] [选项]

命令:
  report            生成学习报告
  stats             查看统计信息
  optimize          手动运行优化
  export            导出经验数据

选项:
  --verbose, -v     详细输出
  --help, -h        显示帮助

示例:
  node ExperienceLearner.js report
  node ExperienceLearner.js stats --verbose
`);
    return;
  }

  const command = args[0];
  const verbose = args.includes('--verbose') || args.includes('-v');

  const learner = new ExperienceLearner({ verbose });

  switch (command) {
    case 'report':
      console.log(JSON.stringify(learner.generateReport(), null, 2));
      break;
    case 'stats':
      console.log(JSON.stringify(learner.getStats(), null, 2));
      break;
    case 'optimize':
      const results = learner.runOptimization();
      console.log('优化结果:', JSON.stringify(results, null, 2));
      break;
    case 'export':
      const exportPath = join(__dirname, 'memory', `experiences-export-${Date.now()}.json`);
      writeFileSync(exportPath, JSON.stringify(learner.experiences, null, 2));
      console.log(`已导出到: ${exportPath}`);
      break;
    default:
      console.log('未知命令:', command);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}

export default ExperienceLearner;
