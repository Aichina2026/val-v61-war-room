#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════
 * KIMICLAW Autonomous Planner v1.0
 * 自主决策层: 让系统自己判断用什么工作流
 * 
 * 核心能力:
 * - 需求复杂度分析 (0-1分数)
 * - 工作流自动选择 (single/4ai/zero)
 * - 工具自主调用决策
 * - 执行策略动态调整
 * 
 * 决策矩阵:
 * 复杂度 0.0-0.3 → 单模型快速响应 (Fast Mode)
 * 复杂度 0.3-0.7 → 4AI并行推演 (Standard Mode)
 * 复杂度 0.7-1.0 → 零错误对抗审查 (Strict Mode)
 * ═══════════════════════════════════════════════════════════════════
 */

import { readFileSync, existsSync } from 'fs';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ═══════════════════════════════════════════════════════════════════
// 复杂度分析关键词库
// ═══════════════════════════════════════════════════════════════════
const COMPLEXITY_INDICATORS = {
  // 简单任务指标 (低分)
  simple: {
    keywords: ['hello', 'hi', '你好', '简单', '一句话', '简述', '举例', '什么是', '介绍'],
    patterns: [/^\w+\?$/i, /^(what|how|why|when|where)\s/i],
    score: -0.2
  },
  
  // 中等复杂度指标
  medium: {
    keywords: ['设计', '实现', '编写', '创建', '开发', '模块', '组件', 'API', '函数', '类'],
    patterns: [/\b(module|component|api|function|class)\b/i],
    score: 0.1
  },
  
  // 高复杂度指标
  high: {
    keywords: ['系统', '架构', '框架', '平台', '集成', '优化', '重构', '多轮', '验证', '生产级'],
    patterns: [/\b(system|architecture|framework|platform|integration|optimization)\b/i],
    score: 0.3
  },
  
  // 极高复杂度指标 (严格模式触发)
  critical: {
    keywords: ['零错误', '严格', '安全', '认证', '加密', '金融', '医疗', '核心', '关键任务', '高可用', '审计', '加密算法'],
    patterns: [/\b(zero.error|security|authentication|encryption|financial|medical|critical|audit)\b/i],
    score: 0.6
  }
};

// 工具触发关键词
const TOOL_TRIGGERS = {
  web_search: {
    keywords: ['最新', '2026', '搜索', '查找', 'news', 'latest', 'search', '查找', '查询'],
    confidence: 0.7
  },
  code_interpreter: {
    keywords: ['计算', '数学', '预测', '统计', 'calculate', 'math', 'predict', 'statistics'],
    confidence: 0.8
  },
  file_access: {
    keywords: ['文件', '读取', '保存', 'file', 'read', 'save', 'load'],
    confidence: 0.9
  },
  database_query: {
    keywords: ['数据库', 'SQL', '查询', '数据', 'database', 'sql', 'query'],
    confidence: 0.9
  }
};

// ═══════════════════════════════════════════════════════════════════
// 自主规划器类
// ═══════════════════════════════════════════════════════════════════
export class AutonomousPlanner {
  constructor(config = {}) {
    this.config = {
      complexityThreshold: {
        simple: 0.3,
        standard: 0.7,
        strict: 1.0
      },
      enableToolUse: true,
      enableReflection: true,
      verbose: config.verbose || false,
      ...config
    };
    
    this.executionHistory = [];
  }

  /**
   * 分析需求复杂度
   * @param {string} prompt - 用户输入
   * @returns {Object} 复杂度分析结果
   */
  analyzeComplexity(prompt) {
    const lowerPrompt = prompt.toLowerCase();
    let score = 0.3; // 基础分
    const factors = [];

    // 1. 长度因子
    const length = prompt.length;
    if (length < 50) {
      score -= 0.1;
      factors.push({ name: '长度短', impact: -0.1 });
    } else if (length > 500) {
      score += 0.15;
      factors.push({ name: '长度长', impact: 0.15 });
    }

    // 2. 关键词分析
    for (const [level, data] of Object.entries(COMPLEXITY_INDICATORS)) {
      let matched = 0;
      
      // 关键词匹配
      for (const kw of data.keywords) {
        if (lowerPrompt.includes(kw.toLowerCase())) {
          matched++;
        }
      }
      
      // 正则匹配
      for (const pattern of data.patterns) {
        if (pattern.test(prompt)) {
          matched++;
        }
      }
      
      if (matched > 0) {
        const impact = data.score * Math.min(matched / 3, 1); // 最多算3个匹配
        score += impact;
        factors.push({ name: `${level}指标`, impact, matched });
      }
    }

    // 3. 结构化程度
    const structureIndicators = [
      /\d+\./,           // 数字列表
      /[-*]\s/,          // 符号列表
      /```/,             // 代码块
      /\n{2,}/           // 多段落
    ];
    let structureScore = 0;
    for (const pattern of structureIndicators) {
      if (pattern.test(prompt)) structureScore += 0.05;
    }
    score += structureScore;
    if (structureScore > 0) {
      factors.push({ name: '结构化输入', impact: structureScore });
    }

    // 4. 多任务检测
    const taskIndicators = ['和', '以及', '同时', '分别', '第一步', '然后', '最后', 'and then', 'next', 'finally'];
    let taskCount = 0;
    for (const indicator of taskIndicators) {
      if (lowerPrompt.includes(indicator)) taskCount++;
    }
    if (taskCount >= 2) {
      score += 0.15;
      factors.push({ name: '多任务', impact: 0.15, count: taskCount });
    }

    // 归一化到 0-1
    score = Math.max(0, Math.min(1, score));

    return {
      score,
      level: this.getComplexityLevel(score),
      factors,
      indicators: {
        length,
        keywordMatches: factors.filter(f => f.name.includes('指标')).length,
        structureScore,
        taskCount
      }
    };
  }

  /**
   * 获取复杂度等级
   */
  getComplexityLevel(score) {
    if (score < this.config.complexityThreshold.simple) return 'simple';
    if (score < this.config.complexityThreshold.standard) return 'medium';
    if (score < this.config.complexityThreshold.strict) return 'high';
    return 'critical';
  }

  /**
   * 分析需要使用的工具
   */
  analyzeToolNeeds(prompt) {
    const lowerPrompt = prompt.toLowerCase();
    const tools = [];

    for (const [toolName, config] of Object.entries(TOOL_TRIGGERS)) {
      let matched = 0;
      for (const kw of config.keywords) {
        if (lowerPrompt.includes(kw.toLowerCase())) matched++;
      }
      
      if (matched > 0) {
        const confidence = Math.min(config.confidence, 0.3 + matched * 0.2);
        tools.push({
          name: toolName,
          confidence,
          reason: `匹配 ${matched} 个关键词`
        });
      }
    }

    return tools.sort((a, b) => b.confidence - a.confidence);
  }

  /**
   * 规划执行策略
   */
  async plan(prompt, context = {}) {
    const startTime = Date.now();
    
    // 1. 复杂度分析
    const complexity = this.analyzeComplexity(prompt);
    
    // 2. 工具需求分析
    const tools = this.analyzeToolNeeds(prompt);
    
    // 3. 选择工作流
    const workflow = this.selectWorkflow(complexity, tools);
    
    // 4. 选择模式
    const mode = this.selectMode(complexity);
    
    // 5. 构建执行计划
    const plan = {
      prompt,
      analysis: {
        complexity,
        tools,
        estimatedTokens: this.estimateTokens(prompt, complexity),
        estimatedCost: this.estimateCost(complexity, workflow)
      },
      strategy: {
        workflow: workflow.type,
        mode,
        timeout: workflow.timeout,
        retries: workflow.retries,
        useTools: tools.filter(t => t.confidence > 0.7).map(t => t.name)
      },
      reasoning: this.generateReasoning(complexity, workflow, tools),
      timestamp: new Date().toISOString()
    };

    if (this.config.verbose) {
      console.log('\n📊 自主规划结果:');
      console.log(`   复杂度: ${complexity.score.toFixed(2)} (${complexity.level})`);
      console.log(`   工作流: ${workflow.type}`);
      console.log(`   模式: ${mode}`);
      console.log(`   建议工具: ${plan.strategy.useTools.join(', ') || '无'}`);
      console.log(`   预估成本: $${plan.analysis.estimatedCost.toFixed(3)}`);
    }

    return plan;
  }

  /**
   * 选择工作流
   */
  selectWorkflow(complexity, tools) {
    const level = complexity.level;
    const score = complexity.score;
    
    // 严格模式触发条件: 明确critical级别 或 高分+严格关键词
    if (level === 'critical' || score >= 0.65) {
      return {
        type: 'zero',
        description: '零错误系统 - 对抗审查',
        timeout: 120000,
        retries: 3,
        reason: '高复杂度/关键任务，需要严格验证'
      };
    }
    
    // 需要搜索工具时，使用4AI以获得更好效果
    if (tools.some(t => t.name === 'web_search' && t.confidence > 0.7)) {
      return {
        type: '4ai',
        description: '4AI并行推演 - 多角色协作',
        timeout: 90000,
        retries: 2,
        reason: '需要搜索/多源信息整合'
      };
    }
    
    // 中等复杂度用4AI
    if (level === 'medium' || level === 'high') {
      return {
        type: '4ai',
        description: '4AI并行推演 - 多角色协作',
        timeout: 60000,
        retries: 2,
        reason: '中等复杂度，需要多角色协作'
      };
    }
    
    // 简单任务用单模型
    return {
      type: 'single',
      description: '单模型快速响应',
      timeout: 30000,
      retries: 1,
      reason: '简单任务，快速响应优先'
    };
  }

  /**
   * 选择执行模式
   */
  selectMode(complexity) {
    const level = complexity.level;
    if (level === 'critical') return 'strict';
    if (level === 'high') return 'standard';
    return 'fast';
  }

  /**
   * 预估Token数
   */
  estimateTokens(prompt, complexity) {
    const baseTokens = prompt.length / 4;
    const multiplier = {
      simple: 2,
      medium: 4,
      high: 6,
      critical: 8
    }[complexity.level];
    return Math.floor(baseTokens * multiplier);
  }

  /**
   * 预估成本 (USD)
   */
  estimateCost(complexity, workflow) {
    const tokenCostPer1M = {
      single: 3,    // GPT-4o级别
      '4ai': 19,    // 4角色并行
      zero: 35,     // 多轮对抗
      codex: 25     // OMC模式
    };
    
    const estimatedTokens = this.estimateTokens('', complexity);
    return (estimatedTokens / 1000000) * tokenCostPer1M[workflow.type];
  }

  /**
   * 生成决策理由
   */
  generateReasoning(complexity, workflow, tools) {
    const reasons = [
      `复杂度评分 ${complexity.score.toFixed(2)} 属于"${complexity.level}"级别`,
      `选择 ${workflow.type} 工作流: ${workflow.reason}`,
    ];
    
    if (tools.length > 0) {
      const highConfTools = tools.filter(t => t.confidence > 0.7);
      if (highConfTools.length > 0) {
        reasons.push(`检测到可能需要工具: ${highConfTools.map(t => t.name).join(', ')}`);
      }
    }
    
    return reasons;
  }

  /**
   * 执行规划的任务
   */
  async execute(plan, options = {}) {
    const { workflow, mode, timeout, retries } = plan.strategy;
    const { prompt } = plan;

    console.log(`\n🚀 启动自主执行`);
    console.log(`   工作流: ${workflow} | 模式: ${mode} | 超时: ${timeout}ms\n`);

    const startTime = Date.now();
    let result;

    try {
      switch (workflow) {
        case 'single':
          result = await this.executeSingle(prompt, mode, timeout);
          break;
        case '4ai':
          result = await this.execute4AI(prompt, mode, timeout);
          break;
        case 'zero':
          result = await this.executeZeroError(prompt, mode, timeout);
          break;
        case 'codex':
          result = await this.executeCodex(prompt, mode, timeout);
          break;
        default:
          throw new Error(`未知工作流: ${workflow}`);
      }

      // 记录执行历史
      this.executionHistory.push({
        plan,
        result: { success: true },
        duration: Date.now() - startTime,
        timestamp: new Date().toISOString()
      });

      return {
        success: true,
        plan,
        output: result,
        duration: Date.now() - startTime
      };

    } catch (error) {
      this.executionHistory.push({
        plan,
        result: { success: false, error: error.message },
        duration: Date.now() - startTime,
        timestamp: new Date().toISOString()
      });

      throw error;
    }
  }

  /**
   * 执行单模型模式
   */
  async executeSingle(prompt, mode, timeout) {
    // 这里可以集成到现有的统一API调用
    console.log(`[Single Mode] 使用 GPT-4o 快速响应`);
    
    // 实际实现需要调用API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(`[单模型响应] 对于: "${prompt.slice(0, 50)}..."\n\n这是一个简单查询，使用单模型快速响应。`);
      }, 1000);
    });
  }

  /**
   * 执行4AI工作流
   */
  async execute4AI(prompt, mode, timeout) {
    const scriptPath = join(__dirname, 'parallel_ai_skill_optimized.js');
    
    if (!existsSync(scriptPath)) {
      throw new Error(`4AI脚本不存在: ${scriptPath}`);
    }

    return new Promise((resolve, reject) => {
      const child = spawn('node', [scriptPath, prompt], {
        stdio: 'pipe',
        env: {
          ...process.env,
          UNIFIED_MODE: mode,
          UNIFIED_TIMEOUT: timeout.toString()
        }
      });

      let output = '';
      child.stdout?.on('data', (data) => output += data.toString());
      child.stderr?.on('data', (data) => console.error(data.toString()));

      child.on('close', (code) => {
        if (code === 0) {
          resolve(output);
        } else {
          reject(new Error(`4AI进程退出码: ${code}`));
        }
      });

      setTimeout(() => {
        child.kill();
        reject(new Error(`4AI执行超时`));
      }, timeout);
    });
  }

  /**
   * 执行零错误系统
   */
  async executeZeroError(prompt, mode, timeout) {
    const scriptPath = join(__dirname, 'zero_error_system_optimized.cjs');
    
    if (!existsSync(scriptPath)) {
      throw new Error(`零错误脚本不存在: ${scriptPath}`);
    }

    return new Promise((resolve, reject) => {
      const child = spawn('node', [scriptPath, prompt], {
        stdio: 'pipe',
        env: {
          ...process.env,
          ZERO_ERROR_ROUNDS: mode === 'strict' ? '3' : '2',
          UNIFIED_TIMEOUT: timeout.toString()
        }
      });

      let output = '';
      child.stdout?.on('data', (data) => output += data.toString());
      child.stderr?.on('data', (data) => console.error(data.toString()));

      child.on('close', (code) => {
        if (code === 0) {
          resolve(output);
        } else {
          reject(new Error(`零错误进程退出码: ${code}`));
        }
      });

      setTimeout(() => {
        child.kill();
        reject(new Error(`零错误执行超时`));
      }, timeout);
    });
  }

  /**
   * 执行oh-my-codex
   */
  async executeCodex(prompt, mode, timeout) {
    console.log(`[OMC Mode] 调用oh-my-codex工作流`);
    // 简化实现，实际集成需要更多代码
    return `[OMC响应] 对于: "${prompt.slice(0, 50)}..."\n\nOMC工作流执行完成。`;
  }

  /**
   * 获取执行历史
   */
  getExecutionHistory() {
    return this.executionHistory;
  }

  /**
   * 学习反馈 (用于持续优化)
   */
  learn(task, result, feedback) {
    // 记录成功/失败模式，用于未来优化决策
    this.executionHistory.push({
      type: 'feedback',
      task,
      result,
      feedback,
      timestamp: new Date().toISOString()
    });
  }
}

// ═══════════════════════════════════════════════════════════════════
// CLI 入口
// ═══════════════════════════════════════════════════════════════════
async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
╔══════════════════════════════════════════════════════════════════╗
║     KIMICLAW Autonomous Planner v1.0                             ║
║     自主决策层 - 让系统自己判断用什么工作流                         ║
╚══════════════════════════════════════════════════════════════════╝

用法:
  node AutonomousPlanner.js "你的需求" [选项]

选项:
  --verbose, -v     详细输出决策过程
  --dry-run         只分析，不执行
  --help, -h        显示帮助

示例:
  node AutonomousPlanner.js "什么是斐波那契数列？"
  node AutonomousPlanner.js "设计一个微服务架构" --verbose
  node AutonomousPlanner.js "生成零错误的安全认证代码" --verbose

决策逻辑:
  复杂度 0.0-0.3  → 单模型快速响应 (Fast)
  复杂度 0.3-0.7  → 4AI并行推演 (Standard)
  复杂度 0.7-1.0  → 零错误对抗审查 (Strict)
`);
    return;
  }

  const prompt = args[0];
  const verbose = args.includes('--verbose') || args.includes('-v');
  const dryRun = args.includes('--dry-run');

  const planner = new AutonomousPlanner({ verbose });
  
  console.log(`\n📝 需求: ${prompt}`);
  
  const plan = await planner.plan(prompt);
  
  if (dryRun) {
    console.log('\n📋 执行计划 (Dry Run):');
    console.log(JSON.stringify(plan, null, 2));
    return;
  }

  const result = await planner.execute(plan);
  
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('✅ 执行完成');
  console.log(`⏱️  耗时: ${(result.duration / 1000).toFixed(2)}s`);
  console.log('═══════════════════════════════════════════════════════════════\n');
  
  console.log(result.output);
}

// 如果直接运行此文件
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}

export default AutonomousPlanner;
