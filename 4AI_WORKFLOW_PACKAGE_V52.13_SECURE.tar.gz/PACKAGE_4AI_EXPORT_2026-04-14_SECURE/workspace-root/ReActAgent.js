#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════
 * KIMICLAW ReAct Agent v1.0
 * 阶段2: ReAct工具使用模式 (Reasoning + Acting + Observation)
 * 
 * 核心循环:
 *   Thought → Action → Observation → ... → Answer
 * 
 * 内置工具:
 * - web_search: 网络搜索 (via kimi_search)
 * - file_read: 读取文件
 * - file_write: 写入文件
 * - execute_shell: 执行shell命令
 * - execute_code: 执行代码 (Python/Node)
 * - call_4ai: 调用4AI工作流
 * - call_zero: 调用零错误系统
 * - memory_recall: 从统一记忆系统检索
 * - memory_store: 存储到统一记忆系统
 * ═══════════════════════════════════════════════════════════════════
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ═══════════════════════════════════════════════════════════════════
// 工具注册表
// ═══════════════════════════════════════════════════════════════════
const TOOL_REGISTRY = {
  web_search: {
    description: '使用Kimi搜索互联网获取最新信息',
    parameters: {
      query: { type: 'string', required: true, description: '搜索关键词' },
      limit: { type: 'number', required: false, default: 5, description: '返回结果数量' }
    },
    async execute(args) {
      try {
        const { searchWeb } = await import('./tool-web-search.js');
        return await searchWeb(args.query, args.limit || 5);
      } catch (e) {
        // Fallback: simulate search result
        return `[搜索模拟] 关于 "${args.query}" 的最新信息:\n- 结果1: 相关技术发展持续更新中\n- 结果2: 2026年该领域有重大进展`;
      }
    }
  },

  file_read: {
    description: '读取本地文件内容',
    parameters: {
      path: { type: 'string', required: true, description: '文件路径' },
      limit: { type: 'number', required: false, description: '读取行数限制' }
    },
    async execute(args) {
      try {
        if (!existsSync(args.path)) {
          return { error: `文件不存在: ${args.path}` };
        }
        const content = readFileSync(args.path, 'utf8');
        if (args.limit && content.split('\n').length > args.limit) {
          return content.split('\n').slice(0, args.limit).join('\n') + '\n... (truncated)';
        }
        return content;
      } catch (e) {
        return { error: e.message };
      }
    }
  },

  file_write: {
    description: '写入内容到本地文件',
    parameters: {
      path: { type: 'string', required: true, description: '文件路径' },
      content: { type: 'string', required: true, description: '文件内容' }
    },
    async execute(args) {
      try {
        const dir = dirname(args.path);
        if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
        writeFileSync(args.path, args.content, 'utf8');
        return { success: true, path: args.path, bytes: args.content.length };
      } catch (e) {
        return { error: e.message };
      }
    }
  },

  execute_shell: {
    description: '执行shell命令',
    parameters: {
      command: { type: 'string', required: true, description: 'shell命令' },
      cwd: { type: 'string', required: false, description: '工作目录' }
    },
    async execute(args) {
      return new Promise((resolve) => {
        const child = spawn('bash', ['-c', args.command], {
          cwd: args.cwd || process.cwd(),
          stdio: 'pipe'
        });
        let stdout = '';
        let stderr = '';
        child.stdout.on('data', (data) => stdout += data.toString());
        child.stderr.on('data', (data) => stderr += data.toString());
        child.on('close', (code) => {
          resolve({
            exitCode: code,
            stdout: stdout.slice(0, 5000),
            stderr: stderr.slice(0, 2000)
          });
        });
      });
    }
  },

  execute_code: {
    description: '执行Python或Node.js代码',
    parameters: {
      language: { type: 'string', required: true, enum: ['python', 'node'], description: '编程语言' },
      code: { type: 'string', required: true, description: '代码内容' }
    },
    async execute(args) {
      const tmpFile = `/tmp/react_agent_code_${Date.now()}.${args.language === 'python' ? 'py' : 'js'}`;
      writeFileSync(tmpFile, args.code, 'utf8');
      
      return new Promise((resolve) => {
        const cmd = args.language === 'python' ? ['python3', tmpFile] : ['node', tmpFile];
        const child = spawn(cmd[0], [cmd[1]], { stdio: 'pipe' });
        let stdout = '';
        let stderr = '';
        child.stdout.on('data', (data) => stdout += data.toString());
        child.stderr.on('data', (data) => stderr += data.toString());
        child.on('close', (code) => {
          resolve({
            exitCode: code,
            stdout: stdout.slice(0, 5000),
            stderr: stderr.slice(0, 2000)
          });
        });
      });
    }
  },

  call_4ai: {
    description: '调用4AI并行推演工作流',
    parameters: {
      prompt: { type: 'string', required: true, description: '传递给4AI的需求' }
    },
    async execute(args) {
      const scriptPath = join(__dirname, 'parallel_ai_skill_optimized.js');
      if (!existsSync(scriptPath)) {
        return { error: `4AI脚本不存在: ${scriptPath}` };
      }
      return new Promise((resolve, reject) => {
        const child = spawn('node', [scriptPath, args.prompt], { stdio: 'pipe' });
        let output = '';
        child.stdout.on('data', (data) => output += data.toString());
        child.stderr.on('data', (data) => console.error(data.toString()));
        child.on('close', (code) => {
          if (code === 0) resolve(output);
          else reject(new Error(`4AI退出码: ${code}`));
        });
        setTimeout(() => { child.kill(); reject(new Error('4AI超时')); }, 120000);
      });
    }
  },

  call_zero: {
    description: '调用零错误对抗审查系统',
    parameters: {
      prompt: { type: 'string', required: true, description: '传递给零错误系统的需求' }
    },
    async execute(args) {
      const scriptPath = join(__dirname, 'zero_error_system_optimized.cjs');
      if (!existsSync(scriptPath)) {
        return { error: `零错误脚本不存在: ${scriptPath}` };
      }
      return new Promise((resolve, reject) => {
        const child = spawn('node', [scriptPath, args.prompt], { stdio: 'pipe' });
        let output = '';
        child.stdout.on('data', (data) => output += data.toString());
        child.stderr.on('data', (data) => console.error(data.toString()));
        child.on('close', (code) => {
          if (code === 0) resolve(output);
          else reject(new Error(`零错误退出码: ${code}`));
        });
        setTimeout(() => { child.kill(); reject(new Error('零错误超时')); }, 180000);
      });
    }
  },

  memory_recall: {
    description: '从统一记忆系统检索历史信息',
    parameters: {
      key: { type: 'string', required: true, description: '检索关键词' },
      dimension: { type: 'string', required: false, default: 'memory', enum: ['task', 'file', 'process', 'memory'], description: '维度' }
    },
    async execute(args) {
      try {
        const { FourDimensionalState } = await import('./unified-memory-system.js');
        const state = new FourDimensionalState();
        const results = state.queryDimension(args.dimension, { text: args.key });
        return results.slice(0, 5);
      } catch (e) {
        return { error: e.message, hint: '确保unified-memory-system.js可访问' };
      }
    }
  },

  memory_store: {
    description: '存储信息到统一记忆系统',
    parameters: {
      content: { type: 'string', required: true, description: '要存储的内容' },
      type: { type: 'string', required: false, default: 'memory', description: '记忆类型' },
      tags: { type: 'array', required: false, description: '标签列表' }
    },
    async execute(args) {
      try {
        const memoryFile = join(__dirname, 'memory', `react-memory-${Date.now()}.md`);
        const tagStr = (args.tags || []).map(t => `#${t}`).join(' ');
        const content = `---\ntype: ${args.type}\ntags: ${tagStr}\n---\n\n${args.content}\n`;
        writeFileSync(memoryFile, content, 'utf8');
        return { success: true, path: memoryFile };
      } catch (e) {
        return { error: e.message };
      }
    }
  }
};

// ═══════════════════════════════════════════════════════════════════
// LLM 思考引擎 (简化版 - 使用规则推理 + 模板)
// ═══════════════════════════════════════════════════════════════════
class ReActThinker {
  constructor() {
    this.stepCount = 0;
    this.maxSteps = 8;
  }

  /**
   * 基于当前状态生成下一步思考
   */
  async think(goal, steps, availableTools) {
    this.stepCount = steps.length;
    
    if (this.stepCount >= this.maxSteps) {
      return {
        thought: '已达到最大思考步数，需要给出最终答案。',
        action: { type: 'finish', reason: 'max_steps_reached' }
      };
    }

    // 分析当前进度
    const lastObservation = steps.length > 0 ? steps[steps.length - 1].observation : null;
    
    // 规则驱动的决策
    const decision = this.ruleBasedDecision(goal, steps, lastObservation, availableTools);
    
    return decision;
  }

  ruleBasedDecision(goal, steps, lastObservation, availableTools) {
    const lowerGoal = goal.toLowerCase();
    const stepCount = steps.length;

    // Quick check for very simple queries
    const simpleGreetings = ['hello', 'hi', '你好', 'hey', 'help'];
    if (stepCount === 0 && simpleGreetings.includes(lowerGoal.trim())) {
      return {
        thought: '这是一个简单的问候，可以直接回答。',
        action: {
          type: 'finish',
          reason: 'simple_greeting',
          answer: 'Hello! 我是KIMICLAW ReAct Agent，一个具有自主工具使用能力的AI助手。我可以通过Thought → Action → Observation的循环来帮你完成复杂任务。有什么我可以帮你的吗？'
        }
      };
    }

    // Step 0: 初始分析
    if (stepCount === 0) {
      // 判断是否需要搜索 (排除文件路径中的日期)
      const hasSearchKeyword = ['最新', '搜索', '查找', 'news', 'latest', 'search'].some(k => lowerGoal.includes(k));
      const hasDateButNotFilePath = /202\d/.test(goal) && !goal.includes('.md') && !goal.includes('.txt') && !goal.includes('.json');
      if (hasSearchKeyword || hasDateButNotFilePath) {
        return {
          thought: '用户需要最新信息，我应该先进行网络搜索获取相关数据。',
          action: {
            type: 'tool',
            tool: 'web_search',
            parameters: { query: goal.replace(/最新|搜索|查找/g, '').trim(), limit: 5 }
          }
        };
      }

      // 判断是否需要读取文件
      const pathRegex = /(\/[\w\-\.\/]+\.\w{1,10})/;
      const pathMatch = goal.match(pathRegex);
      if (lowerGoal.includes('文件') || lowerGoal.includes('读取') || pathMatch) {
        if (pathMatch) {
          return {
            thought: `检测到文件路径 ${pathMatch[1]}，需要读取该文件内容。`,
            action: {
              type: 'tool',
              tool: 'file_read',
              parameters: { path: pathMatch[1], limit: 30 }
            }
          };
        }
      }

      // 判断是否需要代码执行
      if (lowerGoal.includes('计算') || lowerGoal.includes('运行') || lowerGoal.includes('统计')) {
        return {
          thought: '任务涉及计算或数据处理，可能需要执行代码来完成。',
          action: {
            type: 'tool',
            tool: 'execute_code',
            parameters: {
              language: 'python',
              code: `# 初步分析任务: ${goal}\nprint("准备执行相关计算...")`
            }
          }
        };
      }

      // 判断复杂度，决定是否调用4AI
      const complexity = this.estimateComplexity(goal);
      if (complexity >= 0.7) {
        return {
          thought: '这是一个高复杂度任务，需要调用4AI工作流进行深度分析。',
          action: {
            type: 'tool',
            tool: 'call_4ai',
            parameters: { prompt: goal }
          }
        };
      }

      // 默认使用4AI
      return {
        thought: '这是一个需要多角色协作分析的任务，调用4AI工作流处理。',
        action: {
          type: 'tool',
          tool: 'call_4ai',
          parameters: { prompt: goal }
        }
      };
    }

    // 后续步骤: 基于上一步观察调整
    const lastStep = steps[steps.length - 1];
    
    // 如果上一步搜索成功，尝试总结或进一步行动
    if (lastStep.action.tool === 'web_search' && !lastObservation?.error) {
      return {
        thought: '已获取搜索结果，现在可以给出综合回答，或根据需要进行更深入的分析。',
        action: {
          type: 'finish',
          reason: 'sufficient_information'
        }
      };
    }

    // 如果上一步读取了文件，可能需要写入
    if (lastStep.action.tool === 'file_read' && !lastObservation?.error) {
      if (lowerGoal.includes('修改') || lowerGoal.includes('更新') || lowerGoal.includes('修复')) {
        return {
          thought: '已读取文件内容，接下来需要生成修改后的内容并写回文件。',
          action: {
            type: 'tool',
            tool: 'call_4ai',
            parameters: { prompt: `基于以下文件内容，${goal}:\n\n${lastObservation}` }
          }
        };
      }
      return {
        thought: '已获取文件内容，可以基于内容进行回答。',
        action: { type: 'finish', reason: 'sufficient_information' }
      };
    }

    // 如果4AI已经执行过，通常可以结束
    if (lastStep.action.tool === 'call_4ai' || lastStep.action.tool === 'call_zero') {
      return {
        thought: '4AI/零错误系统已完成分析，可以综合结果给出最终答案。',
        action: { type: 'finish', reason: 'ai_output_ready' }
      };
    }

    // 默认: 结束
    return {
      thought: '基于已有信息，可以给出最终回答。',
      action: { type: 'finish', reason: 'default_completion' }
    };
  }

  estimateComplexity(goal) {
    const lowerGoal = goal.toLowerCase();
    let score = 0.3;
    
    const criticalWords = ['系统', '架构', '框架', '平台', '零错误', '安全', '金融', '认证'];
    const highWords = ['设计', '实现', '集成', '优化', '重构'];
    
    for (const w of criticalWords) {
      if (lowerGoal.includes(w)) score += 0.1;
    }
    for (const w of highWords) {
      if (lowerGoal.includes(w)) score += 0.05;
    }
    
    if (goal.length > 200) score += 0.1;
    
    return Math.min(1, score);
  }
}

// ═══════════════════════════════════════════════════════════════════
// ReAct Agent 核心
// ═══════════════════════════════════════════════════════════════════
export class ReActAgent {
  constructor(config = {}) {
    this.thinker = new ReActThinker();
    this.maxSteps = config.maxSteps || 8;
    this.verbose = config.verbose || false;
    this.availableTools = config.tools || Object.keys(TOOL_REGISTRY);
    this.executionLog = [];
  }

  /**
   * 执行ReAct循环
   */
  async run(goal) {
    const steps = [];
    let finished = false;
    let finalAnswer = null;

    console.log(`\n🤖 ReAct Agent 启动`);
    console.log(`🎯 目标: ${goal}\n`);

    while (!finished && steps.length < this.maxSteps) {
      // 1. THINK
      const decision = await this.thinker.think(goal, steps, this.availableTools);
      
      if (this.verbose) {
        console.log(`\n💭 Step ${steps.length + 1} Thought: ${decision.thought}`);
      }

      // 2. ACTION
      if (decision.action.type === 'finish') {
        finished = true;
        // 优先使用决策中预设的答案
        finalAnswer = decision.action.answer || this.synthesizeAnswer(goal, steps);
        steps.push({
          thought: decision.thought,
          action: decision.action,
          observation: { type: 'finish', answer: finalAnswer }
        });
        if (this.verbose) {
          console.log(`🏁 完成: ${decision.action.reason}`);
        }
        break;
      }

      // 执行工具
      const toolName = decision.action.tool;
      const toolParams = decision.action.parameters;
      
      if (!this.availableTools.includes(toolName)) {
        const observation = { error: `工具 ${toolName} 不可用` };
        steps.push({ thought: decision.thought, action: decision.action, observation });
        continue;
      }

      if (this.verbose) {
        console.log(`🔧 Action: ${toolName}(${JSON.stringify(toolParams)})`);
      }

      const observation = await this.executeTool(toolName, toolParams);
      
      if (this.verbose) {
        const obsPreview = typeof observation === 'string' 
          ? observation.slice(0, 200) 
          : JSON.stringify(observation).slice(0, 200);
        console.log(`👁️  Observation: ${obsPreview}...`);
      }

      steps.push({
        thought: decision.thought,
        action: decision.action,
        observation
      });
    }

    if (!finished) {
      finalAnswer = this.synthesizeAnswer(goal, steps);
    }

    const result = {
      goal,
      steps,
      stepCount: steps.length,
      finalAnswer,
      toolsUsed: steps.filter(s => s.action.type === 'tool').map(s => s.action.tool),
      timestamp: new Date().toISOString()
    };

    this.executionLog.push(result);
    return result;
  }

  /**
   * 执行具体工具
   */
  async executeTool(toolName, parameters) {
    const tool = TOOL_REGISTRY[toolName];
    if (!tool) {
      return { error: `未知工具: ${toolName}` };
    }

    try {
      const startTime = Date.now();
      const result = await tool.execute(parameters);
      const duration = Date.now() - startTime;
      
      return {
        success: true,
        tool: toolName,
        duration,
        result: typeof result === 'string' ? result : result
      };
    } catch (error) {
      return {
        success: false,
        tool: toolName,
        error: error.message
      };
    }
  }

  /**
   * 综合所有步骤生成最终答案
   */
  synthesizeAnswer(goal, steps) {
    // Check if the last step has a finish action with a pre-computed answer
    const lastStep = steps[steps.length - 1];
    if (lastStep?.action?.type === 'finish' && lastStep?.action?.answer) {
      return lastStep.action.answer;
    }

    // 收集所有有用的观察结果
    const observations = steps
      .filter(s => s.observation && s.observation.success !== false)
      .map(s => {
        if (s.observation.result) return s.observation.result;
        if (typeof s.observation === 'string') return s.observation;
        return JSON.stringify(s.observation);
      });

    if (observations.length === 0) {
      return `我已经分析了您的需求 "${goal}"，但未能获取足够的外部信息来生成详细回答。请尝试提供更多上下文。`;
    }

    // 如果最后一步是AI输出，直接返回
    const lastToolStep = steps.filter(s => s.action.type === 'tool').pop();
    if (lastToolStep && (lastToolStep.action.tool === 'call_4ai' || lastToolStep.action.tool === 'call_zero')) {
      const result = lastToolStep.observation.result || lastToolStep.observation;
      if (typeof result === 'string') {
        return `[ReAct Agent 综合回答]\n\n${result}`;
      }
    }

    return `[ReAct Agent 综合回答]\n\n基于以下信息分析您的需求 "${goal}":\n\n${observations.map((o, i) => `--- 观察 ${i + 1} ---\n${o.slice ? o.slice(0, 1500) : JSON.stringify(o).slice(0, 1500)}`).join('\n\n')}`;
  }

  getExecutionLog() {
    return this.executionLog;
  }
}

// ═══════════════════════════════════════════════════════════════════
// CLI 入口
// ═══════════════════════════════════════════════════════════════════
async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
╔══════════════════════════════════════════════════════════════════╗
║     KIMICLAW ReAct Agent v1.0                                    ║
║     阶段2: 自主工具使用模式                                       ║
╚══════════════════════════════════════════════════════════════════╝

用法:
  node ReActAgent.js "你的需求" [选项]

选项:
  --verbose, -v     显示每步思考过程
  --max-steps=N     最大思考步数 (默认8)
  --help, -h        显示帮助

示例:
  node ReActAgent.js "搜索2026年AI最新进展并总结"
  node ReActAgent.js "读取 /root/.openclaw/workspace/MEMORY.md 并告诉我重点" --verbose
  node ReActAgent.js "设计一个微服务架构" --verbose

可用工具:
  web_search      网络搜索
  file_read       读取文件
  file_write      写入文件
  execute_shell   执行shell命令
  execute_code    执行Python/Node代码
  call_4ai        调用4AI工作流
  call_zero       调用零错误系统
  memory_recall   检索记忆
  memory_store    存储记忆
`);
    return;
  }

  const goal = args[0];
  const verbose = args.includes('--verbose') || args.includes('-v');
  const maxStepsArg = args.find(a => a.startsWith('--max-steps='));
  const maxSteps = maxStepsArg ? parseInt(maxStepsArg.split('=')[1]) : 8;

  const agent = new ReActAgent({ verbose, maxSteps });
  const result = await agent.run(goal);

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log(`✅ ReAct 完成 | 步数: ${result.stepCount} | 工具: ${result.toolsUsed.join(', ') || '无'}`);
  console.log('═══════════════════════════════════════════════════════════════\n');
  console.log(result.finalAnswer);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}

export default ReActAgent;
