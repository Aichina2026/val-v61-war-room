#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════
 * KIMICLAW Agent Event Loop v1.0
 * 阶段3: 事件驱动循环 (7×24常驻，自主唤醒)
 * 
 * 核心能力:
 * - 事件队列 (优先级调度)
 * - 定时任务 (cron-like)
 * - 文件监控 (热重载/自动响应)
 * - 外部事件监听 (HTTP webhook / socket)
 * - 自主唤醒决策 (基于事件重要性)
 * - 与ReActAgent集成
 * ═══════════════════════════════════════════════════════════════════
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync, watch } from 'fs';
import { createServer } from 'http';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { spawn } from 'child_process';
import { EventEmitter } from 'events';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ═══════════════════════════════════════════════════════════════════
// 事件类型定义
// ═══════════════════════════════════════════════════════════════════
const EVENT_TYPES = {
  USER_REQUEST: 'user_request',      // 用户直接请求
  SCHEDULED: 'scheduled',            // 定时触发
  FILE_CHANGE: 'file_change',        // 文件变化
  WEBHOOK: 'webhook',                // 外部webhook
  SYSTEM_ALERT: 'system_alert',      // 系统告警
  HEARTBEAT: 'heartbeat',            // 心跳事件
  AUTO_WAKE: 'auto_wake',            // 自主唤醒
  REACT_RESULT: 'react_result'       // ReAct执行结果
};

const PRIORITY = {
  CRITICAL: 1,   // 系统告警、安全事件
  HIGH: 2,       // 用户请求、webhook
  MEDIUM: 3,     // 文件变化、ReAct结果
  LOW: 4,        // 定时任务、心跳
  IDLE: 5        // 自主探索
};

// ═══════════════════════════════════════════════════════════════════
// Agent事件
// ═══════════════════════════════════════════════════════════════════
export class AgentEvent {
  constructor(type, payload, priority = PRIORITY.MEDIUM, source = 'unknown') {
    this.id = `evt-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    this.type = type;
    this.payload = payload;
    this.priority = priority;
    this.source = source;
    this.createdAt = Date.now();
    this.processedAt = null;
    this.status = 'pending'; // pending | processing | completed | failed
  }
}

// ═══════════════════════════════════════════════════════════════════
// 优先级队列
// ═══════════════════════════════════════════════════════════════════
class PriorityQueue {
  constructor() {
    this.items = [];
  }

  enqueue(event) {
    // 去重检查: 相同类型+相似payload在5秒内只保留一个
    const isDuplicate = this.items.some(e => 
      e.type === event.type && 
      JSON.stringify(e.payload).slice(0, 100) === JSON.stringify(event.payload).slice(0, 100) &&
      Math.abs(e.createdAt - event.createdAt) < 5000
    );
    if (isDuplicate) return false;

    this.items.push(event);
    this.items.sort((a, b) => a.priority - b.priority);
    return true;
  }

  dequeue() {
    return this.items.shift();
  }

  peek() {
    return this.items[0];
  }

  size() {
    return this.items.length;
  }

  filter(predicate) {
    return this.items.filter(predicate);
  }
}

// ═══════════════════════════════════════════════════════════════════
// 定时任务调度器
// ═══════════════════════════════════════════════════════════════════
class Scheduler {
  constructor(eventLoop) {
    this.eventLoop = eventLoop;
    this.jobs = new Map();
    this.timers = new Map();
  }

  /**
   * 添加定时任务
   */
  addJob(id, config) {
    const job = {
      id,
      cron: config.cron,           // 简化cron: "*/5 * * * *" 或 "0 9 * * *"
      interval: config.interval,   // 毫秒 (优先于cron)
      handler: config.handler,     // 事件payload生成器
      priority: config.priority || PRIORITY.LOW,
      enabled: true,
      lastRun: null,
      runCount: 0
    };

    this.jobs.set(id, job);
    this.scheduleJob(job);
    console.log(`[Scheduler] 已添加任务: ${id}`);
    return job;
  }

  scheduleJob(job) {
    if (job.timer) clearTimeout(job.timer);

    let nextMs;
    if (job.interval) {
      nextMs = job.interval;
    } else if (job.cron) {
      nextMs = this.parseCron(job.cron);
    } else {
      nextMs = 60000; // 默认1分钟
    }

    job.timer = setTimeout(() => {
      if (!job.enabled) return;
      
      const payload = typeof job.handler === 'function' ? job.handler() : job.handler;
      const event = new AgentEvent(
        EVENT_TYPES.SCHEDULED,
        { jobId: job.id, ...payload },
        job.priority,
        `scheduler:${job.id}`
      );
      
      this.eventLoop.emit('event', event);
      job.lastRun = Date.now();
      job.runCount++;
      
      // 重新调度
      this.scheduleJob(job);
    }, nextMs);

    this.timers.set(job.id, job.timer);
  }

  parseCron(cronExpr) {
    // 简化版cron解析，仅支持常见模式
    if (cronExpr === '*/5 * * * *') return 5 * 60 * 1000;
    if (cronExpr === '*/15 * * * *') return 15 * 60 * 1000;
    if (cronExpr === '0 * * * *') return 60 * 60 * 1000;
    if (cronExpr === '0 */6 * * *') return 6 * 60 * 60 * 1000;
    if (cronExpr === '0 9 * * *') {
      const now = new Date();
      const next9am = new Date(now);
      next9am.setHours(9, 0, 0, 0);
      if (next9am <= now) next9am.setDate(next9am.getDate() + 1);
      return next9am - now;
    }
    return 60000; // 默认1分钟
  }

  removeJob(id) {
    if (this.timers.has(id)) {
      clearTimeout(this.timers.get(id));
      this.timers.delete(id);
    }
    this.jobs.delete(id);
  }

  listJobs() {
    return Array.from(this.jobs.values()).map(j => ({
      id: j.id,
      enabled: j.enabled,
      runCount: j.runCount,
      lastRun: j.lastRun
    }));
  }
}

// ═══════════════════════════════════════════════════════════════════
// 文件监控器
// ═══════════════════════════════════════════════════════════════════
class FileWatcher {
  constructor(eventLoop) {
    this.eventLoop = eventLoop;
    this.watchers = new Map();
  }

  watch(path, options = {}) {
    if (this.watchers.has(path)) return;

    const watcher = watch(path, { recursive: options.recursive || false }, (eventType, filename) => {
      const debounceKey = `${path}:${filename}`;
      if (this.debounceTimers?.has(debounceKey)) {
        clearTimeout(this.debounceTimers.get(debounceKey));
      }

      if (!this.debounceTimers) this.debounceTimers = new Map();
      
      const timer = setTimeout(() => {
        const agentEvent = new AgentEvent(
          EVENT_TYPES.FILE_CHANGE,
          {
            path,
            filename,
            eventType,
            filter: options.filter || null
          },
          options.priority || PRIORITY.MEDIUM,
          `watcher:${path}`
        );
        this.eventLoop.emit('event', agentEvent);
        this.debounceTimers.delete(debounceKey);
      }, options.debounce || 500);

      this.debounceTimers.set(debounceKey, timer);
    });

    this.watchers.set(path, watcher);
    console.log(`[FileWatcher] 已监控: ${path}`);
  }

  unwatch(path) {
    if (this.watchers.has(path)) {
      this.watchers.get(path).close();
      this.watchers.delete(path);
    }
  }
}

// ═══════════════════════════════════════════════════════════════════
// Webhook服务器
// ═══════════════════════════════════════════════════════════════════
class WebhookServer {
  constructor(eventLoop, port = 9876) {
    this.eventLoop = eventLoop;
    this.port = port;
    this.server = null;
  }

  start() {
    this.server = createServer((req, res) => {
      if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
        return;
      }

      if (req.url === '/webhook' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
          try {
            const payload = JSON.parse(body);
            const event = new AgentEvent(
              EVENT_TYPES.WEBHOOK,
              payload,
              payload.priority || PRIORITY.HIGH,
              `webhook:${req.socket.remoteAddress}`
            );
            this.eventLoop.emit('event', event);
            
            res.writeHead(202, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ accepted: true, eventId: event.id }));
          } catch (e) {
            res.writeHead(400);
            res.end(JSON.stringify({ error: 'Invalid JSON' }));
          }
        });
        return;
      }

      if (req.url === '/trigger' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
          try {
            const payload = JSON.parse(body);
            const event = new AgentEvent(
              EVENT_TYPES.USER_REQUEST,
              payload,
              payload.priority || PRIORITY.HIGH,
              'web_api'
            );
            this.eventLoop.emit('event', event);
            
            res.writeHead(202, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ accepted: true, eventId: event.id }));
          } catch (e) {
            res.writeHead(400);
            res.end(JSON.stringify({ error: 'Invalid JSON' }));
          }
        });
        return;
      }

      res.writeHead(404);
      res.end('Not Found');
    });

    this.server.listen(this.port, () => {
      console.log(`[WebhookServer] 监听端口: ${this.port}`);
      console.log(`  - POST /webhook   接收外部事件`);
      console.log(`  - POST /trigger   触发Agent任务`);
      console.log(`  - GET  /health    健康检查`);
    });
  }

  stop() {
    if (this.server) {
      this.server.close();
      console.log('[WebhookServer] 已停止');
    }
  }
}

// ═══════════════════════════════════════════════════════════════════
// Agent事件循环核心
// ═══════════════════════════════════════════════════════════════════
export class AgentEventLoop extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      maxConcurrency: config.maxConcurrency || 3,
      idleSleepMs: config.idleSleepMs || 1000,
      busySleepMs: config.busySleepMs || 100,
      enableWebhook: config.enableWebhook !== false,
      webhookPort: config.webhookPort || 9876,
      verbose: config.verbose || false,
      ...config
    };

    this.queue = new PriorityQueue();
    this.scheduler = new Scheduler(this);
    this.fileWatcher = new FileWatcher(this);
    this.webhook = new WebhookServer(this, this.config.webhookPort);
    
    this.running = false;
    this.processingCount = 0;
    this.stats = {
      totalEvents: 0,
      processedEvents: 0,
      failedEvents: 0,
      startTime: null
    };

    // 处理器注册表
    this.handlers = new Map();
    this.registerDefaultHandlers();

    // 绑定事件监听
    this.on('event', (event) => this.enqueue(event));
  }

  registerDefaultHandlers() {
    this.handlers.set(EVENT_TYPES.USER_REQUEST, async (event) => {
      console.log(`[Handler] 处理用户请求: ${event.payload.goal || event.payload.text || JSON.stringify(event.payload).slice(0, 100)}`);
      
      // 调用ReActAgent处理
      if (event.payload.goal || event.payload.text) {
        try {
          const { ReActAgent } = await import('./ReActAgent.js');
          const agent = new ReActAgent({ verbose: this.config.verbose });
          const result = await agent.run(event.payload.goal || event.payload.text);
          
          this.emit(EVENT_TYPES.REACT_RESULT, {
            eventId: event.id,
            success: true,
            result
          });
          
          return result;
        } catch (e) {
          console.error('[Handler] ReActAgent执行失败:', e.message);
          throw e;
        }
      }
      return { status: 'no_goal_provided' };
    });

    this.handlers.set(EVENT_TYPES.SCHEDULED, async (event) => {
      console.log(`[Handler] 执行定时任务: ${event.payload.jobId}`);
      
      switch (event.payload.jobId) {
        case 'heartbeat':
          return this.performHeartbeat();
        case 'memory_consolidation':
          return this.performMemoryConsolidation();
        case 'git_status_check':
          return this.performGitStatusCheck();
        default:
          if (event.payload.handler) {
            return await event.payload.handler(event);
          }
          return { status: 'unknown_job', jobId: event.payload.jobId };
      }
    });

    this.handlers.set(EVENT_TYPES.FILE_CHANGE, async (event) => {
      console.log(`[Handler] 文件变化: ${event.payload.path}/${event.payload.filename}`);
      
      // 忽略常见临时文件
      const ignorePatterns = [/\~$/, /\.tmp$/, /\.swp$/, /\.git\//, /node_modules\//];
      if (ignorePatterns.some(p => p.test(event.payload.filename || ''))) {
        return { status: 'ignored_temp_file' };
      }

      return {
        status: 'file_changed',
        path: event.payload.path,
        filename: event.payload.filename,
        timestamp: Date.now()
      };
    });

    this.handlers.set(EVENT_TYPES.WEBHOOK, async (event) => {
      console.log(`[Handler] 处理Webhook: ${event.payload.type || 'unknown'}`);
      return {
        status: 'webhook_processed',
        payload: event.payload
      };
    });

    this.handlers.set(EVENT_TYPES.SYSTEM_ALERT, async (event) => {
      console.log(`[Handler] ⚠️ 系统告警: ${event.payload.level} - ${event.payload.message}`);
      // 高优先级告警可能需要立即通知
      return {
        status: 'alert_acknowledged',
        level: event.payload.level,
        action: event.payload.suggestedAction || 'monitor'
      };
    });

    this.handlers.set(EVENT_TYPES.HEARTBEAT, async (event) => {
      return this.performHeartbeat();
    });
  }

  registerHandler(eventType, handler) {
    this.handlers.set(eventType, handler);
  }

  enqueue(event) {
    const success = this.queue.enqueue(event);
    if (success) {
      this.stats.totalEvents++;
      if (this.config.verbose) {
        console.log(`[Queue] +${event.type} (P${event.priority}) - 队列长度: ${this.queue.size()}`);
      }
    }
    return success;
  }

  async start() {
    if (this.running) return;
    this.running = true;
    this.stats.startTime = Date.now();

    console.log('\n═══════════════════════════════════════════════════════════════');
    console.log('🚀 Agent Event Loop 启动');
    console.log(`   并发数: ${this.config.maxConcurrency}`);
    console.log(`   Webhook: ${this.config.enableWebhook ? `:${this.config.webhookPort}` : '禁用'}`);
    console.log('═══════════════════════════════════════════════════════════════\n');

    // 启动webhook服务器
    if (this.config.enableWebhook) {
      this.webhook.start();
    }

    // 注册默认定时任务
    this.setupDefaultJobs();

    // 启动主循环
    this.loop();
  }

  setupDefaultJobs() {
    // 心跳检查 - 每5分钟
    this.scheduler.addJob('heartbeat', {
      interval: 5 * 60 * 1000,
      priority: PRIORITY.LOW,
      handler: () => ({ check: 'system_resources' })
    });

    // 内存整理 - 每4小时
    this.scheduler.addJob('memory_consolidation', {
      interval: 4 * 60 * 60 * 1000,
      priority: PRIORITY.LOW,
      handler: () => ({ action: 'compact_memory' })
    });
  }

  async loop() {
    while (this.running) {
      const event = this.queue.dequeue();

      if (!event) {
        // 队列为空，休眠
        await this.sleep(this.config.idleSleepMs);
        continue;
      }

      // 检查并发限制
      if (this.processingCount >= this.config.maxConcurrency) {
        // 重新入队，稍后处理
        this.queue.enqueue(event);
        await this.sleep(this.config.busySleepMs);
        continue;
      }

      // 处理事件
      this.processEvent(event);
      
      // 短暂休眠让其他事件有机会入队
      await this.sleep(this.config.busySleepMs);
    }
  }

  async processEvent(event) {
    this.processingCount++;
    event.status = 'processing';
    event.processedAt = Date.now();

    if (this.config.verbose) {
      console.log(`[Process] 开始处理 ${event.id} (${event.type})`);
    }

    const handler = this.handlers.get(event.type);
    
    if (!handler) {
      console.warn(`[Process] 未找到处理器: ${event.type}`);
      event.status = 'failed';
      this.processingCount--;
      this.stats.failedEvents++;
      return;
    }

    try {
      const result = await handler(event);
      event.status = 'completed';
      event.result = result;
      this.stats.processedEvents++;
      
      if (this.config.verbose) {
        console.log(`[Process] ✅ ${event.id} 完成`);
      }
    } catch (error) {
      event.status = 'failed';
      event.error = error.message;
      this.stats.failedEvents++;
      
      console.error(`[Process] ❌ ${event.id} 失败: ${error.message}`);
      
      // 失败重试逻辑 (高优先级事件最多重试2次)
      if (event.priority <= PRIORITY.HIGH && (!event.retries || event.retries < 2)) {
        event.retries = (event.retries || 0) + 1;
        event.status = 'pending';
        event.processedAt = null;
        this.queue.enqueue(event);
        console.log(`[Process] 🔄 ${event.id} 已加入重试队列 (${event.retries}/2)`);
      }
    } finally {
      this.processingCount--;
    }
  }

  async performHeartbeat() {
    const memUsage = process.memoryUsage();
    const uptime = process.uptime();
    
    return {
      type: 'heartbeat',
      timestamp: Date.now(),
      memory: {
        rss: Math.floor(memUsage.rss / 1024 / 1024) + 'MB',
        heapUsed: Math.floor(memUsage.heapUsed / 1024 / 1024) + 'MB'
      },
      uptime: Math.floor(uptime / 60) + 'm',
      queueSize: this.queue.size(),
      processing: this.processingCount,
      stats: this.stats
    };
  }

  async performMemoryConsolidation() {
    console.log('[Heartbeat] 执行内存整理...');
    // 触发垃圾回收 (如果可用)
    if (global.gc) {
      global.gc();
      return { status: 'gc_triggered' };
    }
    return { status: 'no_gc_available' };
  }

  async performGitStatusCheck() {
    return new Promise((resolve) => {
      const child = spawn('git', ['status', '--short'], { cwd: __dirname, stdio: 'pipe' });
      let output = '';
      child.stdout.on('data', (data) => output += data.toString());
      child.on('close', () => {
        resolve({
          status: 'git_checked',
          changes: output.trim().split('\n').filter(Boolean).length,
          details: output.trim()
        });
      });
    });
  }

  stop() {
    this.running = false;
    this.scheduler.listJobs().forEach(j => this.scheduler.removeJob(j.id));
    this.webhook.stop();
    console.log('[AgentEventLoop] 已停止');
  }

  getStatus() {
    return {
      running: this.running,
      queueSize: this.queue.size(),
      processing: this.processingCount,
      stats: this.stats,
      jobs: this.scheduler.listJobs(),
      watchedPaths: Array.from(this.fileWatcher.watchers.keys())
    };
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ═══════════════════════════════════════════════════════════════════
// CLI 入口
// ═══════════════════════════════════════════════════════════════════
async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    console.log(`
╔══════════════════════════════════════════════════════════════════╗
║     KIMICLAW Agent Event Loop v1.0                               ║
║     阶段3: 7×24事件驱动循环                                       ║
╚══════════════════════════════════════════════════════════════════╝

用法:
  node AgentEventLoop.js [命令] [选项]

命令:
  start             启动事件循环 (默认)
  status            查看当前状态
  trigger "任务"    手动触发一个用户请求事件
  stop              停止事件循环 (通过文件信号)

选项:
  --verbose, -v     详细输出
  --port=N          Webhook端口 (默认9876)
  --no-webhook      禁用webhook服务器
  --help, -h        显示帮助

示例:
  node AgentEventLoop.js start --verbose
  node AgentEventLoop.js trigger "检查系统状态" --verbose
  node AgentEventLoop.js status
`);
    return;
  }

  const command = args[0];
  const verbose = args.includes('--verbose') || args.includes('-v');
  const portArg = args.find(a => a.startsWith('--port='));
  const port = portArg ? parseInt(portArg.split('=')[1]) : 9876;
  const enableWebhook = !args.includes('--no-webhook');

  const loop = new AgentEventLoop({
    verbose,
    webhookPort: port,
    enableWebhook
  });

  if (command === 'start' || (!['status', 'trigger', 'stop'].includes(command))) {
    // 启动事件循环
    await loop.start();
  } else if (command === 'trigger') {
    const goal = args[1] || '默认任务';
    const event = new AgentEvent(
      EVENT_TYPES.USER_REQUEST,
      { goal },
      PRIORITY.HIGH,
      'cli_manual'
    );
    loop.enqueue(event);
    
    // 处理一次就退出
    await loop.processEvent(event);
    console.log('\n✅ 手动触发完成');
    loop.stop();
  } else if (command === 'status') {
    console.log(JSON.stringify(loop.getStatus(), null, 2));
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}

export default AgentEventLoop;
