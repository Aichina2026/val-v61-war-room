#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════
 * KIMICLAW Unified Memory & State System v4.0
 * 任务-文件-进程-记忆 四维融合管理系统
 * ═══════════════════════════════════════════════════════════════════
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync } from 'fs';
import { join, basename, dirname } from 'path';
import crypto from 'crypto';

// ═══════════════════════════════════════════════════════════════════
// 四维状态模型
// ═══════════════════════════════════════════════════════════════════
class FourDimensionalState {
  constructor() {
    this.dimensions = {
      task: new Map(),      // 任务维度
      file: new Map(),      // 文件维度  
      process: new Map(),   // 进程维度
      memory: new Map()     // 记忆维度
    };
    this.relations = new Map(); // 四维关联
    this.persistencePath = './memory/4d-state';
    this.loadState();
  }

  // 生成唯一ID
  generateId(type) {
    return `${type}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  }

  // 创建任务并建立四维关联
  createTask(config) {
    const taskId = this.generateId('task');
    const timestamp = new Date().toISOString();
    
    const task = {
      id: taskId,
      type: config.type || 'general',
      description: config.description,
      status: 'created',
      priority: config.priority || 'normal',
      createdAt: timestamp,
      updatedAt: timestamp,
      metadata: config.metadata || {},
      
      // 四维关联ID
      relations: {
        files: [],      // 关联的文件
        processes: [],  // 关联的进程
        memories: []    // 关联的记忆
      },
      
      // 执行追踪
      execution: {
        startedAt: null,
        completedAt: null,
        attempts: 0,
        results: null,
        errors: []
      },
      
      // 成本追踪
      cost: {
        estimated: config.estimatedCost || 0,
        actual: 0,
        tokens: { input: 0, output: 0 }
      }
    };

    this.dimensions.task.set(taskId, task);
    this.persistState();
    
    console.log(`[4D-State] Created task: ${taskId}`);
    return task;
  }

  // 注册文件并关联任务
  registerFile(taskId, filePath, metadata = {}) {
    const fileId = this.generateId('file');
    const timestamp = new Date().toISOString();
    
    const file = {
      id: fileId,
      path: filePath,
      name: basename(filePath),
      type: metadata.type || 'output',
      size: metadata.size || 0,
      hash: metadata.hash || null,
      createdAt: timestamp,
      modifiedAt: timestamp,
      
      // 版本控制
      version: {
        current: 1,
        history: []
      },
      
      // 关联
      taskId: taskId,
      processId: metadata.processId || null,
      
      // 内容摘要
      summary: metadata.summary || null
    };

    this.dimensions.file.set(fileId, file);
    
    // 建立双向关联
    const task = this.dimensions.task.get(taskId);
    if (task) {
      task.relations.files.push(fileId);
      task.updatedAt = timestamp;
    }

    // 创建关系记录
    this.relations.set(`${taskId}-${fileId}`, {
      type: 'task-file',
      from: taskId,
      to: fileId,
      timestamp,
      metadata
    });

    this.persistState();
    console.log(`[4D-State] Registered file: ${fileId} -> ${filePath}`);
    return file;
  }

  // 注册进程并关联任务
  registerProcess(taskId, processConfig) {
    const processId = this.generateId('process');
    const timestamp = new Date().toISOString();
    
    const proc = {
      id: processId,
      type: processConfig.type || 'subagent',
      name: processConfig.name || 'unnamed',
      status: 'created',
      createdAt: timestamp,
      startedAt: null,
      completedAt: null,
      
      // 资源配置
      resources: {
        memory: 0,
        cpu: 0,
        tokens: 0
      },
      
      // 关联
      taskId: taskId,
      parentProcess: processConfig.parent || null,
      childProcesses: [],
      
      // 运行时信息
      runtime: {
        pid: null,
        sessionKey: processConfig.sessionKey || null,
        nodeId: processConfig.nodeId || null
      }
    };

    this.dimensions.process.set(processId, proc);
    
    // 建立双向关联
    const task = this.dimensions.task.get(taskId);
    if (task) {
      task.relations.processes.push(processId);
      task.updatedAt = timestamp;
    }

    this.relations.set(`${taskId}-${processId}`, {
      type: 'task-process',
      from: taskId,
      to: processId,
      timestamp
    });

    this.persistState();
    console.log(`[4D-State] Registered process: ${processId}`);
    return proc;
  }

  // 保存记忆片段
  saveMemory(config) {
    const memoryId = this.generateId('memory');
    const timestamp = new Date().toISOString();
    
    const memory = {
      id: memoryId,
      type: config.type || 'observation', // observation, learning, pattern, decision
      content: config.content,
      context: config.context || {},
      importance: config.importance || 0.5, // 0-1
      createdAt: timestamp,
      accessCount: 0,
      lastAccessed: timestamp,
      
      // 向量表示 (用于语义检索)
      embedding: config.embedding || null,
      
      // 关联
      taskId: config.taskId || null,
      fileId: config.fileId || null,
      processId: config.processId || null,
      
      // 记忆链接 (相关记忆)
      links: config.links || [],
      
      // TTL (生存时间)
      ttl: config.ttl || null,
      expiresAt: config.ttl ? new Date(Date.now() + config.ttl).toISOString() : null
    };

    this.dimensions.memory.set(memoryId, memory);

    // 建立关联
    if (config.taskId) {
      const task = this.dimensions.task.get(config.taskId);
      if (task) {
        task.relations.memories.push(memoryId);
      }
      this.relations.set(`${config.taskId}-${memoryId}`, {
        type: 'task-memory',
        from: config.taskId,
        to: memoryId,
        timestamp
      });
    }

    this.persistState();
    console.log(`[4D-State] Saved memory: ${memoryId} (${memory.type})`);
    return memory;
  }

  // 查询四维关联
  queryRelations(entityId, options = {}) {
    const results = {
      entity: null,
      related: {
        tasks: [],
        files: [],
        processes: [],
        memories: []
      }
    };

    // 查找实体
    for (const [dimName, dimMap] of Object.entries(this.dimensions)) {
      if (dimMap.has(entityId)) {
        results.entity = { dimension: dimName, data: dimMap.get(entityId) };
        break;
      }
    }

    if (!results.entity) return null;

    // 根据类型查找关联
    const entity = results.entity.data;
    if (entity.relations) {
      for (const [type, ids] of Object.entries(entity.relations)) {
        const dimName = type.replace('s', ''); // files -> file
        const dim = this.dimensions[dimName];
        if (dim) {
          results.related[type] = ids.map(id => dim.get(id)).filter(Boolean);
        }
      }
    }

    // 反向查找
    for (const [relId, rel] of this.relations) {
      if (rel.to === entityId) {
        const sourceDim = rel.type.split('-')[0] + 's';
        const source = this.dimensions[sourceDim]?.get(rel.from);
        if (source) {
          results.related[sourceDim].push(source);
        }
      }
    }

    return results;
  }

  // 语义记忆搜索
  searchMemory(query, options = {}) {
    const memories = Array.from(this.dimensions.memory.values());
    
    // 过滤过期记忆
    const now = new Date().toISOString();
    const validMemories = memories.filter(m => !m.expiresAt || m.expiresAt > now);

    // 简单文本匹配 (实际应用中使用向量相似度)
    const results = validMemories.filter(m => {
      const content = m.content?.toString().toLowerCase() || '';
      const context = JSON.stringify(m.context).toLowerCase();
      return content.includes(query.toLowerCase()) || 
             context.includes(query.toLowerCase());
    });

    // 按重要性和访问频率排序
    results.sort((a, b) => {
      const scoreA = a.importance * (1 + a.accessCount * 0.1);
      const scoreB = b.importance * (1 + b.accessCount * 0.1);
      return scoreB - scoreA;
    });

    // 更新访问计数
    results.forEach(m => {
      m.accessCount++;
      m.lastAccessed = now;
    });

    return options.limit ? results.slice(0, options.limit) : results;
  }

  // 生成任务图谱 (可视化任务依赖关系)
  generateTaskGraph(taskId) {
    const task = this.dimensions.task.get(taskId);
    if (!task) return null;

    const graph = {
      id: taskId,
      label: task.description,
      status: task.status,
      nodes: [],
      edges: []
    };

    // 添加任务本身
    graph.nodes.push({
      id: taskId,
      type: 'task',
      label: task.description,
      status: task.status
    });

    // 添加关联文件
    task.relations.files.forEach(fileId => {
      const file = this.dimensions.file.get(fileId);
      if (file) {
        graph.nodes.push({
          id: fileId,
          type: 'file',
          label: file.name,
          path: file.path
        });
        graph.edges.push({ from: taskId, to: fileId, type: 'produces' });
      }
    });

    // 添加关联进程
    task.relations.processes.forEach(procId => {
      const proc = this.dimensions.process.get(procId);
      if (proc) {
        graph.nodes.push({
          id: procId,
          type: 'process',
          label: proc.name,
          status: proc.status
        });
        graph.edges.push({ from: taskId, to: procId, type: 'executes' });
      }
    });

    // 添加关联记忆
    task.relations.memories.forEach(memId => {
      const mem = this.dimensions.memory.get(memId);
      if (mem) {
        graph.nodes.push({
          id: memId,
          type: 'memory',
          label: mem.type,
          importance: mem.importance
        });
        graph.edges.push({ from: taskId, to: memId, type: 'remembers' });
      }
    });

    return graph;
  }

  // 持久化状态
  persistState() {
    try {
      if (!existsSync(this.persistencePath)) {
        mkdirSync(this.persistencePath, { recursive: true });
      }

      const state = {
        timestamp: new Date().toISOString(),
        dimensions: {
          task: Array.from(this.dimensions.task.entries()),
          file: Array.from(this.dimensions.file.entries()),
          process: Array.from(this.dimensions.process.entries()),
          memory: Array.from(this.dimensions.memory.entries())
        },
        relations: Array.from(this.relations.entries()),
        stats: this.getStats()
      };

      const statePath = join(this.persistencePath, 'state.json');
      writeFileSync(statePath, JSON.stringify(state, null, 2));
    } catch (e) {
      console.error('[4D-State] Failed to persist:', e.message);
    }
  }

  // 加载状态
  loadState() {
    try {
      const statePath = join(this.persistencePath, 'state.json');
      if (existsSync(statePath)) {
        const state = JSON.parse(readFileSync(statePath, 'utf8'));
        
        // 恢复维度数据
        for (const [dimName, entries] of Object.entries(state.dimensions)) {
          this.dimensions[dimName] = new Map(entries);
        }
        
        // 恢复关系
        this.relations = new Map(state.relations);
        
        console.log(`[4D-State] Loaded state: ${this.getStats().total} entities`);
      }
    } catch (e) {
      console.log('[4D-State] No previous state found, starting fresh');
    }
  }

  // 获取统计信息
  getStats() {
    return {
      tasks: this.dimensions.task.size,
      files: this.dimensions.file.size,
      processes: this.dimensions.process.size,
      memories: this.dimensions.memory.size,
      relations: this.relations.size,
      total: this.dimensions.task.size + 
             this.dimensions.file.size + 
             this.dimensions.process.size + 
             this.dimensions.memory.size
    };
  }

  // 清理过期数据
  cleanup() {
    const now = new Date();
    let cleaned = 0;

    // 清理过期记忆
    for (const [id, mem] of this.dimensions.memory) {
      if (mem.expiresAt && mem.expiresAt < now.toISOString()) {
        this.dimensions.memory.delete(id);
        cleaned++;
      }
    }

    // 清理已完成任务的旧进程
    for (const [id, proc] of this.dimensions.process) {
      const task = this.dimensions.task.get(proc.taskId);
      if (task && task.status === 'completed' && proc.completedAt) {
        const completedTime = new Date(proc.completedAt);
        if (now - completedTime > 24 * 60 * 60 * 1000) { // 24小时
          this.dimensions.process.delete(id);
          cleaned++;
        }
      }
    }

    if (cleaned > 0) {
      this.persistState();
      console.log(`[4D-State] Cleaned up ${cleaned} expired entities`);
    }

    return cleaned;
  }
}

// ═══════════════════════════════════════════════════════════════════
// 工作流记忆融合器
// ═══════════════════════════════════════════════════════════════════
class WorkflowMemoryFusion {
  constructor(stateManager) {
    this.state = stateManager;
    this.fusionRules = new Map();
    this.initializeRules();
  }

  initializeRules() {
    // 4AI工作流融合规则
    this.fusionRules.set('4ai-parallel', {
      onRoundComplete: (taskId, roundData) => {
        this.state.saveMemory({
          type: 'pattern',
          content: `4AI Round ${roundData.round}: ${roundData.role} completed`,
          taskId,
          context: roundData,
          importance: 0.7
        });
      },
      onComplete: (taskId, finalData) => {
        this.state.saveMemory({
          type: 'learning',
          content: `4AI workflow completed: ${finalData.description}`,
          taskId,
          context: finalData,
          importance: 0.9
        });
      }
    });

    // 零错误系统融合规则
    this.fusionRules.set('zero-error', {
      onReview: (taskId, reviewData) => {
        this.state.saveMemory({
          type: 'observation',
          content: `Security review: ${reviewData.findings}`,
          taskId,
          context: reviewData,
          importance: 0.95 // 高重要性
        });
      },
      onFix: (taskId, fixData) => {
        this.state.saveMemory({
          type: 'learning',
          content: `Auto-fix applied: ${fixData.strategy}`,
          taskId,
          context: fixData,
          importance: 0.85
        });
      }
    });

    // 辩证系统融合规则
    this.fusionRules.set('dialectic', {
      onDebate: (taskId, debateData) => {
        this.state.saveMemory({
          type: 'decision',
          content: `Debate outcome: ${debateData.winner}`,
          taskId,
          context: debateData,
          importance: 0.8
        });
      }
    });
  }

  // 应用融合规则
  applyFusion(workflowType, event, taskId, data) {
    const rules = this.fusionRules.get(workflowType);
    if (rules && rules[event]) {
      rules[event](taskId, data);
    }
  }

  // 跨工作流学习
  crossWorkflowLearning() {
    const learnings = this.state.searchMemory('', { type: 'learning' });
    const patterns = this.state.searchMemory('', { type: 'pattern' });

    // 发现跨工作流的共同模式
    const commonPatterns = this.findCommonPatterns([...learnings, ...patterns]);
    
    return commonPatterns;
  }

  findCommonPatterns(memories) {
    // 简单实现：按内容相似度分组
    const groups = new Map();
    
    memories.forEach(mem => {
      const key = mem.content?.substring(0, 50); // 取前50字符作为组键
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key).push(mem);
    });

    // 返回出现多次的模式
    return Array.from(groups.entries())
      .filter(([_, items]) => items.length > 1)
      .map(([key, items]) => ({
        pattern: key,
        occurrences: items.length,
        memories: items
      }));
  }
}

// ═══════════════════════════════════════════════════════════════════
// 导出
// ═══════════════════════════════════════════════════════════════════
export { FourDimensionalState, WorkflowMemoryFusion };

// CLI
async function main() {
  const state = new FourDimensionalState();
  
  if (process.argv[2] === 'stats') {
    console.log('4D State Statistics:');
    console.log(JSON.stringify(state.getStats(), null, 2));
  }
  else if (process.argv[2] === 'cleanup') {
    const cleaned = state.cleanup();
    console.log(`Cleaned up ${cleaned} entities`);
  }
  else if (process.argv[2] === 'search') {
    const query = process.argv[3] || '';
    const results = state.searchMemory(query, { limit: 10 });
    console.log(`Found ${results.length} memories:`);
    results.forEach(m => console.log(`  - ${m.type}: ${m.content?.substring(0, 50)}...`));
  }
  else {
    console.log('Usage:');
    console.log('  node unified-memory.js stats');
    console.log('  node unified-memory.js cleanup');
    console.log('  node unified-memory.js search "query"');
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}
