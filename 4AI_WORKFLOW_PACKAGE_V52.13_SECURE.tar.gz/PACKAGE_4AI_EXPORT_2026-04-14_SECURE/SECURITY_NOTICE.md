# 🔐 安全提示 - API密钥已移除

**本包已移除所有API密钥，使用前必须手动配置！**

---

## ⚠️ 重要提醒

所有敏感信息已被替换为占位符：
- `YOUR_KIMI_API_KEY_HERE`
- `YOUR_ALIYUN_API_KEY_HERE`
- `YOUR_4SAPI_KEY_1_HERE`
- `YOUR_4SAPI_KEY_2_HERE`
- `YOUR_4SAPI_KEY_3_HERE`
- `YOUR_4SAPI_KEY_4_HERE`
- `YOUR_ADMIN_PASSWORD_HERE`

---

## 📝 需要配置的文件

### 1. unified-ai-config.json (workspace-root/)
```json
{
  "api_pools": {
    "kimi": {
      "keys": ["YOUR_KIMI_API_KEY_HERE"]
    },
    "aliyun": {
      "keys": [
        "YOUR_ALIYUN_API_KEY_HERE",
        "YOUR_ALIYUN_API_KEY_HERE"
      ]
    },
    "4sapi": {
      "keys": [
        "YOUR_4SAPI_KEY_1_HERE",
        "YOUR_4SAPI_KEY_2_HERE",
        "YOUR_4SAPI_KEY_3_HERE",
        "YOUR_4SAPI_KEY_4_HERE"
      ]
    }
  }
}
```

### 2. config.json (workspace-root/)
```json
{
  "adminPassword": "YOUR_ADMIN_PASSWORD_HERE"
}
```

### 3. skills/4ai-workflow/config.json
```json
{
  "main": {
    "key": "YOUR_4SAPI_KEY_HERE"
  },
  "backup": {
    "key": "YOUR_ALIYUN_KEY_HERE"
  }
}
```

---

## 🔧 快速配置命令

```bash
# 编辑配置文件
nano /root/.openclaw/workspace/unified-ai-config.json
nano /root/.openclaw/workspace/config.json
nano ~/.openclaw/skills/4ai-workflow/config.json
```

---

**安全版本导出时间**: 2026-04-14 02:40  
**清理内容**: 9个API密钥，1个管理密码
