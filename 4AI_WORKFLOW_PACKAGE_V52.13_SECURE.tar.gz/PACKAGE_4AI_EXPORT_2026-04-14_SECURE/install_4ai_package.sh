#!/bin/bash
set -e

PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
WORKSPACE="/root/.openclaw/workspace"
SKILL_DIR="$HOME/.openclaw/skills/4ai-workflow"

echo "🚀 安装4AI工作流系统 V52.13..."

# 检查包是否存在
if [ ! -d "$PACKAGE_DIR/workspace-root" ]; then
    echo "❌ 错误: 未找到 workspace-root 目录"
    echo "请确保在解压后的包目录中运行此脚本"
    exit 1
fi

# 创建工作区目录
mkdir -p "$WORKSPACE"
mkdir -p "$SKILL_DIR"
mkdir -p "$WORKSPACE/memory"

# 复制核心文件
echo "📦 复制核心文件..."
cp -v "$PACKAGE_DIR/workspace-root/"*.js "$WORKSPACE/" 2>/dev/null || true
cp -v "$PACKAGE_DIR/workspace-root/"*.cjs "$WORKSPACE/" 2>/dev/null || true
cp -v "$PACKAGE_DIR/workspace-root/"*.json "$WORKSPACE/" 2>/dev/null || true

# 安装技能
echo "🔧 安装4ai-workflow技能..."
cp -v "$PACKAGE_DIR/skills/4ai-workflow/"*.json "$SKILL_DIR/"
cp -v "$PACKAGE_DIR/skills/4ai-workflow/"*.md "$SKILL_DIR/"

# 设置权限
echo "🔐 设置执行权限..."
chmod +x "$WORKSPACE/unified-ai-cli.js" 2>/dev/null || true
chmod +x "$WORKSPACE/parallel_ai_skill_optimized.js" 2>/dev/null || true
chmod +x "$WORKSPACE/zero_error_system_optimized.cjs" 2>/dev/null || true
chmod +x "$WORKSPACE/KimiClawAgent.js" 2>/dev/null || true

echo ""
echo "✅ 安装完成!"
echo ""
echo "📋 已安装文件:"
ls -1 "$WORKSPACE/"*.js "$WORKSPACE/"*.cjs "$WORKSPACE/"*.json 2>/dev/null | sed 's/^/  - /'
echo ""
echo "🔑 下一步: 编辑 $WORKSPACE/unified-ai-config.json 配置API密钥"
echo "🧪 测试命令: node $WORKSPACE/unified-ai-cli.js 4ai '测试'"
echo "📖 完整文档: $WORKSPACE/4AI_PACKAGE_INSTALLATION_GUIDE.md"
