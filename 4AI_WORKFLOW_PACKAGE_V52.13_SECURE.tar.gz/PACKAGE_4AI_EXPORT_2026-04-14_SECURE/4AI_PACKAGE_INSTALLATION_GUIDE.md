# 4AI工作流系统 - 导出包安装指南

**版本**: V52.13-20260414  
**系统**: 4AI Unified Workflow System  
**适用**: OpenClaw Gateway 任意实例

---

## 📦 包内容清单

### 1. 核心工作流文件 (workspace-root/)

| 文件 | 大小 | 说明 |
|------|:----:|------|
| `parallel_ai_skill_optimized.js` | ~35KB | **并行AI技能 (优化版)** - 4模型并行推演 |
| `zero_error_system_optimized.cjs` | ~28KB | **零错误系统 (优化版)** - 2-3轮对抗审查 |
| `AutonomousPlanner.js` | ~18KB | **自主规划层** - 复杂度分析+工作流选择 |
| `ReActAgent.js` | ~22KB | **ReAct工具使用** - 9种内置工具 |
| `AgentEventLoop.js` | ~20KB | **事件驱动循环** - 7×24持续运行 |
| `ExperienceLearner.js` | ~18KB | **经验学习闭环** - 策略优化+工具评分 |
| `KimiClawAgent.js` | ~10KB | **统一AGENT入口** - 整合全部4阶段 |
| `unified-ai-cli.js` | ~15KB | **统一CLI入口** - 整合4AI/零错误/工作流 |
| `unified-ai-config.json` | ~8KB | **统一配置文件** - 所有API密钥和模型配置 |
| `config.json` | ~17KB | **工作流配置** - 332种自动修复策略 |
| `unified-memory-system.js` | ~12KB | **统一记忆系统** - 4D状态持久化 |
| `TOOLS.md` | ~25KB | **工具使用文档** - 完整使用说明 |

### 2. 备选/兼容版本

| 文件 | 说明 |
|------|------|
| `parallel_ai_skill.js` | 标准版 (非优化，兼容旧系统) |
| `zero_error_system.cjs` | 标准版 (非优化，兼容旧系统) |
| `unified-workflow-v5.js` | 历史版本V5工作流 |

### 3. Skill定义 (skills/4ai-workflow/)

| 文件 | 说明 |
|------|------|
| `SKILL.md` | 技能文档 (7.9KB) |
| `config.json` | 技能配置 (17.7KB) |

---

## 🚀 安装步骤

### 步骤1: 复制包到目标OpenClaw

```bash
# 方法1: 直接复制 (如果在同一机器或已挂载)
cp 4AI_WORKFLOW_PACKAGE_V52.13.tar.gz /目标路径/

# 方法2: 使用scp远程复制
scp 4AI_WORKFLOW_PACKAGE_V52.13.tar.gz user@目标机器IP:/root/.openclaw/workspace/

# 方法3: 使用rsync (推荐，支持断点续传)
rsync -avz --progress 4AI_WORKFLOW_PACKAGE_V52.13.tar.gz user@目标机器IP:/root/.openclaw/workspace/

# 方法4: 上传到对象存储后下载
# 上传到S3/OSS等，然后在目标机器wget/curl下载
```

### 步骤2: 解压包

```bash
cd /root/.openclaw/workspace
tar -xzf 4AI_WORKFLOW_PACKAGE_V52.13.tar.gz
cd PACKAGE_4AI_EXPORT_2026-04-14
```

### 步骤3: 安装核心文件到工作区

```bash
# 复制核心JS文件到工作区根目录
cp workspace-root/*.js workspace-root/*.cjs workspace-root/*.json ../

# 创建技能目录并复制技能文件
mkdir -p ~/.openclaw/skills/4ai-workflow
cp skills/4ai-workflow/* ~/.openclaw/skills/4ai-workflow/
```

### 步骤4: 配置API密钥

```bash
# 编辑统一配置文件
nano /root/.openclaw/workspace/unified-ai-config.json
```

**必须配置的密钥**:
```json
{
  "nodes": {
    "kimi2.5": {
      "apiKey": "sk-kimi-xxx"
    },
    "ali": {
      "apiKey": "sk-ali-xxx"
    },
    "4sapi": {
      "apiKeys": ["key1", "key2", "key3", "key4"]
    }
  }
}
```

### 步骤5: 验证安装

```bash
cd /root/.openclaw/workspace

# 测试并行AI技能
node parallel_ai_skill_optimized.js "测试4AI工作流"

# 测试零错误系统
node zero_error_system_optimized.cjs "测试零错误系统"

# 测试统一CLI
./unified-ai-cli.js 4ai "测试统一CLI"
```

---

## 📁 文件路径映射表

| 源路径 (本机) | 目标路径 (新OpenClaw) | 必需 |
|---------------|----------------------|:----:|
| `workspace-root/parallel_ai_skill_optimized.js` | `/root/.openclaw/workspace/parallel_ai_skill_optimized.js` | ✅ |
| `workspace-root/zero_error_system_optimized.cjs` | `/root/.openclaw/workspace/zero_error_system_optimized.cjs` | ✅ |
| `workspace-root/AutonomousPlanner.js` | `/root/.openclaw/workspace/AutonomousPlanner.js` | ✅ |
| `workspace-root/ReActAgent.js` | `/root/.openclaw/workspace/ReActAgent.js` | ✅ |
| `workspace-root/AgentEventLoop.js` | `/root/.openclaw/workspace/AgentEventLoop.js` | ✅ |
| `workspace-root/ExperienceLearner.js` | `/root/.openclaw/workspace/ExperienceLearner.js` | ✅ |
| `workspace-root/KimiClawAgent.js` | `/root/.openclaw/workspace/KimiClawAgent.js` | ✅ |
| `workspace-root/unified-ai-cli.js` | `/root/.openclaw/workspace/unified-ai-cli.js` | ✅ |
| `workspace-root/unified-ai-config.json` | `/root/.openclaw/workspace/unified-ai-config.json` | ✅ |
| `workspace-root/config.json` | `/root/.openclaw/workspace/config.json` | ✅ |
| `workspace-root/unified-memory-system.js` | `/root/.openclaw/workspace/unified-memory-system.js` | ✅ |
| `skills/4ai-workflow/SKILL.md` | `~/.openclaw/skills/4ai-workflow/SKILL.md` | ✅ |
| `skills/4ai-workflow/config.json` | `~/.openclaw/skills/4ai-workflow/config.json` | ✅ |

---

## ⚡ 快速安装脚本

创建 `install_4ai_package.sh`:

```bash
#!/bin/bash
set -e

PACKAGE_DIR="PACKAGE_4AI_EXPORT_2026-04-14"
WORKSPACE="/root/.openclaw/workspace"
SKILL_DIR="$HOME/.openclaw/skills/4ai-workflow"

echo "🚀 安装4AI工作流系统 V52.13..."

# 检查包是否存在
if [ ! -d "$PACKAGE_DIR" ]; then
    echo "❌ 错误: 未找到 $PACKAGE_DIR 目录"
    echo "请确保已解压 4AI_WORKFLOW_PACKAGE_V52.13.tar.gz"
    exit 1
fi

# 复制核心文件
echo "📦 复制核心文件..."
cp -v "$PACKAGE_DIR/workspace-root/"*.js "$WORKSPACE/" 2>/dev/null || true
cp -v "$PACKAGE_DIR/workspace-root/"*.cjs "$WORKSPACE/" 2>/dev/null || true
cp -v "$PACKAGE_DIR/workspace-root/"*.json "$WORKSPACE/" 2>/dev/null || true

# 安装技能
echo "🔧 安装4ai-workflow技能..."
mkdir -p "$SKILL_DIR"
cp -v "$PACKAGE_DIR/skills/4ai-workflow/"*.json "$SKILL_DIR/"
cp -v "$PACKAGE_DIR/skills/4ai-workflow/"*.md "$SKILL_DIR/"

# 设置权限
echo "🔐 设置执行权限..."
chmod +x "$WORKSPACE/unified-ai-cli.js"
chmod +x "$WORKSPACE/parallel_ai_skill_optimized.js"
chmod +x "$WORKSPACE/zero_error_system_optimized.cjs"
chmod +x "$WORKSPACE/KimiClawAgent.js"

echo "✅ 安装完成!"
echo ""
echo "📋 下一步:"
echo "1. 编辑 $WORKSPACE/unified-ai-config.json 配置API密钥"
echo "2. 运行测试: node $WORKSPACE/unified-ai-cli.js 4ai '测试'"
echo ""
echo "📖 详细文档: $WORKSPACE/TOOLS.md"
```

使用方法:
```bash
chmod +x install_4ai_package.sh
./install_4ai_package.sh
```

---

## 🔧 故障排除

### 问题1: 缺少依赖

```bash
# 安装Node.js依赖
npm install axios zod chalk

# 或使用Bun
bun install axios zod chalk
```

### 问题2: API密钥未配置

```bash
# 检查配置
node -e "console.log(require('/root/.openclaw/workspace/unified-ai-config.json'))"

# 如果没有API密钥，系统会使用模拟模式 (仅限测试)
```

### 问题3: 权限错误

```bash
chmod +x /root/.openclaw/workspace/*.js
chmod +x /root/.openclaw/workspace/*.cjs
```

### 问题4: 路径不存在

```bash
# 创建必要目录
mkdir -p /root/.openclaw/workspace
mkdir -p ~/.openclaw/skills/4ai-workflow
mkdir -p /root/.openclaw/workspace/memory
```

---

## 📝 使用示例

### 基本使用

```bash
cd /root/.openclaw/workspace

# 4AI并行推演
./unified-ai-cli.js 4ai "设计微服务架构"

# 零错误系统
./unified-ai-cli.js zero "生成安全认证代码"

# 完整AGENT
node KimiClawAgent.js "分析项目结构" --mode=auto
```

### 编程调用

```javascript
const { AutonomousPlanner } = require('./AutonomousPlanner');
const { ReActAgent } = require('./ReActAgent');

// 自主规划
const planner = new AutonomousPlanner();
const decision = planner.analyzeComplexity("设计任务");

// ReAct执行
const agent = new ReActAgent();
const result = await agent.execute("执行任务");
```

---

## 🔄 更新维护

### 从旧版本更新

```bash
# 备份旧配置
cp unified-ai-config.json unified-ai-config.json.backup

# 解压新包
tar -xzf 4AI_WORKFLOW_PACKAGE_V52.13.tar.gz

# 执行安装
./install_4ai_package.sh

# 恢复API密钥配置
# (手动合并新config.json中的新策略到旧配置)
```

### 版本检查

```bash
# 查看当前版本
grep "系统版本" /root/.openclaw/workspace/TOOLS.md | head -1

# 或
node -e "console.log('V52.13-20260414')"
```

---

## 📊 系统要求

| 资源 | 最低要求 | 推荐配置 |
|------|:--------:|:--------:|
| **Node.js** | v18+ | v20+ |
| **内存** | 2GB | 4GB+ |
| **磁盘** | 500MB | 1GB+ |
| **网络** | 可访问API端点 | 低延迟连接 |

---

## 📞 支持与反馈

- **文档**: `/root/.openclaw/workspace/TOOLS.md`
- **技能文档**: `~/.openclaw/skills/4ai-workflow/SKILL.md`
- **系统指南**: `/root/.openclaw/workspace/UNIFIED_SYSTEM_GUIDE.md`

---

**导出时间**: 2026-04-14 02:35  
**包MD5**: c2478e877a19fd65ed312453de7b9ee4  
**适用版本**: OpenClaw Gateway v2.0+
